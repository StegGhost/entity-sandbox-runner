from stegverse import MaxTransferInvariant, Passport, SharedBatteryFloorInvariant, TransitionGuard


def test_charge_blocked_when_battery_floor_would_break() -> None:
    guard = TransitionGuard(invariants=[SharedBatteryFloorInvariant(min_battery=10)])
    passport = Passport(agent_id="agent-1", identity_root="root-1")
    result = guard.evaluate(passport, {"type": "charge", "amount": 3}, {"battery": 12})
    assert result.admitted is False
    assert result.reason == "battery_floor_protection"


def test_share_blocked_when_above_max_transfer() -> None:
    guard = TransitionGuard(invariants=[MaxTransferInvariant(max_amount=1)])
    passport = Passport(agent_id="agent-1", identity_root="root-1")
    result = guard.evaluate(passport, {"type": "share", "amount": 2}, {"battery": 40})
    assert result.admitted is False
    assert result.reason == "transfer_limit"


def test_action_admitted_when_constraints_hold() -> None:
    guard = TransitionGuard(invariants=[SharedBatteryFloorInvariant(min_battery=10)])
    passport = Passport(agent_id="agent-1", identity_root="root-1")
    result = guard.evaluate(passport, {"type": "charge", "amount": 1}, {"battery": 12})
    assert result.admitted is True
    assert result.reason == "admitted"
