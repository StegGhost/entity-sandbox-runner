from __future__ import annotations

from stegverse import MaxTransferInvariant, Passport, SharedBatteryFloorInvariant, TransitionGuard


def main() -> None:
    guard = TransitionGuard(
        invariants=[
            SharedBatteryFloorInvariant(min_battery=10),
            MaxTransferInvariant(max_amount=1),
        ]
    )
    passport = Passport(agent_id="agent-1", identity_root="root-1")

    states_and_actions = [
        ({"battery": 12}, {"type": "charge", "amount": 1}),
        ({"battery": 10}, {"type": "charge", "amount": 2}),
        ({"battery": 25}, {"type": "share", "amount": 3}),
    ]

    for idx, (state, action) in enumerate(states_and_actions, start=1):
        result = guard.evaluate(passport=passport, proposed_action=action, state=state)
        print(f"case={idx} admitted={result.admitted} reason={result.reason}")
        print(result.receipt.to_dict())


if __name__ == "__main__":
    main()
