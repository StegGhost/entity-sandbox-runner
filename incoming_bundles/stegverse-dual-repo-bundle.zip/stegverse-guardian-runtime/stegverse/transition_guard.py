from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, List

from .invariants import Invariant
from .passport import Passport
from .receipts import Receipt


@dataclass
class GuardResult:
    admitted: bool
    reason: str
    receipt: Receipt


class TransitionGuard:
    def __init__(self, invariants: List[Invariant] | None = None) -> None:
        self.invariants = invariants or []

    def evaluate(
        self,
        passport: Passport,
        proposed_action: Dict[str, object],
        state: Dict[str, object],
    ) -> GuardResult:
        passport.record_state({"identity_root": passport.identity_root, **state})
        if not passport.continuity_ok():
            receipt = Receipt.create(
                agent_id=passport.agent_id,
                identity_root=passport.identity_root,
                action=proposed_action,
                admitted=False,
                reason="identity_continuity_failure",
                state=state,
            )
            return GuardResult(False, "identity_continuity_failure", receipt)

        for invariant in self.invariants:
            ok, reason = invariant.check(proposed_action, state)
            if not ok:
                receipt = Receipt.create(
                    agent_id=passport.agent_id,
                    identity_root=passport.identity_root,
                    action=proposed_action,
                    admitted=False,
                    reason=reason,
                    state=state,
                )
                return GuardResult(False, reason, receipt)

        receipt = Receipt.create(
            agent_id=passport.agent_id,
            identity_root=passport.identity_root,
            action=proposed_action,
            admitted=True,
            reason="admitted",
            state=state,
        )
        return GuardResult(True, "admitted", receipt)
