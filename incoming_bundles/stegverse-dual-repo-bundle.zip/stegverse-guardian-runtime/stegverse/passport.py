from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List


@dataclass
class Passport:
    agent_id: str
    identity_root: str
    state_history: List[Dict[str, object]] = field(default_factory=list)

    def record_state(self, state: Dict[str, object]) -> None:
        self.state_history.append(state)

    def continuity_ok(self) -> bool:
        return all(entry.get("identity_root") == self.identity_root for entry in self.state_history)
