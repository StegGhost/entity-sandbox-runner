from __future__ import annotations

from dataclasses import dataclass, asdict
from hashlib import sha256
from typing import Dict


@dataclass
class Receipt:
    agent_id: str
    identity_root: str
    action_type: str
    admitted: bool
    reason: str
    state_digest: str

    @classmethod
    def create(
        cls,
        agent_id: str,
        identity_root: str,
        action: Dict[str, object],
        admitted: bool,
        reason: str,
        state: Dict[str, object],
    ) -> "Receipt":
        digest = sha256(repr(sorted(state.items())).encode("utf-8")).hexdigest()
        return cls(
            agent_id=agent_id,
            identity_root=identity_root,
            action_type=str(action.get("type", "unknown")),
            admitted=admitted,
            reason=reason,
            state_digest=digest,
        )

    def to_dict(self) -> Dict[str, object]:
        return asdict(self)
