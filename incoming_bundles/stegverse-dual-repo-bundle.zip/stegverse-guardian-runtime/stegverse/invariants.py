from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, Tuple


class Invariant:
    def check(self, action: Dict[str, object], state: Dict[str, object]) -> Tuple[bool, str]:
        raise NotImplementedError


@dataclass
class SharedBatteryFloorInvariant(Invariant):
    min_battery: int

    def check(self, action: Dict[str, object], state: Dict[str, object]) -> Tuple[bool, str]:
        if action.get("type") != "charge":
            return True, "not_applicable"
        amount = int(action.get("amount", 0))
        if int(state.get("battery", 0)) - amount < self.min_battery:
            return False, "battery_floor_protection"
        return True, "ok"


@dataclass
class MaxTransferInvariant(Invariant):
    max_amount: int

    def check(self, action: Dict[str, object], state: Dict[str, object]) -> Tuple[bool, str]:
        if action.get("type") != "share":
            return True, "not_applicable"
        amount = int(action.get("amount", 0))
        if amount > self.max_amount:
            return False, "transfer_limit"
        return True, "ok"
