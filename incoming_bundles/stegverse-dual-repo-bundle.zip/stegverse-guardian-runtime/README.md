# StegVerse Guardian Runtime

StegVerse Guardian Runtime is a minimal execution-layer governance primitive for autonomous and multi-agent systems.

Its purpose is simple:

> Do not rely on agent intentions alone. Enforce admissibility at execution.

This repo is the paired solution layer to the StegGhost simulation lab. Where the StegGhost repo demonstrates system failure under weak constraints, this repo provides a small, installable runtime that can be embedded into agent systems to:

- bind actions to persistent identity roots
- evaluate transitions before application
- enforce invariants on shared resources
- emit receipts for every action decision

## Core idea

The runtime does **not** try to make agents morally better or semantically aligned.
It constrains what can happen at the point of execution.

That is the design center.

## Repo layout

```text
guardian-runtime/
├── .github/
│   └── workflows/
│       └── ci.yml
├── examples/
│   └── toy_world_example.py
├── stegverse/
│   ├── __init__.py
│   ├── invariants.py
│   ├── passport.py
│   ├── receipts.py
│   └── transition_guard.py
├── tests/
│   └── test_guardian_runtime.py
├── pyproject.toml
└── README.md
```

## Quickstart

```bash
python -m venv .venv
source .venv/bin/activate
pip install -e .
pytest
```

Run the example:

```bash
python examples/toy_world_example.py
```

## What is in scope

This repo intentionally stays small.

It includes:

- **passport**: identity continuity object for agents
- **transition guard**: evaluates proposed actions against invariants
- **invariants**: common resource protection checks
- **receipts**: signed-like deterministic action records for audit trails

It does **not** include:

- orchestration
- training infrastructure
- world models
- policy optimization
- remote execution control planes

## Integration pattern

A host system can wrap any proposed action like this:

```python
from stegverse import Passport, TransitionGuard, SharedBatteryFloorInvariant

passport = Passport(agent_id="agent-1", identity_root="root-1")
guard = TransitionGuard(invariants=[SharedBatteryFloorInvariant(min_battery=10)])

action = {"type": "charge", "amount": 4}
state = {"battery": 12}

result = guard.evaluate(passport=passport, proposed_action=action, state=state)
```

If the action violates admissibility constraints, the guard will deny it and emit a receipt describing why.

## Why this belongs in StegVerse

This repo belongs in the core StegVerse org because it is the delivery layer:

- compact
- installable
- developer-facing
- easy to embed into external systems

The StegGhost repo proves why it matters.
This repo makes it usable.

## Positioning

The most accurate framing is:

> **execution-layer constraint system for autonomous agents**

Or even more directly:

> **the missing runtime primitive that prevents agent systems from destabilizing themselves**

