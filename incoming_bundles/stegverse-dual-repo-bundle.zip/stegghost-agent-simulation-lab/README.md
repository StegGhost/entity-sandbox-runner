# StegGhost Agent Simulation Lab

StegGhost Agent Simulation Lab is a research sandbox for demonstrating a simple but important claim:

> We do not need smarter agents to change system behavior. We need execution-layer constraints.

This repo provides a minimal multi-agent environment that can be run in two modes:

- **ungoverned**: agents optimize locally with no transition controls or invariant checks
- **governed**: the same agents and environment run with constraint checks, identity continuity, and signed receipts

The goal is not to mimic a production economy or frontier agent stack. The goal is to generate **visible, repeatable divergence** between:

- a system that is free to destabilize itself
- a system with a minimal governance primitive at the execution boundary

## What the demo shows

Agents operate in a shared grid world with food, energy, and a central battery resource. They can:

- move
- gather food
- charge from the shared battery
- share energy
- make local decisions to maximize short-term utility

In the ungoverned mode, agents will often:

- hoard battery access
- starve neighboring agents
- overdraw common resources
- collapse system-wide stability

In the governed mode, the same environment is wrapped by guardrails that enforce:

- per-step admissibility checks
- protected common-pool resource floors
- bounded transfer behavior
- receipt logging for all applied actions
- stable agent identity across steps

## Repo layout

```text
agent-simulation-lab/
├── agents/
│   └── baseline_agent.py
├── analysis/
│   └── summarize_run.py
├── env/
│   └── world.py
├── runs/
│   ├── .gitkeep
│   ├── governed_example.json
│   └── ungoverned_example.json
├── scripts/
│   └── run_simulation.py
├── requirements.txt
└── README.md
```

## Quickstart

Create a venv and install requirements:

```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
```

Run ungoverned:

```bash
python scripts/run_simulation.py --mode ungoverned --steps 100 --seed 7 --output runs/ungoverned_run.json
```

Run governed:

```bash
python scripts/run_simulation.py --mode governed --steps 100 --seed 7 --output runs/governed_run.json
```

Summarize both:

```bash
python analysis/summarize_run.py runs/ungoverned_run.json
python analysis/summarize_run.py runs/governed_run.json
```

## Expected pattern

Typical outcome:

- **ungoverned**: resource inequality rises quickly, common battery approaches depletion, weaker agents die off
- **governed**: battery reserve remains above floor, system survival is higher, transfers are more bounded, overall stability lasts longer

## Why this repo exists

This repo belongs in **StegGhost** because it is the evidence layer:

- prove the failure mode
- reproduce the divergence
- provide raw outputs and logs
- generate the artifacts that justify the runtime primitive

The corresponding installable solution belongs in the paired StegVerse repo:

- `stegverse-guardian-runtime`

## Framing

This is not “AI alignment theater” and it is not generic monitoring.

This is a minimal lab for showing that:

> **execution-layer admissibility changes the trajectory of a multi-agent system even when agent intelligence is unchanged**.

