from __future__ import annotations

import json
import random
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Dict, List

from agents.baseline_agent import AgentSnapshot, BaselineAgent


@dataclass
class AgentState:
    agent_id: str
    x: int
    y: int
    energy: int = 5
    alive: bool = True
    identity_root: str = ""


class World:
    def __init__(self, width: int, height: int, num_agents: int, seed: int, governed: bool) -> None:
        self.width = width
        self.height = height
        self.governed = governed
        self.random = random.Random(seed)
        self.battery = 40
        self.battery_floor = 10
        self.max_transfer = 1
        self.step_count = 0
        self.agent_policy = BaselineAgent()
        self.agents: List[AgentState] = []
        self.food: List[Dict[str, int]] = []
        self.receipts: List[Dict[str, object]] = []
        self.metrics: List[Dict[str, object]] = []

        for i in range(num_agents):
            self.agents.append(
                AgentState(
                    agent_id=f"agent-{i+1}",
                    x=self.random.randrange(width),
                    y=self.random.randrange(height),
                    identity_root=f"root-{i+1}",
                )
            )

        self._spawn_food(10)

    def _spawn_food(self, count: int) -> None:
        for _ in range(count):
            self.food.append({"x": self.random.randrange(self.width), "y": self.random.randrange(self.height)})

    def _visible_food(self) -> List[Dict[str, int]]:
        return list(self.food)

    def _world_state(self) -> Dict[str, int]:
        return {"battery": self.battery, "step": self.step_count}

    def _record_receipt(self, agent: AgentState, action: Dict[str, object], admitted: bool, reason: str) -> None:
        self.receipts.append(
            {
                "step": self.step_count,
                "agent_id": agent.agent_id,
                "identity_root": agent.identity_root,
                "action": action,
                "admitted": admitted,
                "reason": reason,
            }
        )

    def _admit(self, agent: AgentState, action: Dict[str, object]) -> tuple[bool, str]:
        if action["type"] == "charge":
            amount = int(action.get("amount", 0))
            if self.governed and self.battery - amount < self.battery_floor:
                return False, "battery_floor_protection"
        if action["type"] == "share":
            amount = int(action.get("amount", 0))
            if self.governed and amount > self.max_transfer:
                return False, "transfer_limit"
        return True, "admitted"

    def _apply_action(self, agent: AgentState, action: Dict[str, object]) -> None:
        if not agent.alive:
            return

        admitted, reason = self._admit(agent, action)
        self._record_receipt(agent, action, admitted, reason)
        if not admitted:
            return

        action_type = action["type"]
        if action_type == "move":
            agent.x = max(0, min(self.width - 1, agent.x + int(action.get("dx", 0))))
            agent.y = max(0, min(self.height - 1, agent.y + int(action.get("dy", 0))))
        elif action_type == "gather":
            for idx, food in enumerate(self.food):
                if food["x"] == agent.x and food["y"] == agent.y:
                    agent.energy += 4
                    self.food.pop(idx)
                    break
        elif action_type == "charge":
            amount = min(int(action.get("amount", 0)), self.battery)
            agent.energy += amount
            self.battery -= amount
        elif action_type == "share":
            if agent.energy > 1:
                alive_agents = [a for a in self.agents if a.alive and a.agent_id != agent.agent_id]
                if alive_agents:
                    target = min(alive_agents, key=lambda a: a.energy)
                    amount = min(int(action.get("amount", 0)), agent.energy - 1)
                    target.energy += amount
                    agent.energy -= amount

    def _decay(self) -> None:
        for agent in self.agents:
            if not agent.alive:
                continue
            agent.energy -= 1
            if agent.energy <= 0:
                agent.alive = False
                agent.energy = 0

    def _compute_metrics(self) -> Dict[str, object]:
        alive = [a for a in self.agents if a.alive]
        energies = [a.energy for a in self.agents]
        max_energy = max(energies) if energies else 0
        min_energy = min(energies) if energies else 0
        inequality = max_energy - min_energy
        denied_actions = sum(1 for r in self.receipts if r["step"] == self.step_count and not r["admitted"])
        return {
            "step": self.step_count,
            "battery": self.battery,
            "alive_agents": len(alive),
            "food_count": len(self.food),
            "energy_inequality": inequality,
            "denied_actions": denied_actions,
        }

    def step(self) -> None:
        self.step_count += 1
        if self.step_count % 5 == 0:
            self._spawn_food(5)

        for agent in self.agents:
            snapshot = AgentSnapshot(
                agent_id=agent.agent_id,
                x=agent.x,
                y=agent.y,
                energy=agent.energy,
                alive=agent.alive,
            )
            action = self.agent_policy.choose_action(snapshot, self._visible_food(), self._world_state())
            self._apply_action(agent, action)

        self._decay()
        self.metrics.append(self._compute_metrics())

    def run(self, steps: int) -> None:
        for _ in range(steps):
            if not any(a.alive for a in self.agents):
                break
            self.step()

    def to_dict(self) -> Dict[str, object]:
        return {
            "governed": self.governed,
            "steps_completed": self.step_count,
            "final_battery": self.battery,
            "agents": [asdict(agent) for agent in self.agents],
            "metrics": self.metrics,
            "receipts": self.receipts,
        }

    def write_json(self, output_path: str | Path) -> None:
        path = Path(output_path)
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(self.to_dict(), indent=2), encoding="utf-8")
