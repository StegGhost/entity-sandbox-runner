from __future__ import annotations

import argparse
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from env.world import World


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Run a governed or ungoverned simulation.")
    parser.add_argument("--mode", choices=["ungoverned", "governed"], required=True)
    parser.add_argument("--steps", type=int, default=100)
    parser.add_argument("--seed", type=int, default=7)
    parser.add_argument("--agents", type=int, default=8)
    parser.add_argument("--width", type=int, default=8)
    parser.add_argument("--height", type=int, default=8)
    parser.add_argument("--output", required=True)
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    world = World(
        width=args.width,
        height=args.height,
        num_agents=args.agents,
        seed=args.seed,
        governed=args.mode == "governed",
    )
    world.run(args.steps)
    world.write_json(args.output)
    final = world.to_dict()
    alive_agents = sum(1 for agent in final["agents"] if agent["alive"])
    print(f"mode={args.mode}")
    print(f"steps_completed={final['steps_completed']}")
    print(f"final_battery={final['final_battery']}")
    print(f"alive_agents={alive_agents}")
    print(f"output={args.output}")


if __name__ == "__main__":
    main()
