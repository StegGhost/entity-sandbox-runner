from __future__ import annotations

import json
import statistics
import sys
from pathlib import Path


def main(path_str: str) -> None:
    path = Path(path_str)
    data = json.loads(path.read_text(encoding="utf-8"))
    metrics = data.get("metrics", [])
    receipts = data.get("receipts", [])
    final_agents = data.get("agents", [])

    alive_agents = sum(1 for a in final_agents if a["alive"])
    inequalities = [m["energy_inequality"] for m in metrics] or [0]
    denied = sum(1 for r in receipts if not r["admitted"])

    print(f"file={path}")
    print(f"governed={data['governed']}")
    print(f"steps_completed={data['steps_completed']}")
    print(f"final_battery={data['final_battery']}")
    print(f"alive_agents={alive_agents}/{len(final_agents)}")
    print(f"mean_energy_inequality={statistics.mean(inequalities):.2f}")
    print(f"max_energy_inequality={max(inequalities)}")
    print(f"denied_actions={denied}")


if __name__ == "__main__":
    if len(sys.argv) != 2:
        raise SystemExit("Usage: python analysis/summarize_run.py <run.json>")
    main(sys.argv[1])
