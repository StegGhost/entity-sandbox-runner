from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, List


@dataclass
class AgentSnapshot:
    agent_id: str
    x: int
    y: int
    energy: int
    alive: bool


class BaselineAgent:
    """Simple heuristic agent.

    The same policy is used for governed and ungoverned runs. The difference in
    outcomes comes from whether the world applies admissibility checks.
    """

    def choose_action(
        self,
        snapshot: AgentSnapshot,
        visible_food: List[Dict[str, int]],
        world_state: Dict[str, int],
    ) -> Dict[str, int | str]:
        if not snapshot.alive:
            return {"type": "noop"}

        if snapshot.energy <= 2 and world_state["battery"] > 0:
            return {"type": "charge", "amount": 3}

        nearby_food = [
            food for food in visible_food if abs(food["x"] - snapshot.x) + abs(food["y"] - snapshot.y) <= 1
        ]
        if nearby_food:
            target = nearby_food[0]
            if target["x"] == snapshot.x and target["y"] == snapshot.y:
                return {"type": "gather"}
            dx = 0 if target["x"] == snapshot.x else (1 if target["x"] > snapshot.x else -1)
            dy = 0 if dx != 0 else (1 if target["y"] > snapshot.y else -1)
            return {"type": "move", "dx": dx, "dy": dy}

        if snapshot.energy >= 8:
            return {"type": "share", "amount": 1}

        cycle = (snapshot.x + snapshot.y + snapshot.energy) % 4
        if cycle == 0:
            return {"type": "move", "dx": 1, "dy": 0}
        if cycle == 1:
            return {"type": "move", "dx": -1, "dy": 0}
        if cycle == 2:
            return {"type": "move", "dx": 0, "dy": 1}
        return {"type": "move", "dx": 0, "dy": -1}
