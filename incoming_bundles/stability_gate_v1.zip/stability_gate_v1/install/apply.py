import os
import shutil

BASE_DIR = os.getcwd()

def _copy_tree(src_dir: str, dst_dir: str) -> None:
    os.makedirs(dst_dir, exist_ok=True)
    for name in os.listdir(src_dir):
        src = os.path.join(src_dir, name)
        dst = os.path.join(dst_dir, name)
        if os.path.isdir(src):
            if os.path.exists(dst):
                shutil.rmtree(dst)
            shutil.copytree(src, dst)
        else:
            shutil.copy2(src, dst)

def apply_bundle() -> None:
    print("[stability_gate v1] Applying bundle...")

    _copy_tree(os.path.join(BASE_DIR, "install", "engine"), os.path.join(BASE_DIR, "engine"))
    print("[stability_gate v1] Engine installed.")

    _copy_tree(os.path.join(BASE_DIR, "install", "tests"), os.path.join(BASE_DIR, "tests"))
    print("[stability_gate v1] Tests installed.")

    print("[stability_gate v1] Bundle applied successfully.")

if __name__ == "__main__":
    apply_bundle()
