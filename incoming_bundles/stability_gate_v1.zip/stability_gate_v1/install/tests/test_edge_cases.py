from engine.state_model import SystemState
from engine.stability_guard import compute_stability_score

def test_zero_denominator():
    state = SystemState(1.0, 1.0, 0.0, 1.0)
    score = compute_stability_score(state)
    assert score == float("inf")
