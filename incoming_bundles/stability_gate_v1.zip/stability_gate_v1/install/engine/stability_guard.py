from .state_model import SystemState

def compute_stability_score(state: SystemState) -> float:
    denominator = state.env_volatility * state.action_magnitude
    if denominator == 0:
        return float("inf")
    return (state.deliberation_time * state.model_fidelity) / denominator
