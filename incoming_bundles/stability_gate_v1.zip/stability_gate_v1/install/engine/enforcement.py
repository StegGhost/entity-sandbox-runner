from .stability_guard import compute_stability_score

def enforce_action(state, threshold: float = 1.0):
    score = compute_stability_score(state)

    if score >= threshold:
        return {
            "status": "allowed",
            "stability_score": score
        }

    if score >= 0.7:
        return {
            "status": "delay",
            "stability_score": score,
            "action": "increase_deliberation"
        }

    return {
        "status": "blocked",
        "stability_score": score,
        "action": "escalate_or_abort"
    }
