from dataclasses import dataclass

@dataclass
class SystemState:
    deliberation_time: float
    model_fidelity: float
    env_volatility: float
    action_magnitude: float
