# v2.0 Multi-Agent Governance Fabric
Adds negotiation, conflict resolution, and agent ranking.