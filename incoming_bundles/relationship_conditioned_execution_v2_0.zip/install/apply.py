from agent_registry import AgentRegistry
from conflict_detector import ConflictDetector
from negotiation_engine import NegotiationEngine
from incentive_model import IncentiveModel
from governance_fabric import GovernanceFabric

registry = AgentRegistry()
detector = ConflictDetector()
negotiator = NegotiationEngine()
incentive = IncentiveModel()
fabric = GovernanceFabric(registry, incentive)

def apply(proposals, agent_profiles):
    for agent_id, profile in agent_profiles.items():
        registry.register(agent_id, profile)

    conflicts = detector.detect(proposals)

    if conflicts:
        resolved = negotiator.resolve(conflicts)
    else:
        resolved = proposals

    ranked_agents = fabric.rank_agents()

    return {
        "resolved_actions": resolved,
        "agent_ranking": ranked_agents
    }
