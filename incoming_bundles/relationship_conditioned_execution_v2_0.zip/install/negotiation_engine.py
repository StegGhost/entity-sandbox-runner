class NegotiationEngine:
    def resolve(self, conflicts):
        resolutions = []
        for a, b in conflicts:
            if a.get("priority", 0) >= b.get("priority", 0):
                resolutions.append(a)
            else:
                resolutions.append(b)
        return resolutions
