class ConflictDetector:
    def detect(self, proposals):
        conflicts = []
        for i in range(len(proposals)):
            for j in range(i+1, len(proposals)):
                if proposals[i].get("target") == proposals[j].get("target"):
                    conflicts.append((proposals[i], proposals[j]))
        return conflicts
