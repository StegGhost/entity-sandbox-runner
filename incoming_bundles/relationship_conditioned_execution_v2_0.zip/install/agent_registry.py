class AgentRegistry:
    def __init__(self):
        self.agents = {}
    def register(self, agent_id, profile):
        self.agents[agent_id] = profile
    def get_all(self):
        return self.agents
