class GovernanceFabric:
    def __init__(self, registry, incentive):
        self.registry = registry
        self.incentive = incentive
    def rank_agents(self):
        agents = self.registry.get_all()
        return sorted(
            agents.items(),
            key=lambda x: self.incentive.evaluate(x[1]),
            reverse=True
        )
