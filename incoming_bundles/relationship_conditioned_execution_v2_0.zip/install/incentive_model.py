class IncentiveModel:
    def evaluate(self, agent_profile):
        return agent_profile.get("reputation", 0.5)
