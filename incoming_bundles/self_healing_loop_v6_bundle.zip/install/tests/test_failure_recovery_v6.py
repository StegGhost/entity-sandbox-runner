from install.engine.failure_recovery_v6 import classify_failure, generate_fix_plan

def test_classify():
    f = {"reason": "capability_violation"}
    assert classify_failure(f) == "path_policy_mismatch"

def test_plan():
    f = {"reason": "capability_violation"}
    plan = generate_fix_plan(f)
    assert "action" in plan
