from install.engine.failure_recovery_v6 import classify_failure, generate_fix_plan, apply_fix_plan

def run_self_heal(failure_result, bundle_files):
    classification = classify_failure(failure_result)
    plan = generate_fix_plan(failure_result)
    fixed_bundle = apply_fix_plan(plan, bundle_files)

    return {
        "classification": classification,
        "plan": plan,
        "fixed_bundle_files": fixed_bundle
    }
