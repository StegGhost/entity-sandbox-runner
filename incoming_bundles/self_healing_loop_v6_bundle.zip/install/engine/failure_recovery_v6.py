import json

def classify_failure(failure):
    reason = failure.get("reason", "")
    if reason == "capability_violation":
        return "path_policy_mismatch"
    if reason == "manifest_missing_required_fields":
        return "manifest_error"
    return "unknown"

def generate_fix_plan(failure):
    classification = classify_failure(failure)
    if classification == "path_policy_mismatch":
        return {"action": "relocate_or_remove_disallowed_files"}
    if classification == "manifest_error":
        return {"action": "repair_manifest"}
    return {"action": "manual_review"}

def apply_fix_plan(plan, bundle_files):
    fixed = []
    if plan["action"] == "relocate_or_remove_disallowed_files":
        for f in bundle_files:
            if "install/apply.py" in f:
                continue
            fixed.append(f)
    else:
        fixed = bundle_files
    return fixed
