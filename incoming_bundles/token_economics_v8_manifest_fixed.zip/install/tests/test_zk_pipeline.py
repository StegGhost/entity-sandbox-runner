
from install.engine.zk_prover_engine import prove
from install.engine.zk_verifier_engine import verify

def test_zk_pipeline():
    data = {"a": 1}
    p = prove(data)
    assert verify(data, p) is True
