
from install.engine.identity_staking_engine import IdentityAccount, stake_weight

def test_identity_staking():
    i = IdentityAccount("agent_1")
    i.deposit(100)
    i.reputation = 50
    assert stake_weight(i) > 100
