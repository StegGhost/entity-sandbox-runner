
from install.engine.rl_agent_engine import RLAgent

def test_rl_agent():
    agent = RLAgent()
    a = agent.act()
    q = agent.learn(a, 5)
    assert isinstance(q, dict)
