
class IdentityAccount:
    def __init__(self, agent_id):
        self.agent_id = agent_id
        self.stake = 0
        self.reputation = 0

    def deposit(self, amount):
        self.stake += amount

    def slash(self, amount):
        self.stake = max(0, self.stake - amount)

def stake_weight(identity):
    # stake-weighted identity influence
    return identity.stake * (1 + identity.reputation / 100)

def sybil_check(identities):
    # naive: duplicate agent_id detection
    ids = [i.agent_id for i in identities]
    return len(ids) != len(set(ids))
