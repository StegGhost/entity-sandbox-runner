
import hashlib
from install.engine.zk_circuit_engine import Circuit

def prove(data):
    circuit = Circuit()
    witness = circuit.compute_witness(data)
    # Proof is commitment to witness (toy; replace with SNARK/STARK later)
    proof = hashlib.sha256((witness["witness_hash"]).encode()).hexdigest()
    public_inputs = hashlib.sha256(str(data).encode()).hexdigest()
    return {"proof": proof, "public_inputs": public_inputs}
