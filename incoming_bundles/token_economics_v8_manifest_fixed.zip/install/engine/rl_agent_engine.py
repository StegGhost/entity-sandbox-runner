
import random
from install.engine.rl_environment import ACTIONS

class RLAgent:
    def __init__(self, lr=0.001, gamma=0.99, eps=1.0, eps_min=0.05, eps_decay=0.995):
        self.q = {a: 0.0 for a in ACTIONS}
        self.lr = lr
        self.gamma = gamma
        self.eps = eps
        self.eps_min = eps_min
        self.eps_decay = eps_decay

    def act(self):
        if random.random() < self.eps:
            return random.choice(ACTIONS)
        return max(self.q, key=self.q.get)

    def learn(self, action, reward):
        # single-state bandit-style update
        self.q[action] = self.q[action] + self.lr * (reward - self.q[action])
        self.eps = max(self.eps_min, self.eps * self.eps_decay)
        return self.q
