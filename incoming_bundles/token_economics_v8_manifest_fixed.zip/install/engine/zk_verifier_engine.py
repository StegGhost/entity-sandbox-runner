
import hashlib
from install.engine.zk_circuit_engine import Circuit

def verify(data, proof_obj):
    circuit = Circuit()
    # Recompute expected public input
    expected_pi = hashlib.sha256(str(data).encode()).hexdigest()
    if proof_obj.get("public_inputs") != expected_pi:
        return False
    # Reconstruct expected proof from constraints
    witness_hash = hashlib.sha256(str(data).encode()).hexdigest()
    expected_proof = hashlib.sha256(witness_hash.encode()).hexdigest()
    return proof_obj.get("proof") == expected_proof
