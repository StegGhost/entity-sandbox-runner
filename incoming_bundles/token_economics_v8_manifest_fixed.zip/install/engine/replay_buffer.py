
import random

class ReplayBuffer:
    def __init__(self, size=1000):
        self.size = size
        self.buf = []

    def add(self, transition):
        if len(self.buf) >= self.size:
            self.buf.pop(0)
        self.buf.append(transition)

    def sample(self, batch_size=32):
        return random.sample(self.buf, min(len(self.buf), batch_size))
