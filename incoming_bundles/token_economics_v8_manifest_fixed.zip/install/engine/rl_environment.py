
import random

ACTIONS = ["low_risk", "high_risk"]

class Environment:
    def step(self, action):
        if action == "high_risk":
            reward = random.choice([10, -10, 20, -20])
        else:
            reward = random.choice([2, 1, 3])
        next_state = None
        done = False
        return next_state, reward, done
