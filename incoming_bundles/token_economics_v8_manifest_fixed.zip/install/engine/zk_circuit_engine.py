
import hashlib

class Circuit:
    def __init__(self, name="constraint_system_v1"):
        self.name = name

    def compute_witness(self, data):
        # Witness is deterministic hash chain over data
        h = hashlib.sha256(str(data).encode()).hexdigest()
        return {"witness_hash": h}

    def constraints_satisfied(self, data, witness):
        expected = hashlib.sha256(str(data).encode()).hexdigest()
        return witness.get("witness_hash") == expected
