import json
import hashlib

def canonical_json(data):
    return json.dumps(data, sort_keys=True, separators=(",", ":"))

def hash_data(data):
    return hashlib.sha256(canonical_json(data).encode()).hexdigest()

def verify_passport(passport):
    required = ["standard", "version", "agent", "capabilities", "public_key", "signature"]
    for r in required:
        if r not in passport:
            return False, f"missing_{r}"
    return True, "valid_structure"

def verify_receipt_chain(chain):
    prev = "GENESIS"
    for r in chain:
        core = {
            "timestamp": r["timestamp"],
            "passport_hash": r["passport_hash"],
            "action": r["action"],
            "result": r["result"],
            "previous_hash": r["previous_hash"]
        }
        expected = hash_data(core)
        if r["receipt_hash"] != expected:
            return False, "hash_mismatch"
        if r["previous_hash"] != prev:
            return False, "chain_break"
        prev = r["receipt_hash"]
    return True, "valid_chain"

def verify_agent(agent_bundle):
    passport = agent_bundle.get("passport")
    receipts = agent_bundle.get("receipts", [])

    p_ok, p_reason = verify_passport(passport)
    if not p_ok:
        return False, {"stage": "passport", "reason": p_reason}

    c_ok, c_reason = verify_receipt_chain(receipts)
    if not c_ok:
        return False, {"stage": "receipt_chain", "reason": c_reason}

    return True, {"stage": "complete", "reason": "verified"}
