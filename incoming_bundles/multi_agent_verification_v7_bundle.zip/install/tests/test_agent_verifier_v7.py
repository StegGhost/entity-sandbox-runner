from install.engine.agent_verifier_v7 import verify_agent

def test_verify_agent_success():
    agent = {
        "passport": {
            "standard": "x",
            "version": "1",
            "agent": {},
            "capabilities": [],
            "public_key": "k",
            "signature": "s"
        },
        "receipts": []
    }
    ok, info = verify_agent(agent)
    assert ok is True

def test_verify_agent_fail_passport():
    agent = {"passport": {}, "receipts": []}
    ok, info = verify_agent(agent)
    assert ok is False
