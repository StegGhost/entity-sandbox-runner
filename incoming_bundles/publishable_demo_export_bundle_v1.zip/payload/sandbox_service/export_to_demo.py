import json, shutil
from pathlib import Path

SRC = Path("experiments/critical_ratio_campaign")
DEST = Path("demo_export/latest")

def main():
    DEST.mkdir(parents=True, exist_ok=True)

    for file in [
        "results/merge_summary.json",
        "results/validation_report.json"
    ]:
        src_file = SRC / file
        if src_file.exists():
            shutil.copy2(src_file, DEST / Path(file).name)

    print("Demo export ready:", DEST)

if __name__ == "__main__":
    main()
