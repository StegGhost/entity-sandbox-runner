# Critical Ratio Experiment (Demo)

## Summary
This experiment evaluates a proposed stability invariant:

U = (capacity * continuity) / (pressure * constraints)

## Outputs
- merge_summary.json
- validation_report.json

## Claim
System transitions occur near U ≈ 1

## Reproduce
Run GitHub workflow: Run Experiment
