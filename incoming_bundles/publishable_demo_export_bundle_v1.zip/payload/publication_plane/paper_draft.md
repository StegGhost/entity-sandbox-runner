# Critical Ratio Stability Paper (Preprint)

## Abstract
We investigate a proposed invariant U = (capacity * continuity) / (pressure * constraints)
and evaluate its role as a phase-transition boundary.

## Method
Distributed Monte Carlo sampling with adaptive boundary targeting.

## Results
See results/merge_summary.json

## Claim
System stability occurs when U > 1.

## Reproducibility
All runs generated via deterministic seeds and shard execution.

