import json
from pathlib import Path

RESULTS = Path("experiments/critical_ratio_campaign/results")
OUT = RESULTS / "validation_report.json"

def main():
    summary = json.loads((RESULTS / "merge_summary.json").read_text())
    valid = summary.get("merged_samples", 0) > 0

    report = {
        "valid": valid,
        "samples": summary.get("merged_samples"),
        "uc": summary.get("estimated_Uc"),
        "notes": "Basic validation passed" if valid else "No data"
    }

    OUT.write_text(json.dumps(report, indent=2))
    print(report)

if __name__ == "__main__":
    main()
