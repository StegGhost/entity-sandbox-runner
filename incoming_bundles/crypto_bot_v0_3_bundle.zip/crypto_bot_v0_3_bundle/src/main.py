from .engine import MicroMakerEngine


def main() -> None:
    engine = MicroMakerEngine()
    engine.run()


if __name__ == "__main__":
    main()
