from __future__ import annotations

import time
from .state import EngineState


class RiskManager:
    def __init__(
        self,
        max_daily_realized_loss_usd: float,
        cooldown_seconds: int,
        max_hold_seconds: int,
        max_spread_usd: float,
        heartbeat_timeout_seconds: int,
    ) -> None:
        self.max_daily_realized_loss_usd = max_daily_realized_loss_usd
        self.cooldown_seconds = cooldown_seconds
        self.max_hold_seconds = max_hold_seconds
        self.max_spread_usd = max_spread_usd
        self.heartbeat_timeout_seconds = heartbeat_timeout_seconds

    def can_enter(self, state: EngineState) -> tuple[bool, str]:
        now = time.time()
        if state.position is not None or state.entry_order is not None or state.exit_order is not None:
            return False, "inventory_or_orders_present"
        if state.market.best_bid is None or state.market.best_ask is None:
            return False, "no_market"
        if state.market.spread is None or state.market.spread > self.max_spread_usd:
            return False, "spread_too_wide"
        if now - state.market.last_update_ts > self.heartbeat_timeout_seconds:
            return False, "stale_market"
        if state.realized_pnl_usd <= -abs(self.max_daily_realized_loss_usd):
            return False, "daily_loss_limit"
        if (now - state.last_trade_ts) < self.cooldown_seconds:
            return False, "cooldown"
        return True, "ok"

    def should_force_exit(self, state: EngineState) -> tuple[bool, str]:
        if state.position is None:
            return False, "no_position"
        age = time.time() - state.position.opened_ts
        if age > self.max_hold_seconds:
            return True, "max_hold_exceeded"
        return False, "ok"
