from __future__ import annotations

from .state import Position


def calc_base_size(price: float, trade_size_usd: float, precision: int) -> float:
    raw = trade_size_usd / price
    return round(raw, precision)


def calc_entry_fee(entry_price: float, size: float, fee_rate: float) -> float:
    return entry_price * size * fee_rate


def calc_exit_fee(exit_price: float, size: float, fee_rate: float) -> float:
    return exit_price * size * fee_rate


def calc_net_profit(position: Position, exit_price: float, exit_fee_rate: float, slippage_buffer_usd: float) -> float:
    gross = (exit_price - position.entry_price) * position.size
    exit_fee = calc_exit_fee(exit_price, position.size, exit_fee_rate)
    return gross - position.entry_fee - exit_fee - slippage_buffer_usd


def calc_min_profitable_exit_price(
    position: Position,
    target_profit_usd: float,
    exit_fee_rate: float,
    slippage_buffer_usd: float,
) -> float:
    numerator = (
        target_profit_usd
        + position.entry_fee
        + slippage_buffer_usd
        + (position.entry_price * position.size)
    )
    denominator = position.size * (1.0 - exit_fee_rate)
    return numerator / denominator
