from __future__ import annotations

import json
import math
import time
import uuid
from typing import Any, Optional

from coinbase.rest import RESTClient
from coinbase.websocket import WSClient, WSUserClient

from . import config
from .ledger import (
    calc_base_size,
    calc_entry_fee,
    calc_min_profitable_exit_price,
    calc_net_profit,
)
from .risk import RiskManager
from .state import EngineState, PendingOrder, Position


class ExecutionAdapter:
    def __init__(self, rest: Optional[RESTClient]) -> None:
        self.rest = rest

    def place_limit_buy(self, product_id: str, price: float, size: float, client_order_id: str) -> dict[str, Any]:
        if config.DRY_RUN:
            return {"success": True, "order_id": f"dry-buy-{client_order_id}"}
        assert self.rest is not None
        return self.rest.limit_order_gtc_buy(
            client_order_id=client_order_id,
            product_id=product_id,
            base_size=str(size),
            limit_price=str(price),
            post_only=True,
        )

    def place_limit_sell(self, product_id: str, price: float, size: float, client_order_id: str) -> dict[str, Any]:
        if config.DRY_RUN:
            return {"success": True, "order_id": f"dry-sell-{client_order_id}"}
        assert self.rest is not None
        return self.rest.limit_order_gtc_sell(
            client_order_id=client_order_id,
            product_id=product_id,
            base_size=str(size),
            limit_price=str(price),
            post_only=True,
        )

    def cancel_orders(self, order_ids: list[str]) -> dict[str, Any]:
        if config.DRY_RUN:
            return {"success": True, "results": [{"success": True, "order_id": oid} for oid in order_ids]}
        assert self.rest is not None
        return self.rest.cancel_orders(order_ids=order_ids)


class MicroMakerEngine:
    def __init__(self) -> None:
        self.state = EngineState()
        self.rest = RESTClient(api_key=config.API_KEY, api_secret=config.API_SECRET, verbose=config.VERBOSE)
        self.exec = ExecutionAdapter(None if config.DRY_RUN else self.rest)
        self.risk = RiskManager(
            max_daily_realized_loss_usd=config.MAX_DAILY_REALIZED_LOSS_USD,
            cooldown_seconds=config.COOLDOWN_SECONDS,
            max_hold_seconds=config.MAX_HOLD_SECONDS,
            max_spread_usd=config.MAX_SPREAD_USD,
            heartbeat_timeout_seconds=config.HEARTBEAT_TIMEOUT_SECONDS,
        )
        self.ws_market: Optional[WSClient] = None
        self.ws_user: Optional[WSUserClient] = None

    def _round_price(self, price: float) -> float:
        ticks = round(price / config.TICK_SIZE)
        return round(ticks * config.TICK_SIZE, config.PRICE_PRECISION)

    def _log(self, msg: str) -> None:
        print(msg, flush=True)

    def _new_client_order_id(self, prefix: str) -> str:
        return f"{prefix}-{uuid.uuid4().hex[:16]}"

    def on_market_message(self, raw: str) -> None:
        data = json.loads(raw)
        if data.get("channel") not in {"ticker", "heartbeats"}:
            return
        for event in data.get("events", []):
            for t in event.get("tickers", []):
                if t.get("product_id") != config.PRODUCT_ID:
                    continue
                bid = t.get("best_bid")
                ask = t.get("best_ask")
                if bid is not None and ask is not None:
                    self.state.market.best_bid = float(bid)
                    self.state.market.best_ask = float(ask)
                    self.state.market.last_update_ts = time.time()
        self.maybe_trade()

    def on_user_message(self, raw: str) -> None:
        data = json.loads(raw)
        if data.get("channel") != "user":
            return
        for event in data.get("events", []):
            for order in event.get("orders", []):
                self._process_user_order_update(order)
        self.maybe_trade()

    def _process_user_order_update(self, order: dict[str, Any]) -> None:
        order_id = order.get("order_id")
        status = order.get("status", "")
        filled_size = float(order.get("filled_size", 0) or 0)
        avg_price = float(order.get("average_filled_price", 0) or 0)

        if self.state.entry_order and order_id == self.state.entry_order.order_id:
            self.state.entry_order.status = status
            if status == "FILLED" and filled_size > 0 and avg_price > 0:
                entry_fee = calc_entry_fee(avg_price, filled_size, config.ENTRY_FEE_RATE)
                self.state.position = Position(
                    entry_price=avg_price,
                    size=filled_size,
                    entry_fee=entry_fee,
                    entry_order_id=order_id,
                )
                self.state.entry_order = None
                self._log(f"ENTRY FILLED price={avg_price:.2f} size={filled_size:.8f} fee={entry_fee:.4f}")
                self.place_exit_if_ready()
            elif status in {"CANCELLED", "EXPIRED", "FAILED"}:
                self._log(f"ENTRY CLOSED status={status}")
                self.state.entry_order = None

        if self.state.exit_order and order_id == self.state.exit_order.order_id:
            self.state.exit_order.status = status
            if status == "FILLED" and filled_size > 0 and avg_price > 0 and self.state.position is not None:
                pnl = calc_net_profit(
                    self.state.position,
                    avg_price,
                    config.EXIT_FEE_RATE,
                    config.SLIPPAGE_BUFFER_USD,
                )
                self.state.realized_pnl_usd += pnl
                self.state.last_trade_ts = time.time()
                self._log(f"EXIT FILLED price={avg_price:.2f} size={filled_size:.8f} net_pnl={pnl:.4f} realized={self.state.realized_pnl_usd:.4f}")
                self.state.position = None
                self.state.exit_order = None
            elif status in {"CANCELLED", "EXPIRED", "FAILED"}:
                self._log(f"EXIT CLOSED status={status}")
                self.state.exit_order = None

    def maybe_trade(self) -> None:
        can_enter, reason = self.risk.can_enter(self.state)
        if can_enter:
            self.place_entry()
            return

        if self.state.position is not None and self.state.exit_order is None:
            force_exit, why = self.risk.should_force_exit(self.state)
            if force_exit:
                self._log(f"FORCE EXIT reason={why}")
                self.place_exit(force=True)
            else:
                self.place_exit_if_ready()

        self.cancel_stale_orders()

    def place_entry(self) -> None:
        bid = self.state.market.best_bid
        ask = self.state.market.best_ask
        if bid is None or ask is None:
            return
        entry_price = self._round_price(min(bid, ask - config.ENTRY_OFFSET_TICKS))
        size = calc_base_size(entry_price, config.TRADE_SIZE_USD, config.BASE_SIZE_PRECISION)
        if size <= 0:
            return
        coid = self._new_client_order_id("entry")
        result = self.exec.place_limit_buy(config.PRODUCT_ID, entry_price, size, coid)
        if result.get("success"):
            order_id = result.get("order_id")
            self.state.entry_order = PendingOrder(
                client_order_id=coid,
                side="BUY",
                price=entry_price,
                size=size,
                order_id=order_id,
                status="OPEN",
            )
            self._log(f"ENTRY ORDER price={entry_price:.2f} size={size:.8f} order_id={order_id}")
            if config.DRY_RUN:
                # Immediate simulated fill at entry price.
                self._process_user_order_update({
                    "order_id": order_id,
                    "status": "FILLED",
                    "filled_size": str(size),
                    "average_filled_price": str(entry_price),
                })
        else:
            self._log(f"ENTRY FAILED {result}")

    def place_exit_if_ready(self) -> None:
        if self.state.position is None or self.state.exit_order is not None:
            return
        min_exit = calc_min_profitable_exit_price(
            self.state.position,
            config.PROFIT_TARGET_USD,
            config.EXIT_FEE_RATE,
            config.SLIPPAGE_BUFFER_USD,
        )
        bid = self.state.market.best_bid
        ask = self.state.market.best_ask
        if bid is None or ask is None:
            return
        desired = max(min_exit, ask + config.EXIT_OFFSET_TICKS)
        desired = self._round_price(desired)
        # In dry-run, only simulate profitable fill once market could plausibly cross it.
        if bid >= min_exit:
            self.place_exit(force=False, override_price=desired)

    def place_exit(self, force: bool = False, override_price: Optional[float] = None) -> None:
        if self.state.position is None or self.state.exit_order is not None:
            return
        bid = self.state.market.best_bid
        ask = self.state.market.best_ask
        if bid is None or ask is None:
            return
        if override_price is not None:
            exit_price = override_price
        elif force:
            exit_price = self._round_price(max(bid, ask - config.EXIT_OFFSET_TICKS))
        else:
            min_exit = calc_min_profitable_exit_price(
                self.state.position,
                config.PROFIT_TARGET_USD,
                config.EXIT_FEE_RATE,
                config.SLIPPAGE_BUFFER_USD,
            )
            exit_price = self._round_price(max(min_exit, ask + config.EXIT_OFFSET_TICKS))
        coid = self._new_client_order_id("exit")
        result = self.exec.place_limit_sell(config.PRODUCT_ID, exit_price, self.state.position.size, coid)
        if result.get("success"):
            order_id = result.get("order_id")
            self.state.exit_order = PendingOrder(
                client_order_id=coid,
                side="SELL",
                price=exit_price,
                size=self.state.position.size,
                order_id=order_id,
                status="OPEN",
            )
            self._log(f"EXIT ORDER price={exit_price:.2f} size={self.state.position.size:.8f} order_id={order_id}")
            if config.DRY_RUN:
                simulated_fill_price = exit_price if not force else max(bid, exit_price)
                self._process_user_order_update({
                    "order_id": order_id,
                    "status": "FILLED",
                    "filled_size": str(self.state.position.size),
                    "average_filled_price": str(simulated_fill_price),
                })
        else:
            self._log(f"EXIT FAILED {result}")

    def cancel_stale_orders(self) -> None:
        now = time.time()
        if self.state.entry_order and (now - self.state.entry_order.created_ts) > config.ENTRY_ORDER_TTL_SECONDS:
            oid = self.state.entry_order.order_id
            if oid:
                self.exec.cancel_orders([oid])
            self._log("ENTRY CANCEL stale")
            self.state.entry_order = None
        if self.state.exit_order and (now - self.state.exit_order.created_ts) > config.EXIT_ORDER_TTL_SECONDS:
            oid = self.state.exit_order.order_id
            if oid:
                self.exec.cancel_orders([oid])
            self._log("EXIT CANCEL stale")
            self.state.exit_order = None

    def run(self) -> None:
        self.ws_market = WSClient(
            api_key=config.API_KEY,
            api_secret=config.API_SECRET,
            on_message=self.on_market_message,
            verbose=config.VERBOSE,
        )
        self.ws_user = WSUserClient(
            api_key=config.API_KEY,
            api_secret=config.API_SECRET,
            on_message=self.on_user_message,
            verbose=config.VERBOSE,
        )

        self.ws_market.open()
        self.ws_market.subscribe([config.PRODUCT_ID], ["heartbeats", "ticker"])
        self.ws_user.open()
        self.ws_user.subscribe([config.PRODUCT_ID], ["heartbeats", "user"])
        self._log(f"RUNNING product={config.PRODUCT_ID} dry_run={config.DRY_RUN}")

        try:
            while True:
                self.ws_market.sleep_with_exception_check(1)
                self.ws_user.sleep_with_exception_check(1)
                self.maybe_trade()
        finally:
            if self.ws_market:
                self.ws_market.close()
            if self.ws_user:
                self.ws_user.close()
