from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional
import time


@dataclass
class MarketState:
    best_bid: Optional[float] = None
    best_ask: Optional[float] = None
    last_update_ts: float = 0.0

    @property
    def spread(self) -> Optional[float]:
        if self.best_bid is None or self.best_ask is None:
            return None
        return self.best_ask - self.best_bid


@dataclass
class PendingOrder:
    client_order_id: str
    side: str
    price: float
    size: float
    order_id: Optional[str] = None
    created_ts: float = field(default_factory=time.time)
    status: str = "PENDING"


@dataclass
class Position:
    entry_price: float
    size: float
    entry_fee: float
    opened_ts: float = field(default_factory=time.time)
    entry_order_id: Optional[str] = None


@dataclass
class EngineState:
    market: MarketState = field(default_factory=MarketState)
    position: Optional[Position] = None
    entry_order: Optional[PendingOrder] = None
    exit_order: Optional[PendingOrder] = None
    realized_pnl_usd: float = 0.0
    last_trade_ts: float = 0.0
