from src.ledger import calc_entry_fee, calc_min_profitable_exit_price, calc_net_profit
from src.state import Position


def test_min_exit_price_hits_target_close():
    p = Position(entry_price=100.0, size=1.0, entry_fee=0.4)
    min_exit = calc_min_profitable_exit_price(p, target_profit_usd=1.0, exit_fee_rate=0.004, slippage_buffer_usd=0.25)
    net = calc_net_profit(p, min_exit, exit_fee_rate=0.004, slippage_buffer_usd=0.25)
    assert abs(net - 1.0) < 1e-6


def test_entry_fee():
    assert calc_entry_fee(200.0, 0.5, 0.004) == 0.4
