# Crypto Bot v0.3 — Coinbase Advanced Trade micro-maker

This bundle upgrades the earlier prototype with:
- Coinbase Advanced Trade Python SDK integration
- WebSocket market data + user order updates
- Order fill confirmation and reconciliation
- Post-only limit order logic
- Fee-aware minimum profitable exit price
- Dry-run by default
- Single-position risk controls

## Safety
- `DRY_RUN = true` by default
- Use API keys with **trade only** permissions and **no withdrawals**
- Start with very small notional if you enable live mode

## Files
- `src/config.py` — settings
- `src/state.py` — state models
- `src/ledger.py` — pnl math
- `src/risk.py` — risk checks
- `src/engine.py` — strategy + execution engine
- `src/main.py` — entry point
- `requirements.txt`

## Install
```bash
pip install -r requirements.txt
```

## Configure
Edit `src/config.py`:
- `API_KEY`
- `API_SECRET`
- `PRODUCT_ID`
- `DRY_RUN`

Coinbase currently documents the Advanced Trade Python SDK package as `coinbase-advanced-py`, with `RESTClient` and `WSClient`/`WSUserClient` patterns for REST and WebSocket flows. The docs also show subscribing to `ticker`, `heartbeats`, and `user` channels, which this bundle follows. citeturn231431search0

## Run
```bash
python -m src.main
```

## Notes
This is still intentionally conservative:
- one open position max
- one entry order max
- one exit order max
- timeout-based inventory escape
- optional live mode only after paper validation
