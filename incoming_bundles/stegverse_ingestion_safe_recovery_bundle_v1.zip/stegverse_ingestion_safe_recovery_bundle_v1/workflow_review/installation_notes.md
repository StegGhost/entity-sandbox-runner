# StegVerse Ingestion-Safe Recovery Bundle v1

## Included
- `bundle_manifest.json` at root with required ingestion fields
- `install/bundle_guard.py` pre-ingestion validator
- `payload/canonical_manifest_template.json`
- repaired manifests for previously failed bundles
- forward architecture notes for the next worker/self-healing phase

## Intended use
1. Drop `install/bundle_guard.py` into the sandbox ingestion path or validator stage.
2. Use the canonical template for all new bundles.
3. Replace the failed bundle manifests with the repaired versions in `payload/fixed_manifests/`.
4. Requeue the affected bundles after manifest replacement.

## Hard rule
Every bundle must include:
- `bundle_name`
- `version`
- `install_mode`
- `description`
- `allowed_paths`

## Default allowed paths
```json
[
  "install/",
  "payload/",
  "experiments/",
  "workflow_review/"
]
```

## Suggested next bundles
- `sandbox_decentralized_worker_runtime_v1`
- `sandbox_self_healing_ingestion_v1`
- `sandbox_trust_consensus_layer_v1`
