# stegverse_ingestion_safe_recovery_bundle_v1

Recovery/install bundle for failed manifests plus pre-ingestion validation.

## Quick verify
```bash
python install/bundle_guard.py .
```

## Bundle contents
- `bundle_manifest.json`
- `install/bundle_guard.py`
- `payload/canonical_manifest_template.json`
- `payload/fixed_manifests/*.bundle_manifest.json`
- `workflow_review/*.md`
