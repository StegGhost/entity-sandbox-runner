import json
import os
from typing import Dict, Tuple, Any

REQUIRED_FIELDS = [
    "bundle_name",
    "version",
    "install_mode",
    "description",
    "allowed_paths",
]

ALLOWED_ROOTS = [
    "install/",
    "payload/",
    "experiments/",
    "workflow_review/",
]


def validate_manifest(manifest_path: str) -> Tuple[bool, str]:
    if not os.path.exists(manifest_path):
        return False, "manifest_missing"

    with open(manifest_path, "r", encoding="utf-8") as f:
        try:
            manifest = json.load(f)
        except Exception:
            return False, "invalid_json"

    missing = [field for field in REQUIRED_FIELDS if field not in manifest]
    if missing:
        return False, f"missing_fields:{missing}"

    allowed_paths = manifest.get("allowed_paths", [])
    if not isinstance(allowed_paths, list) or not allowed_paths:
        return False, "allowed_paths_invalid_or_empty"

    for path in allowed_paths:
        if path not in ALLOWED_ROOTS:
            return False, f"invalid_allowed_path:{path}"

    return True, "valid"


def validate_bundle(bundle_path: str) -> Dict[str, Any]:
    manifest_path = os.path.join(bundle_path, "bundle_manifest.json")
    valid, reason = validate_manifest(manifest_path)
    return {
        "valid": valid,
        "reason": reason,
        "bundle_path": bundle_path,
        "manifest_path": manifest_path,
    }


if __name__ == "__main__":
    import sys

    target = sys.argv[1] if len(sys.argv) > 1 else "."
    result = validate_bundle(target)
    print(json.dumps(result, indent=2))
