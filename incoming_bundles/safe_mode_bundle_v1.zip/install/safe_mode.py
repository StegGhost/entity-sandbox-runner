import json, os
data=json.load(open("payload/state_scoring/state_score.json")) if os.path.exists("payload/state_scoring/state_score.json") else {}
score=data.get("score",100)
safe=score<50
os.makedirs("payload/runtime",exist_ok=True)
json.dump({"safe_mode":safe,"score":score},open("payload/runtime/safe_mode.json","w"),indent=2)
print({"safe_mode":safe,"score":score})
