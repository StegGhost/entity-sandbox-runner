class QuorumValidator:
    def validate(self, approvals, required=2):
        positive = [a for a in approvals if a["decision"] == "APPROVE"]
        return len(positive) >= required
