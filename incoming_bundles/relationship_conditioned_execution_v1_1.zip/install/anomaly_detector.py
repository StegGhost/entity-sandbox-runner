class AnomalyDetector:
    def detect(self, action, history):
        recent = history[-5:] if len(history) >= 5 else history
        mismatch = all(h["type"] != action["type"] for h in recent)
        return mismatch
