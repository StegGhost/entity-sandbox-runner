class WitnessCoordinator:
    def collect(self, action, witnesses):
        approvals = []
        for w in witnesses:
            decision = w.evaluate(action)
            approvals.append({"witness_id": w.id, "decision": decision})
        return approvals
