# v1.1 Distributed Witness + Self-Healing Layer

Adds quorum validation, anomaly detection, and recovery loops.