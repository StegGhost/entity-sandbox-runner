
import hashlib

def create_did(pubkey):
    # did:key method (simplified)
    return "did:key:" + hashlib.sha256(pubkey.encode()).hexdigest()

def resolve_did(did):
    return {"did": did, "doc": {"authentication": [did + "#key-1"]}}
