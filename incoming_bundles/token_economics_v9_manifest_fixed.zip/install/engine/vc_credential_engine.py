
import hashlib

def issue_vc(subject_did, vc_type):
    payload = f"{subject_did}:{vc_type}"
    sig = hashlib.sha256(payload.encode()).hexdigest()
    return {"sub": subject_did, "type": vc_type, "sig": sig}

def verify_vc(vc):
    payload = f"{vc['sub']}:{vc['type']}"
    expected = hashlib.sha256(payload.encode()).hexdigest()
    return vc.get("sig") == expected
