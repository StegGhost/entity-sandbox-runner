
class ZKBackend:
    def setup(self):
        raise NotImplementedError

    def prove(self, public_inputs, private_inputs):
        raise NotImplementedError

    def verify(self, proof, public_inputs):
        raise NotImplementedError
