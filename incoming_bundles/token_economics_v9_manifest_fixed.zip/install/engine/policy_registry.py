
POLICIES = {}

def save_policy(agent_id, policy):
    POLICIES[agent_id] = policy

def load_policy(agent_id):
    return POLICIES.get(agent_id, {})
