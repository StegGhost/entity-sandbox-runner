
import random
from install.engine.multi_agent_env import MultiAgentEnv, ACTIONS
from install.engine.policy_registry import save_policy

class Agent:
    def __init__(self, eps=1.0, eps_min=0.05, eps_decay=0.995, lr=0.001):
        self.q = {a: 0.0 for a in ACTIONS}
        self.eps = eps
        self.eps_min = eps_min
        self.eps_decay = eps_decay
        self.lr = lr

    def act(self):
        if random.random() < self.eps:
            return random.choice(ACTIONS)
        return max(self.q, key=self.q.get)

    def learn(self, action, reward):
        self.q[action] = self.q[action] + self.lr * (reward - self.q[action])
        self.eps = max(self.eps_min, self.eps * self.eps_decay)

class MultiAgentTrainer:
    def __init__(self, num_agents=4, episodes=50):
        self.env = MultiAgentEnv(num_agents)
        self.agents = [Agent() for _ in range(num_agents)]
        self.episodes = episodes

    def train(self):
        for _ in range(self.episodes):
            actions = [a.act() for a in self.agents]
            rewards, _ = self.env.step(actions)
            for i, a in enumerate(self.agents):
                a.learn(actions[i], rewards[i])
                save_policy(f"agent_{i}", a.q)
        return {f"agent_{i}": a.q for i, a in enumerate(self.agents)}
