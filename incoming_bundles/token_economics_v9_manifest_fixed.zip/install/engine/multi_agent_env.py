
import random

ACTIONS = ["low_risk", "high_risk"]

class MultiAgentEnv:
    def __init__(self, num_agents=4):
        self.num_agents = num_agents

    def step(self, actions):
        rewards = {}
        for i, a in enumerate(actions):
            if a == "high_risk":
                rewards[i] = random.choice([20, -20, 10, -10])
            else:
                rewards[i] = random.choice([2, 3, 1])
        done = False
        return rewards, done
