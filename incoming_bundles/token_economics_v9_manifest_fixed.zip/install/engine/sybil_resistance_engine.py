
def detect_sybil(dids):
    return len(dids) != len(set(dids))

def apply_sybil_penalty(accounts):
    for a in accounts:
        a['penalized'] = True
    return accounts
