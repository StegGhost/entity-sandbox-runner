
from install.engine.multi_agent_trainer import MultiAgentTrainer

def test_multi_agent():
    t = MultiAgentTrainer(num_agents=2, episodes=2)
    out = t.train()
    assert isinstance(out, dict)
