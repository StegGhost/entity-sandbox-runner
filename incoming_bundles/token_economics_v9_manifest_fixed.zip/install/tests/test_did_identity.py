
from install.engine.did_identity_engine import create_did
from install.engine.vc_credential_engine import issue_vc, verify_vc

def test_did_vc():
    did = create_did("pubkey")
    vc = issue_vc(did, "ExecutionAgent")
    assert verify_vc(vc)
