
from install.engine.zk_circom_adapter import CircomBackend

def test_circom_backend():
    b = CircomBackend()
    b.setup()
    p = b.prove({"x":1}, {"w":2})
    assert b.verify(p, {"x":1})
