
# Generator V7 Bundle

Trust + Reputation + Scoring Engine

- Identity-based scoring
- Persistent trust state
- Receipt continuity

Enables governance over WHO executes actions.
