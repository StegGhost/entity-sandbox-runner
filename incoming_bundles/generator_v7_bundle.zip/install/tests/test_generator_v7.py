
from install.engine.proposal_to_bundle import build_manifest

def test_trust_present():
    m = build_manifest("sample_bundle")
    assert "trust" in m

def test_receipt_chain():
    m = build_manifest("sample_bundle")
    assert "receipt" in m
