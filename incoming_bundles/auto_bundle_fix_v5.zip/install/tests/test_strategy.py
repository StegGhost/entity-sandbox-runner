
def test_strategy_selection():
    from install.engine.proposal_to_bundle import record_strategy, choose_strategy

    memory = {"patterns": {}, "strategies": {}}

    record_strategy(memory, "capability_violation:x", "quarantine", True)
    record_strategy(memory, "capability_violation:x", "relocate", False)

    assert choose_strategy(memory, "capability_violation:x") == "quarantine"
