
import json
import os
import shutil

ALLOWED_PATHS = [
    "bundle_manifest.json",
    "install/tests/",
    "install/engine/",
    "install/apply.py",
    "install/config/"
]

MAX_RETRIES = 3
MEMORY_PATH = "install/config/repair_memory.json"

def load_memory(bundle_root):
    path = os.path.join(bundle_root, MEMORY_PATH)
    if os.path.exists(path):
        with open(path) as f:
            return json.load(f)
    return {"patterns": {}, "strategies": {}}

def save_memory(bundle_root, memory):
    path = os.path.join(bundle_root, MEMORY_PATH)
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w") as f:
        json.dump(memory, f, indent=2)

def record_failure(memory, reason):
    memory["patterns"].setdefault(reason, {"count": 0})
    memory["patterns"][reason]["count"] += 1

def record_strategy(memory, reason, strategy, success):
    memory["strategies"].setdefault(reason, {})
    memory["strategies"][reason].setdefault(strategy, {"success": 0, "fail": 0})
    if success:
        memory["strategies"][reason][strategy]["success"] += 1
    else:
        memory["strategies"][reason][strategy]["fail"] += 1

def choose_strategy(memory, reason):
    strategies = memory.get("strategies", {}).get(reason, {})
    if not strategies:
        return "quarantine"

    # choose best success ratio
    best = None
    best_score = -1
    for name, stats in strategies.items():
        total = stats["success"] + stats["fail"]
        score = stats["success"] / total if total > 0 else 0
        if score > best_score:
            best = name
            best_score = score

    return best or "quarantine"

def build_manifest(bundle_name, bundle_version="1.0.0"):
    return {
        "bundle_name": bundle_name,
        "bundle_version": bundle_version,
        "install_mode": "folder_map",
        "allowed_paths": ALLOWED_PATHS
    }

def simulate_ingestion(bundle_root):
    manifest_path = os.path.join(bundle_root, "bundle_manifest.json")
    if not os.path.exists(manifest_path):
        return False, "missing_manifest"

    with open(manifest_path) as f:
        manifest = json.load(f)

    allowed = manifest.get("allowed_paths", [])

    for root, _, files in os.walk(bundle_root):
        for file in files:
            rel_path = os.path.relpath(os.path.join(root, file), bundle_root)

            if rel_path == "bundle_manifest.json":
                continue

            valid = False
            for path in allowed:
                if path.endswith("/") and rel_path.startswith(path):
                    valid = True
                elif rel_path == path:
                    valid = True

            if not valid:
                return False, f"capability_violation:{rel_path}"

    return True, "ok"

def ensure_structure(bundle_root):
    os.makedirs(os.path.join(bundle_root, "install/tests"), exist_ok=True)
    os.makedirs(os.path.join(bundle_root, "install/engine"), exist_ok=True)
    os.makedirs(os.path.join(bundle_root, "install/config"), exist_ok=True)

    apply_path = os.path.join(bundle_root, "install/apply.py")
    if not os.path.exists(apply_path):
        with open(apply_path, "w") as f:
            f.write("def apply():\n    print(\"Bundle applied successfully.\")\n")

def repair_quarantine(bundle_root, bad_path):
    full_path = os.path.join(bundle_root, bad_path)
    quarantine_dir = os.path.join(bundle_root, "quarantine")
    os.makedirs(quarantine_dir, exist_ok=True)
    if os.path.exists(full_path):
        shutil.move(full_path, os.path.join(quarantine_dir, os.path.basename(bad_path)))
    return True

def repair_relocate(bundle_root, bad_path):
    full_path = os.path.join(bundle_root, bad_path)
    target_path = os.path.join(bundle_root, "install/engine", os.path.basename(bad_path))
    if os.path.exists(full_path):
        shutil.move(full_path, target_path)
    return True

def auto_repair(bundle_root, reason, memory):
    record_failure(memory, reason)

    if reason.startswith("capability_violation:"):
        bad_path = reason.split(":", 1)[1]

        strategy = choose_strategy(memory, reason)

        if strategy == "relocate":
            success = repair_relocate(bundle_root, bad_path)
        else:
            strategy = "quarantine"
            success = repair_quarantine(bundle_root, bad_path)

        record_strategy(memory, reason, strategy, success)
        return success

    if reason == "missing_manifest":
        return True

    return False

def build_bundle(bundle_root, bundle_name):
    ensure_structure(bundle_root)
    memory = load_memory(bundle_root)

    manifest = build_manifest(bundle_name)
    with open(os.path.join(bundle_root, "bundle_manifest.json"), "w") as f:
        json.dump(manifest, f, indent=2)

    for _ in range(MAX_RETRIES):
        ok, reason = simulate_ingestion(bundle_root)
        if ok:
            save_memory(bundle_root, memory)
            return True

        repaired = auto_repair(bundle_root, reason, memory)
        if not repaired:
            save_memory(bundle_root, memory)
            raise Exception(f"UNRECOVERABLE:{reason}")

    save_memory(bundle_root, memory)
    raise Exception(f"MAX_RETRIES_EXCEEDED:{reason}")
