
from engine.verify_signature import verify_signature
from engine.verify_bundle_integrity import verify_integrity
from engine.authority_gate import run_authority_gate

def run_governance_pipeline(extracted_root, manifest):
    sig = verify_signature(manifest)
    if not sig.get("valid"):
        return {"valid": False, "stage": "signature", "reason": sig.get("reason")}

    integrity = verify_integrity(extracted_root, manifest)
    if not integrity.get("valid"):
        return {"valid": False, "stage": "integrity", "reason": integrity.get("file_errors")}

    authority = run_authority_gate(manifest)
    if not authority.get("valid"):
        return {"valid": False, "stage": "authority", "reason": authority.get("violations")}

    return {"valid": True}
