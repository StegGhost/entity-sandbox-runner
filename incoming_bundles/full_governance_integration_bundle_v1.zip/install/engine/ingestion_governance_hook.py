
from engine.governance_pipeline import run_governance_pipeline

def enforce_governance(extracted_root, manifest):
    result = run_governance_pipeline(extracted_root, manifest)
    if not result.get("valid"):
        raise Exception(f"GOVERNANCE_REJECTED: {result}")
    return result
