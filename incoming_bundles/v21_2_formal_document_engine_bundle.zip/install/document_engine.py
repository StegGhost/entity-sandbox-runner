def generate_document(doc_type, topic):
    return f"# {topic}\n\nGenerated as {doc_type}"
