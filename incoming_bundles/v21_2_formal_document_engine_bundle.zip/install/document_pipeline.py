from install.document_engine import generate_document

def run(doc_type, topic):
    doc = generate_document(doc_type, topic)
    print(doc)
