
const canvas = document.getElementById("graph");
const ctx = canvas.getContext("2d");

function drawGraph(data) {
    ctx.clearRect(0,0,600,300);
    ctx.beginPath();
    data.forEach((v,i) => {
        ctx.lineTo(i*50, 300 - v*10);
    });
    ctx.stroke();
}

function pause() {
    document.getElementById("output").innerText = "System Paused";
}

function resume() {
    document.getElementById("output").innerText = "System Running";
}

function simulate() {
    const data = Array.from({length:10}, () => Math.random()*20);
    drawGraph(data);
    document.getElementById("output").innerText = "Simulation Run";
}

simulate();
