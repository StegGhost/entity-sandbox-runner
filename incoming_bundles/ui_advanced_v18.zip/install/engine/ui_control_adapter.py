
def handle_action(action):
    return f"Action executed: {action}"
