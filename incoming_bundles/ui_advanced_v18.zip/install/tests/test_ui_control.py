
from install.engine.ui_control_adapter import handle_action

def test_control():
    assert "executed" in handle_action("pause")
