def map_action_to_capability(action):
    mapping = {
        "SEND_EMAIL": "COMM.EMAIL_SEND",
        "READ_EMAIL": "COMM.EMAIL_READ",
        "SCHEDULE_EVENT": "SCHED.CALENDAR"
    }
    return mapping.get(action)

def is_action_authorized(passport, action):
    capabilities = passport.get("capabilities", [])
    required = map_action_to_capability(action)
    if not required:
        return False, "no_mapping"
    if required not in capabilities:
        return False, "missing_capability"
    return True, "authorized"
