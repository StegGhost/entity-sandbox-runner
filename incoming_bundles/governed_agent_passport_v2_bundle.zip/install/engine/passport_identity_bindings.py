import hashlib
import json

def bind_passport_to_receipt(passport_hash, action, result):
    record = {
        "passport_hash": passport_hash,
        "action": action,
        "result": result
    }
    canonical = json.dumps(record, sort_keys=True).encode()
    record["binding_hash"] = hashlib.sha256(canonical).hexdigest()
    return record
