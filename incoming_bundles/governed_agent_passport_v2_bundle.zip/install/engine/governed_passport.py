import json
import hashlib

REQUIRED_FIELDS = ["standard", "version", "agent", "capabilities", "public_key", "signature"]

def validate_passport_structure(passport):
    for field in REQUIRED_FIELDS:
        if field not in passport:
            return False, f"missing_{field}"
    return True, "valid"

def canonical_json(data):
    return json.dumps(data, sort_keys=True, separators=(",", ":"))

def hash_passport(passport):
    canonical = canonical_json(passport).encode()
    return hashlib.sha256(canonical).hexdigest()

def extract_capabilities(passport):
    return sorted(passport.get("capabilities", []))

def get_agent_id(passport):
    return passport.get("agent", {}).get("id")
