from install.engine.passport_identity_bindings import bind_passport_to_receipt

def test_binding():
    r = bind_passport_to_receipt("abc", "SEND_EMAIL", {"ok": True})
    assert "binding_hash" in r
