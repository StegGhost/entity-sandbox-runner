from install.engine.governed_passport import validate_passport_structure, hash_passport

def test_structure_valid():
    p = {"standard": "x", "version": "1", "agent": {}, "capabilities": [], "public_key": "k", "signature": "s"}
    assert validate_passport_structure(p)[0] is True

def test_hash():
    p = {"a":1}
    h = hash_passport(p)
    assert isinstance(h, str)
