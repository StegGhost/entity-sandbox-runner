from install.engine.passport_authority import is_action_authorized

def test_authorized():
    p = {"capabilities": ["COMM.EMAIL_SEND"]}
    assert is_action_authorized(p, "SEND_EMAIL")[0] is True
