
import json
from pathlib import Path

data=json.loads(Path("results/phase_space_map.json").read_text())

stable=[d for d in data if d["viability_margin"]>0]
unstable=[d for d in data if d["viability_margin"]<=0]

print("Stable states:",len(stable))
print("Unstable states:",len(unstable))

# crude estimate of Uc
boundary=[d["U"] for d in data if abs(d["viability_margin"])<0.05 and d["U"]!=None]

if boundary:
    print("Estimated critical Uc:",sum(boundary)/len(boundary))
