
Experiment outputs appear here.

Primary outputs:

phase_space_map.json
collapse_boundary_surface.json
scaling_exponent_estimate.json
