
import json, random
from pathlib import Path

OUTPUT = Path("results")
OUTPUT.mkdir(exist_ok=True)

def viability(capacity, pressure, constraints, continuity):
    return (capacity * continuity) - (pressure * constraints)

def compute_u(capacity, pressure, constraints, continuity):
    if pressure*constraints == 0:
        return None
    return (capacity * continuity)/(pressure*constraints)

data = []

for _ in range(50000):
    capacity=random.uniform(0.1,5)
    pressure=random.uniform(0.1,5)
    constraints=random.uniform(0.1,5)
    continuity=random.uniform(0.1,5)

    v=viability(capacity,pressure,constraints,continuity)
    u=compute_u(capacity,pressure,constraints,continuity)

    data.append({
        "capacity":capacity,
        "pressure":pressure,
        "constraints":constraints,
        "continuity":continuity,
        "viability_margin":v,
        "U":u
    })

(Path("results")/"phase_space_map.json").write_text(json.dumps(data,indent=2))

print("Experiment completed. Results written to results/phase_space_map.json")
