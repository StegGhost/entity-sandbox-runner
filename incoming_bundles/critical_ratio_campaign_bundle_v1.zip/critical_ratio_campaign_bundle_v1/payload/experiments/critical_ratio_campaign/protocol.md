
# Protocol

Parameter sweep across four variables:

- governance_capacity
- artifact_pressure
- constraints
- trust_continuity

Compute:

U = (capacity * continuity) / (pressure * constraints)

Then identify states where viability_margin approaches zero.
These states approximate the collapse boundary.
