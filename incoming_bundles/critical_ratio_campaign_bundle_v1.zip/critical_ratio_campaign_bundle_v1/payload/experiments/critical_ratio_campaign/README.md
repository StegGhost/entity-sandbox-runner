
# Critical Ratio Campaign

This experiment explores whether a **dimensionless invariant** predicts stability transitions
in governance-like dynamical systems.

Candidate invariant:

U = (capacity * continuity) / (pressure * constraints)

## Goal

Determine whether a critical threshold **Uc** separates stable and unstable regions of phase space.

## Experiment steps

1. Sweep parameter ranges
2. Compute viability margin
3. Calculate invariant U
4. Identify collapse boundary
5. Fit critical threshold Uc
6. Estimate scaling exponent beta

## Expected outputs

- phase_space_map.json
- collapse_boundary_surface.json
- scaling_exponent_estimate.json
