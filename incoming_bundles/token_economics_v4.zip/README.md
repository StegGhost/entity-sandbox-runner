# Token Economics V4
Consensus + Fraud Proofs Layer
