
def verify_fraud(claim, recomputed_result):
    return claim != recomputed_result

def apply_penalty(account, penalty):
    account.balance -= penalty
    return account.balance
