
def finalize_block(consensus_result, fraud_detected):
    if not consensus_result or fraud_detected:
        return False
    return True
