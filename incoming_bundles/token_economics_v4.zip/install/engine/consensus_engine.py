
def reach_consensus(votes, threshold=0.67):
    total = len(votes)
    approvals = sum(1 for v in votes if v)
    ratio = approvals / total if total else 0
    return ratio >= threshold, ratio
