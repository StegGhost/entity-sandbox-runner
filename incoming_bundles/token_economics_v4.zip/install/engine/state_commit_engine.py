
import hashlib

def commit_state(state):
    return hashlib.sha256(str(state).encode()).hexdigest()
