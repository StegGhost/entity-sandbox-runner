
from install.engine.consensus_engine import reach_consensus

def test_consensus():
    result, ratio = reach_consensus([True, True, False])
    assert result is True
