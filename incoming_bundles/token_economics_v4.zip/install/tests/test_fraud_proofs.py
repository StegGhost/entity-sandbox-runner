
from install.engine.fraud_proof_engine import verify_fraud

def test_fraud():
    assert verify_fraud(10, 5) is True
