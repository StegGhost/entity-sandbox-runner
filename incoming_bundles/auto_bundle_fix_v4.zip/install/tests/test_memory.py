
def test_memory_learning():
    from install.engine.proposal_to_bundle import load_memory, record_failure

    memory = {"patterns": {}}
    record_failure(memory, "capability_violation:test.py")
    record_failure(memory, "capability_violation:test.py")

    assert memory["patterns"]["capability_violation:test.py"]["count"] == 2
