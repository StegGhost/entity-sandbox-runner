from __future__ import annotations

import os
import time
import uuid
from typing import Any, Dict, List, Optional

from fastapi import Depends, FastAPI, Header, HTTPException
from pydantic import BaseModel, Field

from .config import get_settings, get_default_provider
from .event_log import write_event
from .models import ProviderResolveRequest, ProviderResolveResponse, ProviderInfo
from .services import resolve_provider

# --- Optional dependency: PyJWT ---
try:
    import jwt  # PyJWT
    from jwt import PyJWKClient  # type: ignore
except Exception as e:  # pragma: no cover
    jwt = None
    PyJWKClient = None  # pragma: no cover
    _jwt_import_error = e

# --- Optional dependency: Redis (async) ---
try:
    import redis.asyncio as redis_async
except Exception:
    redis_async = None


# ------------------------
# Helpers / Settings
# ------------------------
def _now() -> int:
    return int(time.time())


def _utc_now_iso() -> str:
    return time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())


def _clamp_ttl(ttl_seconds: int) -> int:
    # Ephemeral means minutes.
    if ttl_seconds <= 0:
        return 120
    return max(10, min(int(ttl_seconds), 300))


def _require_jwt() -> None:
    if jwt is None:
        raise HTTPException(
            status_code=500,
            detail=(
                "PyJWT is not installed. Add `PyJWT==2.10.1` to requirements.txt. "
                f"Import error: {_jwt_import_error}"
            ),
        )


def _jwt_secret() -> str:
    secret = os.getenv("STEGTV_JWT_SECRET", "").strip()
    if not secret:
        raise HTTPException(status_code=500, detail="Missing env var STEGTV_JWT_SECRET.")
    if len(secret) < 16:
        raise HTTPException(status_code=500, detail="STEGTV_JWT_SECRET too short (min 16 chars).")
    return secret


def _admin_token() -> str:
    # Prefer STEGTV_ADMIN_TOKEN, allow legacy ADMIN_TOKEN fallback.
    tok = (os.getenv("STEGTV_ADMIN_TOKEN") or os.getenv("ADMIN_TOKEN") or "").strip()
    if not tok:
        raise HTTPException(status_code=500, detail="Missing env var STEGTV_ADMIN_TOKEN (or ADMIN_TOKEN).")
    return tok


def _env() -> str:
    """
    Prefer Settings.env (STEGTV_ENV), fall back to STEGTV_ENV/ENV. Normalize prod->production.
    Keeps docs gating consistent with config.py.
    """
    try:
        v = (get_settings().env or "").strip().lower()
        if v:
            if v == "prod":
                return "production"
            return v
    except Exception:
        pass

    v2 = (os.getenv("STEGTV_ENV") or os.getenv("ENV") or "production").strip().lower()
    if v2 == "prod":
        return "production"
    return v2


def _docs_enabled() -> bool:
    # Only enable docs in dev-like envs.
    return _env() in ("dev", "development", "local")


def _public_url() -> str:
    return (os.getenv("PUBLIC_URL") or os.getenv("STEGTV_PUBLIC_URL") or "").strip()


def _redis_url() -> str:
    return (os.getenv("REDIS_URL") or "").strip()


def _verify_grace_seconds() -> int:
    # Sliding window for internal flows (admin-only).
    raw = (os.getenv("STEGTV_VERIFY_GRACE_SECONDS") or "30").strip()
    try:
        v = int(raw)
    except Exception:
        v = 30
    return max(0, min(v, 300))


def _jwt_leeway_seconds() -> int:
    """
    Small leeway for exp/nbf checks to tolerate minor clock skew across instances/CDN edges.
    This is separate from the grace path (which only applies when already expired).
    """
    raw = (os.getenv("STEGTV_JWT_LEEWAY_SECONDS") or "5").strip()
    try:
        v = int(raw)
    except Exception:
        v = 5
    return max(0, min(v, 60))


def _oidc_issuer() -> str:
    return (os.getenv("STEGTV_OIDC_ISSUER") or "https://token.actions.githubusercontent.com").strip()


def _oidc_audience() -> str:
    return (os.getenv("STEGTV_OIDC_AUDIENCE") or "stegtv").strip()


def _oidc_jwks_url() -> str:
    return (os.getenv("STEGTV_OIDC_JWKS_URL") or f"{_oidc_issuer().rstrip('/')}/.well-known/jwks").strip()


def _allowed_repos() -> List[str]:
    """
    Comma-separated allowlist. If empty => allow all repos (NOT recommended for prod).
    Example: "StegVerse-Labs/TVC,StegVerse-Labs/TV"
    """
    raw = (os.getenv("STEGTV_ALLOWED_REPOS") or "").strip()
    if not raw:
        return []
    return [x.strip() for x in raw.split(",") if x.strip()]


def _allowed_envs() -> List[str]:
    raw = (os.getenv("STEGTV_ALLOWED_ENVS") or "production,staging,dev").strip()
    return [x.strip().lower() for x in raw.split(",") if x.strip()]


def _allowed_scopes() -> List[str]:
    raw = (os.getenv("STEGTV_ALLOWED_SCOPES") or "deploy,read-secrets,ops").strip()
    return [x.strip().lower() for x in raw.split(",") if x.strip()]


def _oidc_require_jwks() -> None:
    _require_jwt()
    if PyJWKClient is None:
        raise HTTPException(
            status_code=500,
            detail="PyJWT PyJWKClient not available. Ensure PyJWT>=2.0 is installed (you pin 2.10.1).",
        )


def _repo_allowed(repo: str) -> bool:
    allow = _allowed_repos()
    if not allow:
        return True
    return repo.strip().lower() in {r.lower() for r in allow}


def _provider_to_dict(p: Any) -> Dict[str, Any]:
    """
    Normalize provider config for health responses.
    Works with dict, pydantic models, dataclasses-ish objects.
    """
    if p is None:
        return {}
    if isinstance(p, dict):
        return p
    # Pydantic v2
    if hasattr(p, "model_dump"):
        try:
            d = p.model_dump()
            if isinstance(d, dict):
                return d
        except Exception:
            pass
    # Pydantic v1
    if hasattr(p, "dict"):
        try:
            d = p.dict()
            if isinstance(d, dict):
                return d
        except Exception:
            pass

    # Fallback: pull common attributes
    out: Dict[str, Any] = {}
    for k in ("name", "model", "endpoint", "notes"):
        if hasattr(p, k):
            try:
                out[k] = getattr(p, k)
            except Exception:
                pass
    return out


# ------------------------
# Redis wiring (optional)
# ------------------------
_redis: Optional["redis_async.Redis"] = None


async def _get_redis() -> Optional["redis_async.Redis"]:
    global _redis
    if _redis is not None:
        return _redis

    url = _redis_url()
    if not url:
        return None
    if redis_async is None:
        # redis lib not installed; act like redis is absent.
        return None

    # decode_responses=True returns strings instead of bytes
    _redis = redis_async.from_url(url, decode_responses=True)
    return _redis


async def _get_rev_epoch() -> int:
    r = await _get_redis()
    if r is None:
        return int(os.getenv("STEGTV_REV_EPOCH", "0") or 0)

    try:
        v = await r.get("tvc:rev_epoch")
        if v is None:
            await r.set("tvc:rev_epoch", "0")
            return 0
        return int(v)
    except Exception:
        # If redis is flaky, fall back to process env epoch.
        return int(os.getenv("STEGTV_REV_EPOCH", "0") or 0)


async def _bump_rev_epoch() -> int:
    r = await _get_redis()
    if r is None:
        # Process-local fallback (not shared across instances).
        cur = int(os.getenv("STEGTV_REV_EPOCH", "0") or 0) + 1
        os.environ["STEGTV_REV_EPOCH"] = str(cur)
        return cur

    try:
        v = await r.incr("tvc:rev_epoch")
        return int(v)
    except Exception:
        cur = int(os.getenv("STEGTV_REV_EPOCH", "0") or 0) + 1
        os.environ["STEGTV_REV_EPOCH"] = str(cur)
        return cur


# ------------------------
# Auth dependency
# ------------------------
async def require_admin(x_admin_token: Optional[str] = Header(default=None, alias="X-Admin-Token")) -> None:
    expected = _admin_token()
    presented = (x_admin_token or "").strip()
    if not presented or presented != expected:
        raise HTTPException(status_code=401, detail="Unauthorized")


# ------------------------
# Models
# ------------------------
class TokenIssueRequest(BaseModel):
    sub: str = Field(..., description="Subject identifier (user/workload).")
    action: str = Field(..., description="Action name, e.g. 'deploy', 'write_repo'.")
    scope: str = Field(..., description="Resource scope, e.g. 'repo:StegVerse-Labs/TVC'.")
    ttl_seconds: int = Field(120, description="Token TTL seconds (clamped 10..300).")
    ctx_hash: Optional[str] = Field(None, description="Optional context hash (bind token to request context).")
    bundle_hash: Optional[str] = Field(None, description="Optional policy bundle hash/digest.")
    mode: str = Field("assisted", description="manual|assisted|autonomous|degraded|frozen")
    extra: Optional[Dict[str, Any]] = Field(None, description="Optional extra claims dict (namespaced).")


class TokenIssueResponse(BaseModel):
    token: str
    exp: int
    jti: str
    rev: int


class TokenVerifyRequest(BaseModel):
    token: str


class TokenVerifyResponse(BaseModel):
    valid: bool
    claims: Optional[Dict[str, Any]] = None
    reason: Optional[str] = None


class TokenRevokeResponse(BaseModel):
    rev: int


class OIDCExchangeRequest(BaseModel):
    oidc_jwt: str = Field(..., description="GitHub Actions OIDC JWT")
    repo: str = Field(..., description="Repo name like Org/Repo")
    ref: str = Field(..., description="Git ref (github.ref)")
    sha: str = Field(..., description="Commit SHA (github.sha)")
    scope: str = Field("deploy", description="Requested scope (deploy/read-secrets/ops)")
    environment: str = Field("production", description="Requested environment (production/staging/dev)")
    ttl_seconds: int = Field(60, description="Execution token TTL seconds (clamped 10..300)")


class OIDCExchangeResponse(BaseModel):
    token: str
    exp: int
    jti: str
    rev: int


# ------------------------
# App init (docs toggle)
# ------------------------
settings = get_settings()

app = FastAPI(
    title="StegTVC Core",
    description="StegVerse Token Vault Config / AI Provider Router (Core v1.0, option C).",
    version=settings.version,
    docs_url="/docs" if _docs_enabled() else None,
    redoc_url="/redoc" if _docs_enabled() else None,
    openapi_url="/openapi.json" if _docs_enabled() else None,
)


# Add Swagger "Authorize" (only matters when docs enabled)
def custom_openapi():
    if app.openapi_schema:
        return app.openapi_schema
    from fastapi.openapi.utils import get_openapi

    schema = get_openapi(
        title=app.title,
        version=app.version,
        description=app.description,
        routes=app.routes,
    )
    schema.setdefault("components", {}).setdefault("securitySchemes", {})
    schema["components"]["securitySchemes"]["AdminToken"] = {
        "type": "apiKey",
        "in": "header",
        "name": "X-Admin-Token",
        "description": "Admin token required for /tokens/* endpoints",
    }
    # Mark only the /tokens/* endpoints as requiring AdminToken (UI lock icon + Authorize button)
    for path, methods in schema.get("paths", {}).items():
        if path.startswith("/tokens/"):
            for _, op in methods.items():
                if isinstance(op, dict):
                    op.setdefault("security", [{"AdminToken": []}])
    app.openapi_schema = schema
    return app.openapi_schema


app.openapi = custom_openapi


# ------------------------
# Routes
# ------------------------
@app.get("/", summary="Root (avoid Render HEAD / 404 noise)")
async def root() -> Dict[str, Any]:
    return {"status": "ok", "service": "stegtvc", "env": _env(), "version": settings.version}


@app.get("/health", summary="Basic health check")
async def health() -> Dict[str, Any]:
    provider_raw = get_default_provider()
    provider = _provider_to_dict(provider_raw)
    settings_default = _provider_to_dict(getattr(settings, "default_provider", None))

    redis_ok = False
    redis_configured = bool(_redis_url())
    if redis_configured:
        r = await _get_redis()
        if r is not None:
            try:
                pong = await r.ping()
                redis_ok = bool(pong)
            except Exception:
                redis_ok = False

    payload = {
        "status": "ok",
        "env": _env(),
        "service": "stegtvc",
        "version": settings.version,
        "public_url": _public_url() or (settings_default.get("endpoint") or provider.get("endpoint") or ""),
        "default_provider": {
            "name": provider.get("name"),
            "model": provider.get("model"),
            "endpoint": provider.get("endpoint"),
        },
        "security": {
            "admin_header": "X-Admin-Token",
            "docs_enabled": _docs_enabled(),
            "token_ttl_max_seconds": 300,
            "revocation_epoch": await _get_rev_epoch(),
            "jwt_signing": "HS256 (env: STEGTV_JWT_SECRET)",
            "verify_grace_seconds": _verify_grace_seconds(),
            "jwt_leeway_seconds": _jwt_leeway_seconds(),
            "oidc_exchange_enabled": True,
            "oidc_issuer": _oidc_issuer(),
            "oidc_audience": _oidc_audience(),
            "event_log_path": os.getenv("STEGTV_EVENT_LOG_PATH", "data/execution_events.jsonl"),
        },
        "redis": {
            "configured": redis_configured,
            "ok": redis_ok,
        },
        "time": {
            "now_unix": _now(),
        },
    }
    return payload


@app.post(
    "/providers/resolve",
    response_model=ProviderResolveResponse,
    summary="Resolve which provider/model/config to use for a given use-case.",
)
async def providers_resolve(body: ProviderResolveRequest) -> ProviderResolveResponse:
    return resolve_provider(body)


@app.get(
    "/providers/default",
    response_model=ProviderInfo,
    summary="Return the currently configured default provider/model.",
)
async def providers_default() -> ProviderInfo:
    base = _provider_to_dict(get_default_provider())
    return ProviderInfo(
        name=base.get("name"),
        model=base.get("model"),
        endpoint=base.get("endpoint"),
        notes=base.get("notes"),
    )


@app.post(
    "/v1/oidc/exchange",
    response_model=OIDCExchangeResponse,
    summary="Exchange GitHub OIDC identity for a short-lived StegTV execution token (no CI secrets).",
)
async def oidc_exchange(body: OIDCExchangeRequest) -> OIDCExchangeResponse:
    _oidc_require_jwks()

    repo = body.repo.strip()
    ref = body.ref.strip()
    sha = body.sha.strip()
    scope = body.scope.strip().lower()
    envreq = body.environment.strip().lower()
    request_id = str(uuid.uuid4())

    if not repo or "/" not in repo:
        raise HTTPException(status_code=400, detail="Invalid repo. Expect 'Org/Repo'.")
    if not ref:
        raise HTTPException(status_code=400, detail="Invalid ref.")
    if not sha or len(sha) < 7:
        raise HTTPException(status_code=400, detail="Invalid sha.")

    if scope not in set(_allowed_scopes()):
        raise HTTPException(status_code=403, detail=f"Scope not allowed: {scope}")
    if envreq not in set(_allowed_envs()):
        raise HTTPException(status_code=403, detail=f"Environment not allowed: {envreq}")
    if not _repo_allowed(repo):
        raise HTTPException(status_code=403, detail=f"Repo not allowed: {repo}")

    issuer = _oidc_issuer()
    audience = _oidc_audience()
    jwks_url = _oidc_jwks_url()
    leeway = _jwt_leeway_seconds()

    try:
        jwk_client = PyJWKClient(jwks_url)
        signing_key = jwk_client.get_signing_key_from_jwt(body.oidc_jwt).key
        oidc_claims = jwt.decode(
            body.oidc_jwt,
            signing_key,
            algorithms=["RS256"],
            audience=audience,
            issuer=issuer,
            leeway=leeway,
        )
    except Exception as e:
        raise HTTPException(status_code=401, detail=f"OIDC verify failed: {e}")

    token_repo = str(oidc_claims.get("repository") or "").strip()
    if token_repo and token_repo.lower() != repo.lower():
        raise HTTPException(status_code=403, detail=f"Repo mismatch: oidc={token_repo} req={repo}")

    token_ref = str(oidc_claims.get("ref") or "").strip()
    if token_ref and token_ref != ref:
        raise HTTPException(status_code=403, detail=f"Ref mismatch: oidc={token_ref} req={ref}")

    token_sha = str(oidc_claims.get("sha") or "").strip()
    if token_sha and token_sha.lower() != sha.lower():
        raise HTTPException(status_code=403, detail=f"SHA mismatch: oidc={token_sha} req={sha}")

    sub = str(oidc_claims.get("sub") or "").strip()
    if not sub:
        raise HTTPException(status_code=403, detail="OIDC missing sub claim.")

    secret = _jwt_secret()
    ttl = _clamp_ttl(body.ttl_seconds)
    iat = _now()
    exp = iat + ttl
    jti = str(uuid.uuid4())
    rev = await _get_rev_epoch()

    claims: Dict[str, Any] = {
        "iss": "stegverse:tvc",
        "sub": f"oidc:{sub}",
        "iat": iat,
        "exp": exp,
        "jti": jti,
        "rev": rev,
        "act": "exec",
        "scope": scope,
        "env": envreq,
        "repo": repo,
        "ref": ref,
        "sha": sha,
        "oidc_iss": issuer,
        "aud": audience,
    }

    token = jwt.encode(claims, secret, algorithm="HS256")

    common_meta = {
        "identity_provider": "github_oidc",
        "repository_claim": token_repo or None,
        "subject": sub,
        "audience": audience,
        "oidc_issuer": issuer,
    }

    write_event(
        {
            "event_id": str(uuid.uuid4()),
            "time": _utc_now_iso(),
            "event_type": "oidc_exchange",
            "decision": "allow",
            "issuer": "stegverse:tvc",
            "repo": repo,
            "ref": ref,
            "sha": sha,
            "scope": scope,
            "environment": envreq,
            "request_id": request_id,
            "rev_epoch": rev,
            "identity": {
                "provider": "github_oidc",
                "subject": sub,
                "repository_claim": token_repo or None,
                "workflow_ref": oidc_claims.get("job_workflow_ref"),
            },
            "meta": common_meta,
        }
    )

    write_event(
        {
            "event_id": str(uuid.uuid4()),
            "time": _utc_now_iso(),
            "event_type": "token_issued",
            "decision": "allow",
            "issuer": "stegverse:tvc",
            "token_jti": jti,
            "rev_epoch": rev,
            "repo": repo,
            "ref": ref,
            "sha": sha,
            "scope": scope,
            "environment": envreq,
            "request_id": request_id,
            "identity": {
                "provider": "github_oidc",
                "subject": sub,
                "repository_claim": token_repo or None,
                "workflow_ref": oidc_claims.get("job_workflow_ref"),
            },
            "meta": {**common_meta, "token_exp": exp},
        }
    )

    return OIDCExchangeResponse(token=token, exp=exp, jti=jti, rev=rev)


# ------------------------
# Ephemeral tokens (admin protected)
# ------------------------
@app.post(
    "/tokens/issue",
    response_model=TokenIssueResponse,
    summary="Issue an ephemeral, action-scoped StegVerse token.",
    dependencies=[Depends(require_admin)],
)
async def tokens_issue(body: TokenIssueRequest) -> TokenIssueResponse:
    _require_jwt()
    secret = _jwt_secret()

    ttl = _clamp_ttl(body.ttl_seconds)
    iat = _now()
    exp = iat + ttl
    jti = str(uuid.uuid4())
    rev = await _get_rev_epoch()
    request_id = str(uuid.uuid4())

    claims: Dict[str, Any] = {
        "iss": "stegverse:tvc",
        "sub": body.sub,
        "iat": iat,
        "exp": exp,
        "jti": jti,
        "act": body.action,
        "scope": body.scope,
        "mode": body.mode,
        "rev": rev,
    }
    if body.ctx_hash:
        claims["ctxh"] = body.ctx_hash
    if body.bundle_hash:
        claims["bnd"] = body.bundle_hash
    if body.extra:
        claims["x"] = body.extra

    token = jwt.encode(claims, secret, algorithm="HS256")

    write_event(
        {
            "event_id": str(uuid.uuid4()),
            "time": _utc_now_iso(),
            "event_type": "token_issued",
            "decision": "allow",
            "issuer": "stegverse:tvc",
            "token_jti": jti,
            "rev_epoch": rev,
            "repo": body.scope,
            "ref": "admin",
            "sha": "manual-admin",
            "scope": body.scope,
            "environment": _env(),
            "request_id": request_id,
            "identity": {
                "provider": "admin",
                "subject": body.sub,
                "repository_claim": None,
                "workflow_ref": None,
            },
            "policy": {
                "bundle_hash": body.bundle_hash,
                "policy_version": None,
                "source": "admin_issue",
            },
            "meta": {
                "action": body.action,
                "mode": body.mode,
                "ctx_hash": body.ctx_hash,
                "token_exp": exp,
            },
        }
    )

    return TokenIssueResponse(token=token, exp=exp, jti=jti, rev=rev)


@app.post(
    "/tokens/verify",
    response_model=TokenVerifyResponse,
    summary="Verify a StegVerse token and return claims.",
    dependencies=[Depends(require_admin)],
)
async def tokens_verify(body: TokenVerifyRequest) -> TokenVerifyResponse:
    _require_jwt()
    secret = _jwt_secret()

    leeway = _jwt_leeway_seconds()

    try:
        claims = jwt.decode(body.token, secret, algorithms=["HS256"], leeway=leeway)
    except Exception as e:
        grace = _verify_grace_seconds()
        if grace > 0:
            try:
                claims2 = jwt.decode(
                    body.token,
                    secret,
                    algorithms=["HS256"],
                    options={"verify_exp": False},
                )
                exp = int(claims2.get("exp", 0) or 0)
                if exp and _now() <= exp + grace:
                    cur_rev = await _get_rev_epoch()
                    tok_rev = int(claims2.get("rev", -1))
                    if tok_rev != cur_rev:
                        return TokenVerifyResponse(
                            valid=False,
                            claims=claims2,
                            reason=f"revoked: token_rev={tok_rev} current_rev={cur_rev}",
                        )
                    return TokenVerifyResponse(
                        valid=True,
                        claims=claims2,
                        reason=f"expired_but_within_grace:{grace}s",
                    )
            except Exception:
                pass

        return TokenVerifyResponse(valid=False, claims=None, reason=f"decode_failed: {e}")

    cur_rev = await _get_rev_epoch()
    tok_rev = int(claims.get("rev", -1))
    if tok_rev != cur_rev:
        return TokenVerifyResponse(
            valid=False,
            claims=claims,
            reason=f"revoked: token_rev={tok_rev} current_rev={cur_rev}",
        )

    return TokenVerifyResponse(valid=True, claims=claims, reason=None)


@app.post(
    "/tokens/revoke",
    response_model=TokenRevokeResponse,
    summary="Revoke all previously issued tokens (bump epoch).",
    dependencies=[Depends(require_admin)],
)
async def tokens_revoke() -> TokenRevokeResponse:
    new_rev = await _bump_rev_epoch()
    return TokenRevokeResponse(rev=new_rev)
