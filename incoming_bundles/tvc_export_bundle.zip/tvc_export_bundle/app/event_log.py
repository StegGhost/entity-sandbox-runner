from __future__ import annotations

import json
import os
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict


def _event_log_path() -> Path:
    raw = (os.getenv("STEGTV_EVENT_LOG_PATH") or "data/execution_events.jsonl").strip()
    return Path(raw)


def _utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def write_event(event: Dict[str, Any]) -> None:
    """
    Append a single StegTV execution event to the local JSONL ledger.

    Best-effort only:
    - creates parent directories if needed
    - never raises to callers on write failure
    """
    try:
        path = _event_log_path()
        path.parent.mkdir(parents=True, exist_ok=True)

        payload = dict(event)
        payload.setdefault("schema_name", "stegtv_execution_event")
        payload.setdefault("schema_version", "1.0.0")
        payload.setdefault("time", _utc_now())
        payload.setdefault("meta", {})

        with path.open("a", encoding="utf-8") as f:
            f.write(json.dumps(payload, ensure_ascii=False) + "\n")
    except Exception:
        # Logging must never break request execution.
        return
