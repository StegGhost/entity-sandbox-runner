import json, os

trigger_path = "payload/runtime/rollback_trigger.json"
latest = "payload/rollback/latest_snapshot.json"

if not os.path.exists(trigger_path):
    print("no trigger"); exit()

data = json.load(open(trigger_path))

if not data.get("rollback_recommended"):
    print("no rollback needed"); exit()

if not os.path.exists(latest):
    print("no snapshot"); exit()

snap = json.load(open(latest))

print({
    "auto_rollback": True,
    "snapshot": snap
})
