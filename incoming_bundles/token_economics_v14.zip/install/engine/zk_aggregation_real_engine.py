
def aggregate_recursive(proofs):
    # placeholder for nova/halo2 aggregation
    return "agg_" + "_".join(proofs)

def verify_aggregated(proofs, agg):
    return aggregate_recursive(proofs) == agg
