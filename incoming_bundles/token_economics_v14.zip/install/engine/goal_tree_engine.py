
def build_goal_tree(root, depth, max_depth):
    if depth >= max_depth:
        return {root: []}
    children = [f"{root}_{i}" for i in range(2)]
    return {root: [build_goal_tree(c, depth+1, max_depth) for c in children]}
