
import random

def rewire(graph, rate=0.2):
    nodes = list(graph.keys())
    for n in nodes:
        if random.random() < rate:
            graph[n] = random.sample(nodes, min(2, len(nodes)))
    return graph
