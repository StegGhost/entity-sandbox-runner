
def generate_subgoals(goal, depth, max_depth):
    if depth >= max_depth:
        return []
    return [f"{goal}_sub_{i}" for i in range(2)]
