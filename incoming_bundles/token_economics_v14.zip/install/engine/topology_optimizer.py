
def optimize_topology(graph):
    # simple heuristic: ensure each node has <=3 connections
    for node, edges in graph.items():
        graph[node] = edges[:3]
    return graph
