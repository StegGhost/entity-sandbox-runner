
from install.engine.zk_aggregation_real_engine import aggregate_recursive, verify_aggregated

def test_zk_real():
    proofs = ["a","b"]
    agg = aggregate_recursive(proofs)
    assert verify_aggregated(proofs, agg)
