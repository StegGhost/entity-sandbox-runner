
from install.engine.recursive_goal_engine import generate_subgoals

def test_recursive():
    subs = generate_subgoals("goal", 0, 3)
    assert len(subs) > 0
