
from install.engine.topology_optimizer import optimize_topology

def test_topo():
    g = {"a":["b","c","d","e"]}
    out = optimize_topology(g)
    assert len(out["a"]) <= 3
