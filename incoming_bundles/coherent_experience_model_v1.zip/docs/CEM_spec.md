# Coherent Experience Model (CEM) v1

Each execution produces:

Eₜ = (Sₜ, Δ, Sₜ₊₁, U, P, R)

Where:
- Sₜ = state before
- Δ = transition
- Sₜ₊₁ = state after
- U = uncertainty
- P = policy
- R = receipt hash

## Modes

ACCEPT: U <= threshold_accept  
REVIEW: threshold_accept < U <= threshold_review  
REJECT: U > threshold_review  

## Chain

Each experience links via:
parent → previous hash

## Purpose

Transform execution into structured, provable experience.
