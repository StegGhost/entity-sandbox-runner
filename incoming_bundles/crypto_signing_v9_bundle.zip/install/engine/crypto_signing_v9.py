import json
import hashlib
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey, Ed25519PublicKey
from cryptography.hazmat.primitives import serialization
import base64

def canonical_json(data):
    return json.dumps(data, sort_keys=True, separators=(",", ":")).encode()

def generate_keypair():
    private_key = Ed25519PrivateKey.generate()
    public_key = private_key.public_key()

    private_bytes = private_key.private_bytes(
        encoding=serialization.Encoding.Raw,
        format=serialization.PrivateFormat.Raw,
        encryption_algorithm=serialization.NoEncryption()
    )

    public_bytes = public_key.public_bytes(
        encoding=serialization.Encoding.Raw,
        format=serialization.PublicFormat.Raw
    )

    return {
        "private_key": base64.b64encode(private_bytes).decode(),
        "public_key": base64.b64encode(public_bytes).decode()
    }

def load_private_key(b64_key):
    return Ed25519PrivateKey.from_private_bytes(base64.b64decode(b64_key))

def load_public_key(b64_key):
    return Ed25519PublicKey.from_public_bytes(base64.b64decode(b64_key))

def sign_data(data, private_key_b64):
    private_key = load_private_key(private_key_b64)
    signature = private_key.sign(canonical_json(data))
    return base64.b64encode(signature).decode()

def verify_signature(data, signature_b64, public_key_b64):
    public_key = load_public_key(public_key_b64)
    try:
        public_key.verify(base64.b64decode(signature_b64), canonical_json(data))
        return True
    except Exception:
        return False

def sign_receipt(receipt, private_key_b64):
    core = receipt.copy()
    core.pop("signature", None)
    signature = sign_data(core, private_key_b64)
    receipt["signature"] = signature
    return receipt

def verify_receipt(receipt, public_key_b64):
    sig = receipt.get("signature")
    if not sig:
        return False, "missing_signature"

    core = receipt.copy()
    core.pop("signature")

    valid = verify_signature(core, sig, public_key_b64)
    return valid, "valid" if valid else "invalid_signature"
