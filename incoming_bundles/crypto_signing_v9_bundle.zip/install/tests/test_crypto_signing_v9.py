from install.engine.crypto_signing_v9 import generate_keypair, sign_receipt, verify_receipt

def test_sign_and_verify():
    keys = generate_keypair()
    receipt = {"a": 1}
    signed = sign_receipt(receipt, keys["private_key"])
    ok, reason = verify_receipt(signed, keys["public_key"])
    assert ok is True

def test_invalid_signature():
    keys = generate_keypair()
    receipt = {"a": 1}
    signed = sign_receipt(receipt, keys["private_key"])
    signed["a"] = 2
    ok, reason = verify_receipt(signed, keys["public_key"])
    assert ok is False
