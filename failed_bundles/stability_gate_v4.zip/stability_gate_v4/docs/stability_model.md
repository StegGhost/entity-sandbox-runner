# Stability Gate v4

## Core Equation

```text
S = (D × M) / (E × A)
```

## v4 Additions

- StegOps-style execution receipts with receipt chaining
- commit-ready state snapshots with deterministic state hashes
- policy trace embedded in receipt payload
- runtime artifact emission to `artifacts/receipts/` and `artifacts/snapshots/`
- mandate strength as an additional threshold control input

## Artifact Types

- `stegops.execution.receipt.v1`
- `stegops.state.snapshot.v1`

## Outcome Rule

```text
allow(action) iff stability_score >= threshold
```

## Commit Record

Every admissibility decision emits a compact commit record containing:

- `decision_id`
- `actor_id`
- `action_id`
- `receipt_hash`
- `state_hash`
- `status`
