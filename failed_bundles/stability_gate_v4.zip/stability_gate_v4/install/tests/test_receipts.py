from engine.receipts import build_receipt


def test_receipt_is_deterministic():
    payload = {'a': 1, 'b': 2}
    r1 = build_receipt(payload)
    r2 = build_receipt(payload)
    assert r1['receipt_hash'] == r2['receipt_hash']
    assert r1['receipt_algo'] == 'sha256'
    assert r1['receipt_type'] == 'stegops.execution.receipt.v1'


def test_receipt_chain_changes_hash():
    payload = {'a': 1}
    r1 = build_receipt(payload)
    r2 = build_receipt(payload, previous_receipt_hash=r1['receipt_hash'])
    assert r1['receipt_hash'] != r2['receipt_hash']
