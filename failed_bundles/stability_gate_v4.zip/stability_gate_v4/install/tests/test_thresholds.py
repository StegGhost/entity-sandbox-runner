from engine.adaptive_threshold import compute_threshold


def test_threshold_rises_with_risk():
    low = compute_threshold(base_threshold=1.0, risk_level=1.0, authority_confidence=1.0, mandate_strength=1.0)
    high = compute_threshold(base_threshold=1.0, risk_level=2.0, authority_confidence=1.0, mandate_strength=1.0)
    assert high > low


def test_threshold_falls_with_stronger_mandate():
    weak = compute_threshold(base_threshold=1.0, risk_level=1.0, authority_confidence=1.0, mandate_strength=0.5)
    strong = compute_threshold(base_threshold=1.0, risk_level=1.0, authority_confidence=1.0, mandate_strength=2.0)
    assert strong < weak
