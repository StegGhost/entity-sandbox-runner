from engine.enforcement import enforce_action
from engine.state_model import SystemState


def test_allowed_action_generates_commit_record():
    state = SystemState(2.0, 1.0, 0.5, 1.0)
    result = enforce_action(state, decision_id='d1', actor_id='guardian', action_id='merge')
    assert result['receipt']['payload']['status'] == 'allowed'
    assert result['commit_record']['decision_id'] == 'd1'
    assert result['commit_record']['action_id'] == 'merge'


def test_blocked_action():
    state = SystemState(0.1, 0.3, 2.0, 2.0)
    result = enforce_action(state)
    assert result['receipt']['payload']['status'] == 'blocked'
