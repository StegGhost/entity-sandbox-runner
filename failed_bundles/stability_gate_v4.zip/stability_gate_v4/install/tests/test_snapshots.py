from engine.enforcement import enforce_action
from engine.state_model import SystemState


def test_snapshot_binds_to_receipt():
    state = SystemState(1.2, 0.9, 0.5, 0.8)
    result = enforce_action(state, decision_id='decision-1')
    assert result['snapshot']['decision_id'] == 'decision-1'
    assert result['snapshot']['receipt_hash'] == result['receipt']['receipt_hash']
    assert result['commit_record']['state_hash'] == result['snapshot']['state_hash']
