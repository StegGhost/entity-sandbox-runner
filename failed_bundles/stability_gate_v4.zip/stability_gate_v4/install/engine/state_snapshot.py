import json
import os
from typing import Any, Dict

from .receipts import sha256_hex


SNAPSHOT_TYPE = 'stegops.state.snapshot.v1'


def build_state_snapshot(state: Dict[str, Any], receipt_hash: str, decision_id: str) -> Dict[str, Any]:
    snapshot = {
        'snapshot_type': SNAPSHOT_TYPE,
        'decision_id': decision_id,
        'receipt_hash': receipt_hash,
        'state': state,
    }
    snapshot['state_hash'] = sha256_hex(snapshot)
    return snapshot


def persist_json(payload: Dict[str, Any], out_dir: str, prefix: str, identifier: str) -> str:
    os.makedirs(out_dir, exist_ok=True)
    safe_id = ''.join(ch if ch.isalnum() or ch in ('-', '_') else '-' for ch in identifier)
    path = os.path.join(out_dir, f'{prefix}_{safe_id}.json')
    with open(path, 'w', encoding='utf-8') as f:
        json.dump(payload, f, indent=2, sort_keys=True)
        f.write('\n')
    return path
