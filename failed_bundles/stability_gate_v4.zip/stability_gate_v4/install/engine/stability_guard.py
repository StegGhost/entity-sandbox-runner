from .state_model import SystemState


def compute_stability_score(state: SystemState) -> float:
    denominator = state.env_volatility * state.action_magnitude
    if denominator == 0:
        return float('inf')
    return (state.deliberation_time * state.model_fidelity) / denominator


def classify_stability(score: float, threshold: float) -> str:
    if score >= threshold:
        return 'stable'
    if score >= threshold * 0.7:
        return 'borderline'
    return 'unstable'
