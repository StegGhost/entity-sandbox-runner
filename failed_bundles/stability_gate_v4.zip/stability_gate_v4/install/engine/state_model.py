from dataclasses import dataclass, field
from typing import Any, Dict, Optional


@dataclass
class SystemState:
    deliberation_time: float
    model_fidelity: float
    env_volatility: float
    action_magnitude: float
    observed_at: Optional[str] = None
    metadata: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        return {
            'deliberation_time': self.deliberation_time,
            'model_fidelity': self.model_fidelity,
            'env_volatility': self.env_volatility,
            'action_magnitude': self.action_magnitude,
            'observed_at': self.observed_at,
            'metadata': self.metadata,
        }
