from typing import Any, Dict


def build_policy_trace(
    base_threshold: float,
    risk_level: float,
    authority_confidence: float,
    mandate_strength: float,
    threshold: float,
) -> Dict[str, Any]:
    return {
        'policy_inputs': {
            'base_threshold': base_threshold,
            'risk_level': risk_level,
            'authority_confidence': authority_confidence,
            'mandate_strength': mandate_strength,
        },
        'resolved_threshold': threshold,
        'policy_version': 'stability_gate_v4',
    }
