def compute_threshold(
    base_threshold: float = 1.0,
    risk_level: float = 1.0,
    authority_confidence: float = 1.0,
    mandate_strength: float = 1.0,
) -> float:
    authority_confidence = max(0.1, min(1.0, authority_confidence))
    risk_level = max(0.1, risk_level)
    mandate_strength = max(0.1, min(2.0, mandate_strength))

    threshold = base_threshold * risk_level * (1.0 / authority_confidence) * (1.0 / mandate_strength)
    return max(0.5, min(5.0, threshold))
