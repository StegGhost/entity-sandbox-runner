from typing import Any, Dict

from .adaptive_threshold import compute_threshold
from .policy_trace import build_policy_trace
from .receipts import build_receipt
from .stability_guard import classify_stability, compute_stability_score
from .state_model import SystemState
from .state_snapshot import build_state_snapshot


def enforce_action(
    state: SystemState,
    base_threshold: float = 1.0,
    risk_level: float = 1.0,
    authority_confidence: float = 1.0,
    mandate_strength: float = 1.0,
    decision_id: str = 'decision',
    actor_id: str = 'system',
    action_id: str = 'action',
    previous_receipt_hash: str = '',
) -> Dict[str, Any]:
    threshold = compute_threshold(
        base_threshold=base_threshold,
        risk_level=risk_level,
        authority_confidence=authority_confidence,
        mandate_strength=mandate_strength,
    )

    score = compute_stability_score(state)
    stability_class = classify_stability(score, threshold)

    if stability_class == 'stable':
        status = 'allowed'
        next_action = 'execute'
    elif stability_class == 'borderline':
        status = 'delay'
        next_action = 'increase_deliberation'
    else:
        status = 'blocked'
        next_action = 'escalate_or_abort'

    state_dict = state.to_dict()
    policy_trace = build_policy_trace(
        base_threshold=base_threshold,
        risk_level=risk_level,
        authority_confidence=authority_confidence,
        mandate_strength=mandate_strength,
        threshold=threshold,
    )

    payload = {
        'decision_id': decision_id,
        'actor_id': actor_id,
        'action_id': action_id,
        'status': status,
        'next_action': next_action,
        'stability_class': stability_class,
        'stability_score': score,
        'threshold': threshold,
        'state': state_dict,
        'policy_trace': policy_trace,
    }

    receipt = build_receipt(payload, previous_receipt_hash=previous_receipt_hash)
    snapshot = build_state_snapshot(
        state=state_dict,
        receipt_hash=receipt['receipt_hash'],
        decision_id=decision_id,
    )

    return {
        'receipt': receipt,
        'snapshot': snapshot,
        'commit_record': {
            'decision_id': decision_id,
            'actor_id': actor_id,
            'action_id': action_id,
            'receipt_hash': receipt['receipt_hash'],
            'state_hash': snapshot['state_hash'],
            'status': status,
        },
    }
