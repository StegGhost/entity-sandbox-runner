import hashlib
import json
from typing import Any, Dict


RECEIPT_TYPE = 'stegops.execution.receipt.v1'


def _canonical_json(payload: Dict[str, Any]) -> str:
    return json.dumps(payload, sort_keys=True, separators=(',', ':'))


def sha256_hex(payload: Dict[str, Any]) -> str:
    return hashlib.sha256(_canonical_json(payload).encode('utf-8')).hexdigest()


def build_receipt(payload: Dict[str, Any], previous_receipt_hash: str = '') -> Dict[str, Any]:
    envelope = {
        'receipt_type': RECEIPT_TYPE,
        'previous_receipt_hash': previous_receipt_hash,
        'payload': payload,
    }
    envelope['receipt_hash'] = sha256_hex(envelope)
    envelope['receipt_algo'] = 'sha256'
    return envelope
