# Formal Model

## Definitions

**Definition 1 (System State)**  
S = (A, P, I, C, E)

**Definition 2 (Decision Function)**  
D(a, s) → {ALLOW, DENY}

**Definition 3 (Decision Surface)**  
A mandatory evaluation function prior to execution.

## Constraint

No action may execute unless D(a, s) = ALLOW
