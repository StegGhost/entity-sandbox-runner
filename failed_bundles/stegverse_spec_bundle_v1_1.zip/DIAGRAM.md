# Architecture Flow

Authority → Control Plane → Decision Surface → Execution → Audit
