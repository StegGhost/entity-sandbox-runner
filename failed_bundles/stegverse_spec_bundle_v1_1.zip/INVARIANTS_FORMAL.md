# Formal Invariants

1. Authority Binding  
2. Mandatory Evaluation  
3. Deterministic Replay  
4. Audit Completeness  
5. No Silent Mutation  
6. Fail-Closed Safety
