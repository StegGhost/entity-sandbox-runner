
from install.engine.topology_engine import add_node, connect, get_topology

def test_topo():
    add_node("a")
    connect("a","b")
    assert "b" in get_topology()["a"]
