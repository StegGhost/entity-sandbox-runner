
from install.engine.zk_aggregation_engine import aggregate_proofs, verify_aggregate

def test_agg():
    proofs = ["a","b"]
    agg = aggregate_proofs(proofs)
    assert verify_aggregate(proofs, agg)
