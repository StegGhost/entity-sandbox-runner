
from install.engine.emergent_goal_engine import generate_goals

def test_goals():
    g = generate_goals([])
    assert len(g) == 1
