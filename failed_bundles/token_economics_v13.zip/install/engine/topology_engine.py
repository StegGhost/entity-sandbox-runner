
GRAPH = {}

def add_node(node):
    GRAPH[node] = []

def connect(a, b):
    GRAPH.setdefault(a, []).append(b)
    GRAPH.setdefault(b, []).append(a)

def get_topology():
    return GRAPH
