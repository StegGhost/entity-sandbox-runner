
def select_goals(goal_scores):
    sorted_goals = sorted(goal_scores, key=goal_scores.get, reverse=True)
    return sorted_goals[:max(1, len(sorted_goals)//2)]
