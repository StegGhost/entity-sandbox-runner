
import random

def generate_goals(existing_goals):
    new_goal = "goal_" + str(random.randint(1,10000))
    return existing_goals + [new_goal]

def score_goals(goals, performance):
    return {g: performance.get(g, random.random()) for g in goals}
