
import hashlib

def aggregate_proofs(proofs):
    agg = "".join(proofs)
    return hashlib.sha256(agg.encode()).hexdigest()

def verify_aggregate(proofs, agg_proof):
    return aggregate_proofs(proofs) == agg_proof
