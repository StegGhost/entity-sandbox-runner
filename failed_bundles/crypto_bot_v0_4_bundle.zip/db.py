import sqlite3

DB_FILE = "trades.db"

def init_db():
    conn = sqlite3.connect(DB_FILE)
    c = conn.cursor()
    c.execute("CREATE TABLE IF NOT EXISTS trades (id INTEGER PRIMARY KEY AUTOINCREMENT, entry_price REAL, exit_price REAL, size REAL, net REAL, timestamp TEXT)")
    conn.commit()
    conn.close()

def log_trade(entry, exit_price, size, net):
    conn = sqlite3.connect(DB_FILE)
    c = conn.cursor()
    c.execute("INSERT INTO trades (entry_price, exit_price, size, net, timestamp) VALUES (?, ?, ?, ?, datetime('now'))",
              (entry, exit_price, size, net))
    conn.commit()
    conn.close()
