v0.4 Features:
- Persistent trade logging (SQLite)
- Restart-safe DB
- Net PnL tracking
- Dry-run trading loop

Run:
pip install requests
python app.py
