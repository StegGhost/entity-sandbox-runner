import time
import requests
from config import *
from db import init_db, log_trade

BASE_URL = "https://api.coinbase.com"
position = None

def get_price():
    url = f"{BASE_URL}/v2/prices/{PAIR}/spot"
    r = requests.get(url).json()
    p = float(r["data"]["amount"])
    return p - 0.5, p + 0.5

def calc_size(price):
    return TRADE_SIZE_USD / price

def net_profit(entry, exit_price, size):
    gross = (exit_price - entry) * size
    fees = (entry + exit_price) * size * FEE_RATE
    return gross - fees - SLIPPAGE_BUFFER

def main():
    global position
    init_db()

    while True:
        bid, ask = get_price()
        print(f"Price: {bid:.2f}/{ask:.2f}")

        if position is None:
            spread = ask - bid
            if spread < SPREAD_LIMIT:
                size = calc_size(bid)
                position = {"entry": bid, "size": size, "time": time.time()}
                print(f"ENTER {bid:.2f}")
        else:
            held = time.time() - position["time"]
            np = net_profit(position["entry"], bid, position["size"])

            if np >= PROFIT_TARGET or held > MAX_HOLD_SECONDS:
                print(f"EXIT {bid:.2f} NET={np:.2f}")
                log_trade(position["entry"], bid, position["size"], np)
                position = None

        time.sleep(2)

if __name__ == "__main__":
    main()
