import json, os

score_path="payload/state_scoring/state_score.json"
score=json.load(open(score_path)) if os.path.exists(score_path) else {}

os.makedirs("marketing/generated",exist_ok=True)

linkedin=f"AI systems cannot prove what they did.\n\nCurrent system score: {score.get('score')}\n\nWe built governed execution infrastructure with receipts, rollback, and enforcement."

x_thread=f"1/ AI systems lack provability\n2/ Score: {score.get('score')}\n3/ We built governed execution\n4/ Receipts + rollback\n5/ This is the future"

substack=f"# Governed Execution\n\nSystem score: {score.get('score')}\n\nWe built a deterministic AI execution system with enforcement and rollback."

open("marketing/generated/linkedin.txt","w").write(linkedin)
open("marketing/generated/x_thread.txt","w").write(x_thread)
open("marketing/generated/substack.md","w").write(substack)

print({"generated_multi":True})
