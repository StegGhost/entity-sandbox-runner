import hashlib, json, time

class ReceiptChain:
    def __init__(self):
        self.chain = []
        self.last_hash = "GENESIS"

    def append(self, payload):
        entry = dict(payload)
        entry["timestamp"] = time.time()
        entry["prev_hash"] = self.last_hash
        entry_hash = self._hash(entry)
        entry["hash"] = entry_hash
        self.chain.append(entry)
        self.last_hash = entry_hash
        return entry

    def _hash(self, payload):
        return hashlib.sha256(json.dumps(payload, sort_keys=True).encode()).hexdigest()
