class ContinuousStateEngine:
    def __init__(self):
        self.state_history = []

    def commit(self, state):
        self.state_history.append(state)

    def latest(self):
        return self.state_history[-1] if self.state_history else {}
