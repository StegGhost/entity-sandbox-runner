class CheckpointManager:
    def __init__(self):
        self.checkpoints = []

    def create(self, state):
        self.checkpoints.append(state)
        return len(self.checkpoints) - 1

    def rollback(self, index):
        if 0 <= index < len(self.checkpoints):
            return self.checkpoints[index]
        return None
