from receipt_chain import ReceiptChain
from continuous_state_engine import ContinuousStateEngine
from checkpoint_manager import CheckpointManager

chain = ReceiptChain()
state_engine = ContinuousStateEngine()
checkpoint_mgr = CheckpointManager()

def apply(node_id, action, state):
    state_engine.commit(state)
    receipt = chain.append({
        "node_id": node_id,
        "action": action,
        "state": state
    })
    if action.get("irreversible"):
        checkpoint_mgr.create(state)
    return {
        "decision": "RECORDED",
        "receipt": receipt,
        "chain_length": len(chain.chain)
    }
