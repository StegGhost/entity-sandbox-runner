class DeterministicReplay:
    def run(self, chain):
        return [entry.get("action") for entry in chain]
