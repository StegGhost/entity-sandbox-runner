# v1.3 Continuous State + Receipt Chain
Adds ledger, replay, and rollback.