
import json
from pathlib import Path

RESULTS = Path("experiments/critical_ratio_campaign/results")
OUT = Path("autonomy_plane/next_run_config.json")

def main():
    summary_file = RESULTS / "merge_summary.json"
    if not summary_file.exists():
        print("No summary found, skipping loop")
        return

    summary = json.loads(summary_file.read_text())
    uc = summary.get("estimated_Uc")
    samples = summary.get("merged_samples", 0)

    next_runs = 50000
    mode = "parallel_8"

    if uc is None:
        mode = "parallel_16"
    elif abs(uc - 1.0) < 0.05:
        next_runs = 80000
    elif samples < 100000:
        next_runs = 60000

    config = {
        "experiment": "critical_ratio_campaign",
        "run_mode": mode,
        "runs_per_shard": str(next_runs)
    }

    OUT.parent.mkdir(parents=True, exist_ok=True)
    OUT.write_text(json.dumps(config, indent=2))
    print("Next run config:", config)

if __name__ == "__main__":
    main()
