
def update_strategy(agent, reward):
    agent['strategy_score'] = agent.get('strategy_score', 0) + reward
    return agent

def choose_action(agent):
    if agent.get('strategy_score', 0) > 50:
        return "high_risk_high_reward"
    return "low_risk"
