
STRATEGIES = {}

def save_strategy(agent_id, strategy):
    STRATEGIES[agent_id] = strategy

def load_strategy(agent_id):
    return STRATEGIES.get(agent_id, None)
