
import hashlib

def generate_proof(data):
    return hashlib.sha256(str(data).encode()).hexdigest()

def verify_proof(data, proof):
    return generate_proof(data) == proof
