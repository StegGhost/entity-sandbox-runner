
class Identity:
    def __init__(self, agent_id):
        self.agent_id = agent_id
        self.reputation = 0

def verify_identity(identity):
    return isinstance(identity.agent_id, str)
