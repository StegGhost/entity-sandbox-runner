
from install.engine.agent_learning_engine import update_strategy

def test_learning():
    agent = {}
    agent = update_strategy(agent, 10)
    assert agent["strategy_score"] == 10
