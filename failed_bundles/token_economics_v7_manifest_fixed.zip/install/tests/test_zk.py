
from install.engine.zk_proof_engine import generate_proof, verify_proof

def test_zk():
    data = "hello"
    proof = generate_proof(data)
    assert verify_proof(data, proof)
