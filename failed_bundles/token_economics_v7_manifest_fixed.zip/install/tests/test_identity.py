
from install.engine.identity_engine import Identity, verify_identity

def test_identity():
    ident = Identity("agent_1")
    assert verify_identity(ident)
