
# Generator V2 Bundle

This bundle fixes capability manifest generation.

## Features
- Correct file vs directory handling
- Scope collapsing (install/, config/, docs/)
- Eliminates invalid trailing slashes on files
- Guarantees ingestion compatibility

## Usage
Run proposal_to_bundle.py inside bundle root to generate manifest.
