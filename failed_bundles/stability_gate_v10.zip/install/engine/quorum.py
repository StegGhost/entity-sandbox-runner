
def quorum_met(votes, threshold=0.66):
    positive = sum(1 for v in votes if v)
    return (positive / len(votes)) >= threshold if votes else False
