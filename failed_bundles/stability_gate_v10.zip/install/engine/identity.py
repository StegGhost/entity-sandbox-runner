
import hashlib
def sign(payload, node_id):
    raw = f"{node_id}:{payload}"
    return hashlib.sha256(raw.encode()).hexdigest()
def verify(payload, signature, node_id):
    return sign(payload, node_id) == signature
