
LOCKS = {}
def acquire(resource, node_id):
    if resource in LOCKS:
        return False
    LOCKS[resource] = node_id
    return True
def release(resource, node_id):
    if LOCKS.get(resource) == node_id:
        del LOCKS[resource]
        return True
    return False
