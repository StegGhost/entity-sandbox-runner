
def reconcile(states):
    return max(states) if states else None
