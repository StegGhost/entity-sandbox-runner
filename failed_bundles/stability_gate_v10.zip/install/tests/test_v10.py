
from engine.identity import sign, verify
from engine.quorum import quorum_met

def test_signature():
    sig = sign("data","node1")
    assert verify("data", sig, "node1")

def test_quorum():
    assert quorum_met([True,True,False]) == True
