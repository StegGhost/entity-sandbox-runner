
from install.engine.mechanism_design_engine import compute_allocation

def test_mech():
    w, p = compute_allocation({"a":1, "b":2})
    assert w == "b"
