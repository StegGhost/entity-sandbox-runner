
from install.engine.equilibrium_engine import detect_equilibrium

def test_eq():
    assert detect_equilibrium([1.0, 1.001]) is True
