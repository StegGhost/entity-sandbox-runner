
from install.engine.zk_pipeline_wired import execute_with_proof

def test_zk():
    out = execute_with_proof({"x":1})
    assert out["verified"] is True
