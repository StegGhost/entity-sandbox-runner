
def match_orders(buy_orders, sell_orders):
    buy_orders.sort(reverse=True)
    sell_orders.sort()
    if buy_orders and sell_orders and buy_orders[0] >= sell_orders[0]:
        return {"price": sell_orders[0]}
    return None
