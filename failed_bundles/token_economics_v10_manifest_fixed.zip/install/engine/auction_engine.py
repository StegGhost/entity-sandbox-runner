
def run_auction(bids):
    winner = max(bids, key=bids.get)
    price = bids[winner]
    return {"winner": winner, "price": price}
