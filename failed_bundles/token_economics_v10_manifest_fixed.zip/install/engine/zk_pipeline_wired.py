
from install.engine.zk_circom_adapter import CircomBackend

def execute_with_proof(data):
    backend = CircomBackend()
    backend.setup()
    proof = backend.prove(data, {"w":1})
    verified = backend.verify(proof, data)
    return {"proof": proof, "verified": verified}
