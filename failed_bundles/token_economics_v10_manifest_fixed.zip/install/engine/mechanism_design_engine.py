
def compute_allocation(bids):
    # simple highest-bid-wins allocation
    winner = max(bids, key=bids.get)
    return winner, bids[winner]

def incentive_compatible(bids, true_values):
    # naive check: truthful bidding yields highest payoff
    return bids == true_values
