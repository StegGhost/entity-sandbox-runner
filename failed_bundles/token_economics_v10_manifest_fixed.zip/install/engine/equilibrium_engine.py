
def detect_equilibrium(rewards_history, threshold=0.01):
    if len(rewards_history) < 2:
        return False
    diff = abs(rewards_history[-1] - rewards_history[-2])
    return diff < threshold
