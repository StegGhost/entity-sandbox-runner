
def validate_across_runners(states):
    return len(set(states.values())) == 1
