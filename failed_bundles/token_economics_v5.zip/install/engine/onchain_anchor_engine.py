
import hashlib

def anchor_to_chain(state_hash, chain="testnet"):
    tx_hash = hashlib.sha256((state_hash + chain).encode()).hexdigest()
    return tx_hash
