
def settle(epoch_valid, rewards_distributed):
    if epoch_valid:
        return {"status": "settled", "rewards": rewards_distributed}
    return {"status": "reverted", "rewards": 0}
