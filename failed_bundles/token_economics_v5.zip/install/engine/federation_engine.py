
def register_runner(runners, runner_id):
    runners.add(runner_id)
    return runners

def broadcast_state(runners, state_hash):
    return {r: state_hash for r in runners}
