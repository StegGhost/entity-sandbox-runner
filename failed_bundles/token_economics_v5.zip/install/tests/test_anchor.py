
from install.engine.onchain_anchor_engine import anchor_to_chain

def test_anchor():
    tx = anchor_to_chain("abc")
    assert isinstance(tx, str)
