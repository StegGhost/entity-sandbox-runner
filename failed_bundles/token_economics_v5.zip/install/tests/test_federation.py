
from install.engine.cross_runner_validation import validate_across_runners

def test_federation():
    states = {"a": "hash1", "b": "hash1"}
    assert validate_across_runners(states) is True
