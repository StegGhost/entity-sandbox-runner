
from engine.core import SystemState, stability, should_rollback

def test_stability_ok():
    s = SystemState(1,1,1,1)
    assert stability(s) == 1

def test_rollback():
    s = SystemState(0.1,0.5,2,2)
    assert should_rollback(stability(s)) == True
