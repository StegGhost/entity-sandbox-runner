
def instability_cost(score):
    if score >= 1:
        return 0
    return (1 - score) * 100
