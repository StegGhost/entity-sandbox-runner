
def merge_receipts(receipts):
    return [r["hash"] for r in receipts]
