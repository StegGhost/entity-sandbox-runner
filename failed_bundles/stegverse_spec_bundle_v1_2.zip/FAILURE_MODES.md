# Failure Modes

- Decision failure → DENY  
- State corruption → halt/rollback  
- Authority drift → detected via logs  
- Replay divergence → nondeterminism detected  
- Constraint violation → blocked
