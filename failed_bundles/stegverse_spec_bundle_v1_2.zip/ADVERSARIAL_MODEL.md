# Adversarial Model

Adversary may:
- propose malicious actions
- spoof identity
- attempt policy changes

System guarantees:
- all actions evaluated
- identity verified
- policy changes logged

No action outside Ω(s) executes undetected.
