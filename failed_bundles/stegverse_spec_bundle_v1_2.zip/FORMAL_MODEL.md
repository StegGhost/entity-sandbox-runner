# Formal Model

## State
S = (A, P, I, C, E)

## Action
a ∈ Actions

## Decision Function
D(a, s) → {ALLOW, DENY}

## State Transition
T(s, a) → s'

If D(a, s) = DENY, then T is undefined.
