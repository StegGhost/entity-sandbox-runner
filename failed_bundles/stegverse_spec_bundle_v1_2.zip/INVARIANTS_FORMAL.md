# Formal Invariants

1. Safety: a ∉ Ω(s) ⇒ execution = false  
2. Determinism: D(a, s) deterministic  
3. State Validity: all reachable states valid  
4. Audit Completeness: all actions logged  
5. Authority Bound: actions trace to A
