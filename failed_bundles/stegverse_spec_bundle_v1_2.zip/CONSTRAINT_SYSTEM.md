# Constraint System

Ω(s) = allowable actions in state s

a executable iff a ∈ Ω(s)

Ω(s) defined by:
- Policy P
- Authority A
- Identity I

∀ a ∉ Ω(s) → execution blocked
