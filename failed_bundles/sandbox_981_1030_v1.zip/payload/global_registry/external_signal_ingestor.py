from pathlib import Path
import json
OUT = Path("global_registry/external_signal_ingestor.json")
def main():
    payload = {"module": "external_signal_ingestor", "status": "initialized"}
    OUT.parent.mkdir(parents=True, exist_ok=True)
    OUT.write_text(json.dumps(payload, indent=2))
if __name__ == "__main__":
    main()
