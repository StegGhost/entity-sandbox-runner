from pathlib import Path
import json
OUT = Path("global_registry/hierarchical_controller.json")
def main():
    payload = {"module": "hierarchical_controller", "status": "initialized"}
    OUT.parent.mkdir(parents=True, exist_ok=True)
    OUT.write_text(json.dumps(payload, indent=2))
if __name__ == "__main__":
    main()
