from pathlib import Path
import json
OUT = Path("global_registry/latent_space_explorer.json")
def main():
    payload = {"module": "latent_space_explorer", "status": "initialized"}
    OUT.parent.mkdir(parents=True, exist_ok=True)
    OUT.write_text(json.dumps(payload, indent=2))
if __name__ == "__main__":
    main()
