from pathlib import Path
import json
OUT = Path("sandbox_service/decision_trace_logger.json")
def main():
    payload = {"module": "decision_trace_logger", "status": "initialized"}
    OUT.parent.mkdir(parents=True, exist_ok=True)
    OUT.write_text(json.dumps(payload, indent=2))
if __name__ == "__main__":
    main()
