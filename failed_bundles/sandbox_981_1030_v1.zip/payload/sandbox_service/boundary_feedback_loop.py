from pathlib import Path
import json
OUT = Path("sandbox_service/boundary_feedback_loop.json")
def main():
    payload = {"module": "boundary_feedback_loop", "status": "initialized"}
    OUT.parent.mkdir(parents=True, exist_ok=True)
    OUT.write_text(json.dumps(payload, indent=2))
if __name__ == "__main__":
    main()
