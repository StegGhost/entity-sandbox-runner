from pathlib import Path
import json
OUT = Path("discovery_engine/override_policy_gate.json")
def main():
    payload = {"module": "override_policy_gate", "status": "initialized"}
    OUT.parent.mkdir(parents=True, exist_ok=True)
    OUT.write_text(json.dumps(payload, indent=2))
if __name__ == "__main__":
    main()
