from pathlib import Path
import json
OUT = Path("autonomy_plane/human_in_the_loop_bridge.json")
def main():
    payload = {"module": "human_in_the_loop_bridge", "status": "initialized"}
    OUT.parent.mkdir(parents=True, exist_ok=True)
    OUT.write_text(json.dumps(payload, indent=2))
if __name__ == "__main__":
    main()
