from pathlib import Path
import json
OUT = Path("autonomy_plane/exploration_policy_switcher.json")
def main():
    payload = {"module": "exploration_policy_switcher", "status": "initialized"}
    OUT.parent.mkdir(parents=True, exist_ok=True)
    OUT.write_text(json.dumps(payload, indent=2))
if __name__ == "__main__":
    main()
