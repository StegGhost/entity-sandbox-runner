from pathlib import Path
import json
OUT = Path("autonomy_plane/long_horizon_planner.json")
def main():
    payload = {"module": "long_horizon_planner", "status": "initialized"}
    OUT.parent.mkdir(parents=True, exist_ok=True)
    OUT.write_text(json.dumps(payload, indent=2))
if __name__ == "__main__":
    main()
