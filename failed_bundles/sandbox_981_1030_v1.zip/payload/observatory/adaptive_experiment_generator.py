from pathlib import Path
import json
OUT = Path("observatory/adaptive_experiment_generator.json")
def main():
    payload = {"module": "adaptive_experiment_generator", "status": "initialized"}
    OUT.parent.mkdir(parents=True, exist_ok=True)
    OUT.write_text(json.dumps(payload, indent=2))
if __name__ == "__main__":
    main()
