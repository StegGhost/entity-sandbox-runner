from pathlib import Path
import json
OUT = Path("observatory/experiment_chain_builder.json")
def main():
    payload = {"module": "experiment_chain_builder", "status": "initialized"}
    OUT.parent.mkdir(parents=True, exist_ok=True)
    OUT.write_text(json.dumps(payload, indent=2))
if __name__ == "__main__":
    main()
