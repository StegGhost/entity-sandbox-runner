
def scenario_sybil():
    return {"type": "sybil", "impact": "high"}

def scenario_spam():
    return {"type": "spam", "impact": "medium"}
