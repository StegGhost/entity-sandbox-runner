
from install.engine.attack_simulation_engine import evaluate_outcome

def test_attack():
    assert evaluate_outcome("exploit") == "hard_slash"
