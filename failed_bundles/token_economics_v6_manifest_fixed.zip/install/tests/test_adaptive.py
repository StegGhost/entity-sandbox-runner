
from install.engine.adaptive_governance_engine import adjust_parameters

def test_adjust():
    out = adjust_parameters({"failure_rate":0.5,"throughput":0.4,"reward_pool":100})
    assert "slash_multiplier" in out
