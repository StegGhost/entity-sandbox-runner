
def dynamic_slash(base_slash, history):
    return base_slash * (1 + len(history) * 0.1)
