
def adjust_parameters(metrics):
    # metrics: dict with failure_rate, throughput, reward_pool
    adjustments = {}
    if metrics["failure_rate"] > 0.3:
        adjustments["slash_multiplier"] = 1.2
    if metrics["throughput"] < 0.5:
        adjustments["reward_boost"] = 1.1
    return adjustments
