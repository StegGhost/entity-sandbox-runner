
import random

def simulate_attack(agent):
    # simulate malicious behavior
    return random.choice(["honest", "spam", "exploit"])

def evaluate_outcome(behavior):
    if behavior == "exploit":
        return "hard_slash"
    elif behavior == "spam":
        return "medium_slash"
    return "reward"
