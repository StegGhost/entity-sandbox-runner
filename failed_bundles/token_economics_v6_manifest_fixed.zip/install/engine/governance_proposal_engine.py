
def submit_proposal(params):
    return {"proposal": params, "status": "pending"}

def vote(proposal, votes):
    approvals = sum(votes)
    return approvals > len(votes) / 2
