TC/TVC Platform Bundle v0.2

Installs:

- control_plane
- security_plane
- evidence_plane
- observatory

Purpose:
Provide governance runtime scaffolding for sandbox research experiments.
