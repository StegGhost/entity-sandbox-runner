from pathlib import Path

ROOT = Path.cwd()

REQUIRED_PATHS = [
    "control_plane",
    "security_plane",
    "evidence_plane",
    "observatory"
]

def verify():
    for p in REQUIRED_PATHS:
        if not (ROOT / p).exists():
            raise RuntimeError(f"missing required install path: {p}")
    return True

if __name__ == "__main__":
    verify()
