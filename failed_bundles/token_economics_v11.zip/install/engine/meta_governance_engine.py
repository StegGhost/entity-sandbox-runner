
def adjust_mechanism(params, performance):
    if performance < 0.5:
        params["reward_bias"] *= 1.1
    else:
        params["reward_bias"] *= 0.95
    return params
