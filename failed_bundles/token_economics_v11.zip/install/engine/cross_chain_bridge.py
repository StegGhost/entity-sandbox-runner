
def relay_state(state_hash, chain):
    return f"{chain}_tx_{state_hash}"

def verify_cross_chain(states):
    return len(set(states)) == 1
