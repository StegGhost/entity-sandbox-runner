
def relay(states, chains):
    relayed = {}
    for c in chains:
        relayed[c] = states
    return relayed
