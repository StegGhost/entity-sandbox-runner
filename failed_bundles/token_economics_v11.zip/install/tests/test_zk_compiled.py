
from install.engine.zk_compiled_pipeline import run_compiled_pipeline

def test_zk():
    out = run_compiled_pipeline({"x":1})
    assert out["verified"] is True
