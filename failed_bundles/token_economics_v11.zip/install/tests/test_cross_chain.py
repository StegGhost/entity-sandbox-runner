
from install.engine.cross_chain_bridge import verify_cross_chain

def test_chain():
    assert verify_cross_chain(["a","a"]) is True
