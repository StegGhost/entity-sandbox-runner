
from install.engine.meta_governance_engine import adjust_mechanism

def test_meta():
    params = {"reward_bias":1.0}
    out = adjust_mechanism(params, 0.4)
    assert out["reward_bias"] > 1.0
