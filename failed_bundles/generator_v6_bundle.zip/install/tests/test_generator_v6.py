
from install.engine.proposal_to_bundle import build_manifest

def test_chain_present():
    m = build_manifest("sample_bundle")
    assert "receipt" in m
    assert "current" in m["receipt"]
