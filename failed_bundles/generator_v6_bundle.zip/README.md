
# Generator V6 Bundle

## Receipt Chain Linking + State Continuity

- Links current receipt to previous receipt
- Stores local state in .receipt_state.json
- Enables full execution lineage

This is the foundation for trust scoring, replay, and slashing.
