
NETWORKS = {}
def register_network(name, state):
    NETWORKS[name] = state
def get_networks():
    return NETWORKS
