
def generate_proof(data):
    return f"proof::{hash(str(data))}"
def verify_proof(data, proof):
    return proof == f"proof::{hash(str(data))}"
