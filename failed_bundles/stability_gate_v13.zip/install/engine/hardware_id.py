
def get_hardware_id():
    return "secure-enclave-id-placeholder"
