
def stability_price(score):
    if score >= 1:
        return 1
    return 1 + (1 - score) * 10
