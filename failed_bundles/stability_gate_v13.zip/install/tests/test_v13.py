
from engine.zk_proof import generate_proof, verify_proof
def test_proof():
    p = generate_proof("data")
    assert verify_proof("data", p)
