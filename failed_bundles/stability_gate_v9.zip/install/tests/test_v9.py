
from engine.core import SystemState, stability
from engine.consensus import is_stable
def test_weighted():
    s1 = SystemState(1,1,1,1)
    s2 = SystemState(0.5,1,1,1)
    scores = [stability(s1), stability(s2)]
    weights = [0.7,0.3]
    assert is_stable(scores, weights) == True
