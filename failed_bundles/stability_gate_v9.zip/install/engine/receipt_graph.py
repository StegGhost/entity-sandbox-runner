
GRAPH = {}
def add_receipt(hash, parents):
    GRAPH[hash] = parents
def get_graph():
    return GRAPH
