
def prepare(score, threshold):
    return score >= threshold
def commit(prepared):
    return prepared
def finalize(committed):
    return committed
