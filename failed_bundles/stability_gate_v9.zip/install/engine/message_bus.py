
EVENT_LOG = []
def publish(event):
    EVENT_LOG.append(event)
def consume():
    events = EVENT_LOG.copy()
    EVENT_LOG.clear()
    return events
