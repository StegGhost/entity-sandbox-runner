
def weighted_consensus(scores, weights):
    total = sum(w * s for s, w in zip(scores, weights))
    norm = sum(weights)
    return total / norm if norm else 0
def is_stable(scores, weights, threshold=1.0):
    return weighted_consensus(scores, weights) >= threshold
