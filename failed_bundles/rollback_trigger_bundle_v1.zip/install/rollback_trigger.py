import json, os
safe=json.load(open("payload/runtime/safe_mode.json")) if os.path.exists("payload/runtime/safe_mode.json") else {}
trigger=safe.get("safe_mode",False)
res={"rollback_recommended":trigger}
if trigger and os.path.exists("payload/rollback/latest_snapshot.json"):
    res["snapshot"]=json.load(open("payload/rollback/latest_snapshot.json"))
os.makedirs("payload/runtime",exist_ok=True)
json.dump(res,open("payload/runtime/rollback_trigger.json","w"),indent=2)
print(res)
