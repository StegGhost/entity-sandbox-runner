
import json
from pathlib import Path

STATE_FILE = Path("autonomy_plane/campaign_state.json")

def load():
    if STATE_FILE.exists():
        return json.loads(STATE_FILE.read_text())
    return {
        "runs": 0,
        "total_samples": 0,
        "uc_history": []
    }

def save(state):
    STATE_FILE.parent.mkdir(parents=True, exist_ok=True)
    STATE_FILE.write_text(json.dumps(state, indent=2))

if __name__ == "__main__":
    s = load()
    print(json.dumps(s, indent=2))
