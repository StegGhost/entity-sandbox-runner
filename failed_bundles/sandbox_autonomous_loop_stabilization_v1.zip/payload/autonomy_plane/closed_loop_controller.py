
import json
from pathlib import Path
from statistics import mean

RESULTS = Path("experiments/critical_ratio_campaign/results")
STATE_FILE = Path("autonomy_plane/campaign_state.json")
OUT = Path("autonomy_plane/next_run_config.json")

MAX_RUNS = 20
CONVERGENCE_EPS = 0.01
MIN_HISTORY = 3

def load_state():
    if STATE_FILE.exists():
        return json.loads(STATE_FILE.read_text())
    return {"runs": 0, "total_samples": 0, "uc_history": []}

def save_state(state):
    STATE_FILE.parent.mkdir(parents=True, exist_ok=True)
    STATE_FILE.write_text(json.dumps(state, indent=2))

def main():
    summary_file = RESULTS / "merge_summary.json"
    if not summary_file.exists():
        print("No summary found")
        return

    summary = json.loads(summary_file.read_text())
    uc = summary.get("estimated_Uc")
    samples = summary.get("merged_samples", 0)

    state = load_state()
    state["runs"] += 1
    state["total_samples"] += samples

    if uc is not None:
        state["uc_history"].append(uc)

    # Stop condition
    if state["runs"] >= MAX_RUNS:
        print("Max runs reached. Stopping.")
        return

    if len(state["uc_history"]) >= MIN_HISTORY:
        recent = state["uc_history"][-MIN_HISTORY:]
        if max(recent) - min(recent) < CONVERGENCE_EPS:
            print("Converged. Stopping loop.")
            return

    # Decide next run
    next_runs = 50000
    mode = "parallel_8"

    if uc is None:
        mode = "parallel_16"
    elif abs(uc - 1.0) < 0.05:
        next_runs = 80000
    elif samples < 100000:
        next_runs = 60000

    config = {
        "experiment": "critical_ratio_campaign",
        "run_mode": mode,
        "runs_per_shard": str(next_runs)
    }

    save_state(state)

    OUT.parent.mkdir(parents=True, exist_ok=True)
    OUT.write_text(json.dumps(config, indent=2))
    print("Next run:", config)

if __name__ == "__main__":
    main()
