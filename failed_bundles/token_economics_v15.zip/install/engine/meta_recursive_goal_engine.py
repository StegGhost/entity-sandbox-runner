
def generate_meta_goals(goal, depth, max_depth):
    if depth >= max_depth:
        return []
    return [f"{goal}_meta_{i}" for i in range(2)]
