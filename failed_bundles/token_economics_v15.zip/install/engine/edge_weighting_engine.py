
def weight_edges(graph, throughput_map):
    weights = {}
    for node, neighbors in graph.items():
        weights[node] = sum(throughput_map.get(n,0) for n in neighbors)
    return weights
