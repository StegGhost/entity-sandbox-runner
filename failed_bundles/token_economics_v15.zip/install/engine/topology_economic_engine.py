
def compute_node_value(node, connections, throughput):
    return throughput * len(connections)
