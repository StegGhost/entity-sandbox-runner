
def reflect_on_goals(goals, outcomes):
    return {g: outcomes.get(g, 0) * 1.1 for g in goals}
