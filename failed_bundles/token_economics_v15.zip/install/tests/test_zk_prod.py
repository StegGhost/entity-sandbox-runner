
from install.engine.zk_production_aggregator import aggregate_proofs_prod, verify_prod_agg

def test_zk_prod():
    proofs = ["a","b"]
    agg = aggregate_proofs_prod(proofs)
    assert verify_prod_agg(proofs, agg)
