
from install.engine.topology_economic_engine import compute_node_value

def test_topo_econ():
    val = compute_node_value("a", ["b","c"], 10)
    assert val == 20
