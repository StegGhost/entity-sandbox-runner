
from install.engine.meta_recursive_goal_engine import generate_meta_goals

def test_meta():
    out = generate_meta_goals("goal", 0, 2)
    assert len(out) > 0
