from pydantic import BaseModel, Field
from typing import Any


class TuneRequest(BaseModel):
    params: dict[str, float] = Field(default_factory=dict)
    metrics: dict[str, float] = Field(default_factory=dict)


class ExecuteRequest(BaseModel):
    bundle_name: str
    risk_level: str = "medium"
    payload: dict[str, Any] = Field(default_factory=dict)
