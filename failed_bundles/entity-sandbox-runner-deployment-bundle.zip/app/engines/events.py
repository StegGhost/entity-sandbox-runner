from collections import deque

EVENTS = deque(maxlen=100)


def emit_event(event: dict) -> None:
    EVENTS.append(event)


def get_events() -> list[dict]:
    return list(EVENTS)
