METRICS: dict[str, float] = {
    "success": 0,
    "failure": 0,
    "throughput": 1.0,
    "latency_ms": 25.0,
}


def record_success() -> None:
    METRICS["success"] += 1


def record_failure() -> None:
    METRICS["failure"] += 1


def get_metrics() -> dict[str, float]:
    total = METRICS["success"] + METRICS["failure"]
    failure_rate = (METRICS["failure"] / total) if total else 0.0
    return {**METRICS, "failure_rate": failure_rate}
