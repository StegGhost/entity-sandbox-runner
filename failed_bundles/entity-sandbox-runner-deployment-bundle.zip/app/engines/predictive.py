def forecast(metric_history: list[float]) -> list[float]:
    if len(metric_history) < 2:
        return metric_history
    trend = metric_history[-1] - metric_history[-2]
    return [metric_history[-1] + i * trend for i in range(1, 6)]


def recommend(metrics: dict[str, float]) -> list[str]:
    recs: list[str] = []
    if metrics.get("failure_rate", 0.0) > 0.3:
        recs.append("Increase slashing severity")
    if metrics.get("throughput", 1.0) < 0.5:
        recs.append("Increase rewards for execution")
    if metrics.get("latency_ms", 0.0) > 200:
        recs.append("Scale worker pool or reduce verification batch size")
    return recs


def auto_tune(params: dict[str, float], metrics: dict[str, float], rate: float = 0.1) -> dict[str, float]:
    tuned = dict(params)
    if metrics.get("failure_rate", 0.0) > 0.3:
        tuned["slash_rate"] = tuned.get("slash_rate", 1.0) * (1 + rate)
    if metrics.get("throughput", 1.0) < 0.5:
        tuned["reward_rate"] = tuned.get("reward_rate", 1.0) * (1 + rate)
    if metrics.get("latency_ms", 0.0) > 200:
        tuned["verification_batch_size"] = max(1.0, tuned.get("verification_batch_size", 8.0) * (1 - rate))
    return tuned
