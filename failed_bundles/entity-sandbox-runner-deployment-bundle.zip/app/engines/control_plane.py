SYSTEM_STATE: dict[str, str] = {"system": "running"}


def update_state(key: str, value: str) -> None:
    SYSTEM_STATE[key] = value


def get_state() -> dict[str, str]:
    return dict(SYSTEM_STATE)
