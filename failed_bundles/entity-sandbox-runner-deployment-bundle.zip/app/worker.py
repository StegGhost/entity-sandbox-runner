import time
from app.engines.events import emit_event


def main() -> None:
    while True:
        emit_event({"type": "worker_heartbeat", "message": "worker alive"})
        time.sleep(15)


if __name__ == "__main__":
    main()
