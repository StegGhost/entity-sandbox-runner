from fastapi import Depends, FastAPI, Header, HTTPException
from app.config import settings
from app.models import ExecuteRequest, TuneRequest
from app.engines.control_plane import get_state, update_state
from app.engines.events import emit_event, get_events
from app.engines.execution import execute_bundle
from app.engines.metrics import get_metrics
from app.engines.predictive import auto_tune, forecast, recommend

app = FastAPI(title="Entity Sandbox Runner Control Plane", version="1.0.0")


def require_admin(x_admin_token: str | None = Header(default=None)) -> None:
    if x_admin_token != settings.admin_token:
        raise HTTPException(status_code=401, detail="unauthorized")


@app.get("/healthz")
def healthz() -> dict:
    return {"ok": True, "node_id": settings.runner_node_id}


@app.get("/state")
def state() -> dict:
    return get_state()


@app.post("/state", dependencies=[Depends(require_admin)])
def set_state(body: dict) -> dict:
    for key, value in body.items():
        update_state(str(key), str(value))
    emit_event({"type": "state_updated", "body": body})
    return {"updated": True, "state": get_state()}


@app.get("/metrics")
def metrics() -> dict:
    return get_metrics()


@app.get("/events")
def events() -> list[dict]:
    return get_events()


@app.post("/execute", dependencies=[Depends(require_admin)])
def execute(req: ExecuteRequest) -> dict:
    return execute_bundle(req.bundle_name, req.risk_level, req.payload)


@app.get("/forecast")
def forecast_view() -> dict:
    m = get_metrics()
    series = [max(0.0, m["failure_rate"] - 0.02), m["failure_rate"]]
    return {"failure_rate_forecast": forecast(series)}


@app.get("/recommendations")
def recommendations() -> dict:
    return {"recommendations": recommend(get_metrics())}


@app.post("/tune", dependencies=[Depends(require_admin)])
def tune(req: TuneRequest) -> dict:
    tuned = auto_tune(req.params, req.metrics)
    emit_event({"type": "auto_tune_applied", "params": tuned})
    return {"params": tuned, "auto_tune_enabled": settings.auto_tune_enabled}


@app.get("/dashboard")
def dashboard() -> dict:
    m = get_metrics()
    return {
        "metrics": m,
        "state": get_state(),
        "events": get_events(),
        "recommendations": recommend(m),
        "forecast": forecast([max(0.0, m["failure_rate"] - 0.02), m["failure_rate"]]),
    }
