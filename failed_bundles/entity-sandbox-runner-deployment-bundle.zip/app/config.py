from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    admin_token: str = "change-me"
    database_url: str = "postgresql://postgres:postgres@postgres:5432/esr"
    redis_url: str = "redis://redis:6379/0"
    runner_node_id: str = "node-a"
    auto_tune_enabled: bool = True

    model_config = SettingsConfigDict(env_file=".env", extra="ignore")


settings = Settings()
