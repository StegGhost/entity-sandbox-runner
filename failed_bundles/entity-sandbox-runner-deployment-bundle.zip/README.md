# entity-sandbox-runner-deployment

Production starter repo for deploying the entity-sandbox-runner control plane, execution workers,
observability endpoints, and CI/CD workflows.

## What this repo contains

- FastAPI control plane
- worker service scaffold
- Redis + Postgres via Docker Compose
- health, metrics, state, forecast, recommend, and auto-tune endpoints
- GitHub Actions CI workflow
- Render blueprint
- Fly.io app config
- Dockerfiles for API and worker
- simple tests

## Services

- `api`: FastAPI control plane
- `worker`: execution worker scaffold
- `redis`: live/shared state
- `postgres`: persistent event/state log

## Quick start

```bash
cp .env.example .env
docker compose up --build
```

Open:
- API docs: `http://localhost:8000/docs`
- Health: `http://localhost:8000/healthz`
- Metrics: `http://localhost:8000/metrics`
- Dashboard: `http://localhost:8000/dashboard`

## Key environment variables

- `ADMIN_TOKEN`
- `DATABASE_URL`
- `REDIS_URL`
- `RUNNER_NODE_ID`
- `AUTO_TUNE_ENABLED`

## Recommended deployment path

1. Deploy API to Render or Fly.io
2. Deploy worker as separate service
3. Use managed Postgres + Redis
4. Point UI layer at `/dashboard`, `/events`, `/forecast`, `/recommendations`

## Notes

This repo is intentionally modular so your v1-v19 bundle logic can be mounted into
`app/engines/` incrementally without rewriting the deployment shell.
