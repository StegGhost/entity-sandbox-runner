from fastapi.testclient import TestClient
from app.main import app

client = TestClient(app)


def test_dashboard():
    r = client.get("/dashboard")
    assert r.status_code == 200
    body = r.json()
    assert "metrics" in body
    assert "state" in body
    assert "recommendations" in body
