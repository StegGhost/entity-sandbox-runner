# Entity Sandbox Runner

Entity Sandbox Runner orchestrates sandbox experiments used to explore GCAT / BCAT admissibility dynamics in a controlled environment.

The repository provides everything needed to run experiments, record state transitions, and generate structured outputs for later analysis.

Experiments simulate governed state transitions and evaluate whether those transitions remain inside defined admissibility bounds.

The system is intentionally designed to run in isolation so that experimental code and outputs remain separate from operational systems.

---

# Purpose

This repository supports structured experimentation with governed autonomous systems.

It enables:

• Automation — run sandbox experiments locally or through CI workflows  
• Observability — generate readable summaries and receipt chains  
• Isolation — keep experimental systems separate from production environments  
• Reproducibility — deterministic simulation runs  

Experiments simulate state evolution and verify whether proposed transitions remain admissible.

---

# Repository Structure

```text
entity-sandbox-runner
│
├─ experiments
│   ├─ admissibility
│   ├─ interaction
│   └─ conflict
│
├─ runner
│   ├─ orchestrator.py
│   ├─ scenario_loader.py
│   ├─ result_writer.py
│   ├─ handoff.py
│   └─ visualize_run.py
│
├─ sandbox
│   └─ phase_space.py
│
├─ entities
├─ results
└─ manifests
```

### experiments/

Contains sandbox experiment definitions.

Each experiment includes:

• configuration parameters  
• transition rules  
• expected admissibility behavior  

### runner/

Core orchestration utilities used to execute experiments and generate output artifacts.

### sandbox/

Contains analysis and visualization utilities for sandbox runs.

### results/

Stores experiment outputs such as transition receipts, summaries, and visualizations.

### manifests/

Contains metadata describing completed experiment runs.

---

# Running Experiments

Install dependencies:

```sh
python -m pip install -r requirements.txt
```

Run an experiment:

```sh
python runner/orchestrator.py --experiment experiments/admissibility/simple_test
```

Generate visualizations from a results file:

```sh
python runner/visualize_run.py --results results/simple_test_results.json
```

Outputs are written into:

```text
results/
results/visuals/
manifests/
```

---

# Experiment Outputs

Each run produces:

**Results**

```text
results/<experiment>_results.json
```

Contains:

- state transitions
- admissibility evaluations
- final state

**Manifest**

```text
manifests/<experiment>_handoff.json
```

Contains metadata describing the run.

**Visualizations**

```text
results/visuals/<experiment>_pressure_vs_bound.png
results/visuals/<experiment>_g_t_phase_space.png
results/visuals/<experiment>_visualization_manifest.json
```

These show how artifact pressure evolves relative to the admissibility boundary and how the run moves through GCAT state space.

---

# Extending the Sandbox

New experiments can be added under `experiments/`.

The recommended pattern is:

1. define a config file  
2. run the scenario through the orchestrator  
3. generate the handoff manifest  
4. visualize the resulting run  
5. pass normalized outputs into downstream governance tooling