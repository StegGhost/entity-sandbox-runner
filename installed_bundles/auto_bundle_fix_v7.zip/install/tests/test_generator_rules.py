
def test_generator_rule_creation():
    from install.engine.proposal_to_bundle import update_generator_rules

    memory = {
        "patterns": {
            "capability_violation:bad.py": {"count": 2}
        },
        "generator_rules": {}
    }

    update_generator_rules(memory)
    assert memory["generator_rules"]["bad.py"] == "install/engine/"
