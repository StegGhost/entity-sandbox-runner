
import json
import os
import shutil

BASE_ALLOWED_PATHS = [
    "bundle_manifest.json",
    "install/tests/",
    "install/engine/",
    "install/apply.py",
    "install/config/"
]

MAX_RETRIES = 3
MEMORY_PATH = "install/config/repair_memory.json"

def load_memory(bundle_root):
    path = os.path.join(bundle_root, MEMORY_PATH)
    if os.path.exists(path):
        with open(path) as f:
            return json.load(f)
    return {"patterns": {}, "rules": {}, "generator_rules": {}}

def save_memory(bundle_root, memory):
    path = os.path.join(bundle_root, MEMORY_PATH)
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w") as f:
        json.dump(memory, f, indent=2)

def record_failure(memory, reason):
    memory["patterns"].setdefault(reason, {"count": 0})
    memory["patterns"][reason]["count"] += 1

# --- NEW: Generator rule synthesis ---
def update_generator_rules(memory):
    for reason, data in memory.get("patterns", {}).items():
        if data["count"] >= 2 and reason.startswith("capability_violation:"):
            bad_path = reason.split(":", 1)[1]

            # learn where file SHOULD go
            filename = os.path.basename(bad_path)
            memory["generator_rules"][filename] = "install/engine/"

# --- NEW: Apply generator rewrite rules BEFORE generation ---
def apply_generator_rules(bundle_root, memory):
    rules = memory.get("generator_rules", {})
    for root, _, files in os.walk(bundle_root):
        for file in files:
            if file in rules:
                src = os.path.join(root, file)
                target_dir = os.path.join(bundle_root, rules[file])
                os.makedirs(target_dir, exist_ok=True)
                dst = os.path.join(target_dir, file)

                if os.path.abspath(src) != os.path.abspath(dst):
                    shutil.move(src, dst)

# --- NEW: Dynamic allowed_paths expansion ---
def build_allowed_paths(memory):
    allowed = list(BASE_ALLOWED_PATHS)

    # if generator rules exist, ensure their targets are allowed
    for target in memory.get("generator_rules", {}).values():
        if target not in allowed:
            allowed.append(target)

    return allowed

def build_manifest(bundle_name, memory, bundle_version="1.0.0"):
    return {
        "bundle_name": bundle_name,
        "bundle_version": bundle_version,
        "install_mode": "folder_map",
        "allowed_paths": build_allowed_paths(memory)
    }

def simulate_ingestion(bundle_root):
    manifest_path = os.path.join(bundle_root, "bundle_manifest.json")
    if not os.path.exists(manifest_path):
        return False, "missing_manifest"

    with open(manifest_path) as f:
        manifest = json.load(f)

    allowed = manifest.get("allowed_paths", [])

    for root, _, files in os.walk(bundle_root):
        for file in files:
            rel_path = os.path.relpath(os.path.join(root, file), bundle_root)

            if rel_path == "bundle_manifest.json":
                continue

            valid = False
            for path in allowed:
                if path.endswith("/") and rel_path.startswith(path):
                    valid = True
                elif rel_path == path:
                    valid = True

            if not valid:
                return False, f"capability_violation:{rel_path}"

    return True, "ok"

def ensure_structure(bundle_root):
    os.makedirs(os.path.join(bundle_root, "install/tests"), exist_ok=True)
    os.makedirs(os.path.join(bundle_root, "install/engine"), exist_ok=True)
    os.makedirs(os.path.join(bundle_root, "install/config"), exist_ok=True)

    apply_path = os.path.join(bundle_root, "install/apply.py")
    if not os.path.exists(apply_path):
        with open(apply_path, "w") as f:
            f.write("def apply():\n    print(\"Bundle applied successfully.\")\n")

def auto_repair(bundle_root, reason, memory):
    record_failure(memory, reason)

    if reason.startswith("capability_violation:"):
        bad_path = reason.split(":", 1)[1]
        full_path = os.path.join(bundle_root, bad_path)

        quarantine_dir = os.path.join(bundle_root, "quarantine")
        os.makedirs(quarantine_dir, exist_ok=True)

        if os.path.exists(full_path):
            shutil.move(full_path, os.path.join(quarantine_dir, os.path.basename(bad_path)))
        return True

    if reason == "missing_manifest":
        return True

    return False

def build_bundle(bundle_root, bundle_name):
    ensure_structure(bundle_root)
    memory = load_memory(bundle_root)

    # --- APPLY learned generator rules BEFORE anything ---
    apply_generator_rules(bundle_root, memory)

    manifest = build_manifest(bundle_name, memory)
    with open(os.path.join(bundle_root, "bundle_manifest.json"), "w") as f:
        json.dump(manifest, f, indent=2)

    for _ in range(MAX_RETRIES):
        ok, reason = simulate_ingestion(bundle_root)
        if ok:
            update_generator_rules(memory)
            save_memory(bundle_root, memory)
            return True

        repaired = auto_repair(bundle_root, reason, memory)
        if not repaired:
            save_memory(bundle_root, memory)
            raise Exception(f"UNRECOVERABLE:{reason}")

    update_generator_rules(memory)
    save_memory(bundle_root, memory)
    raise Exception(f"MAX_RETRIES_EXCEEDED:{reason}")
