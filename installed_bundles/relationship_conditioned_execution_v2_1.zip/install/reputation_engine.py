class ReputationEngine:
    def update(self, profile, outcome):
        if outcome == "failure":
            profile["reputation"] = max(0.0, profile.get("reputation", 0.5) - 0.1)
        elif outcome == "success":
            profile["reputation"] = min(1.0, profile.get("reputation", 0.5) + 0.05)
        return profile
