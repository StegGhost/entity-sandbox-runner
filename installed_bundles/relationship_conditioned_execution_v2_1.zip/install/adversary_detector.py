class AdversaryDetector:
    def detect(self, agent_history):
        failures = sum(1 for h in agent_history if h.get("outcome") == "failure")
        if failures > len(agent_history) * 0.5:
            return True
        return False
