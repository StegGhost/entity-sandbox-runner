from adversary_detector import AdversaryDetector
from reputation_engine import ReputationEngine
from slashing_engine import SlashingEngine
from byzantine_filter import ByzantineFilter

detector = AdversaryDetector()
rep_engine = ReputationEngine()
slasher = SlashingEngine()
filter_engine = ByzantineFilter()

def apply(agent_profiles, histories):

    updated_profiles = {}

    for agent_id, profile in agent_profiles.items():
        history = histories.get(agent_id, [])

        # update reputation
        for h in history:
            profile = rep_engine.update(profile, h.get("outcome"))

        # detect adversary
        if detector.detect(history):
            profile = slasher.apply(profile)

        updated_profiles[agent_id] = profile

    filtered = filter_engine.filter(updated_profiles)

    return {
        "updated_profiles": updated_profiles,
        "active_agents": filtered
    }
