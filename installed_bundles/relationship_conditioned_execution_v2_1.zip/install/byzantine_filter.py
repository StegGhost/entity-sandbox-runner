class ByzantineFilter:
    def filter(self, agents):
        return {
            k: v for k, v in agents.items()
            if not v.get("slashed", False)
        }
