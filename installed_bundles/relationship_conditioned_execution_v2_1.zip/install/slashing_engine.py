class SlashingEngine:
    def apply(self, profile, severity=0.2):
        profile["reputation"] = max(0.0, profile.get("reputation", 0.5) - severity)
        profile["slashed"] = True
        return profile
