from engine.repo_snapshot import build_snapshot
from engine.llm_self_improve import generate_proposal
from engine.proposal_to_bundle import proposal_to_bundle
from pathlib import Path

def test_self_improve_loop():
    snapshot = build_snapshot()
    proposal = generate_proposal(snapshot)

    assert "files_to_create" in proposal

    bundle_path = proposal_to_bundle(proposal)

    assert Path(bundle_path).exists()
