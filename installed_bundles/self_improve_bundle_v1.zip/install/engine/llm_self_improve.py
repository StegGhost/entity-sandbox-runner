def generate_proposal(snapshot: dict):
    gaps = []

    if snapshot["test_count"] < 3:
        gaps.append("low_test_coverage")

    proposal = {
        "proposal_name": "auto_add_test",
        "files_to_create": [
            {
                "path": "install/tests/test_auto_generated.py",
                "content": "\ndef test_auto_generated():\n    assert True\n"
            }
        ],
        "files_to_modify": [],
        "tests_to_add": ["test_auto_generated"],
        "justification": f"Gaps detected: {gaps}",
        "expected_impact": {
            "test_count_increase": 1
        }
    }

    return proposal
