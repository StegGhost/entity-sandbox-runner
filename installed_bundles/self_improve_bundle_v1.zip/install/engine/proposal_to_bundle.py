import json
import zipfile
from pathlib import Path

def proposal_to_bundle(proposal, output_path="incoming_bundles/auto_bundle.zip"):
    temp_dir = Path("tmp_bundle")
    install_dir = temp_dir / "install"

    install_dir.mkdir(parents=True, exist_ok=True)

    for f in proposal.get("files_to_create", []):
        path = install_dir / Path(f["path"]).relative_to("install")
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(f["content"])

    manifest = {
        "bundle_name": "auto_generated_bundle",
        "bundle_version": "1.0.0",
        "version": "1.0.0",
        "install_mode": "folder_map",
        "allowed_paths": [
            "install/tests/",
            "install/engine/"
        ]
    }

    (temp_dir / "bundle_manifest.json").write_text(json.dumps(manifest, indent=2))

    Path("incoming_bundles").mkdir(exist_ok=True)

    with zipfile.ZipFile(output_path, "w") as z:
        for p in temp_dir.rglob("*"):
            z.write(p, p.relative_to(temp_dir))

    return output_path
