from pathlib import Path

def build_snapshot(root="."):
    root = Path(root)

    files = []
    tests = []

    for p in root.rglob("*"):
        if p.is_file():
            rel = str(p.relative_to(root))
            files.append(rel)

            if "test" in rel:
                tests.append(rel)

    return {
        "file_count": len(files),
        "test_count": len(tests),
        "files": files[:50],
        "tests": tests[:50],
    }
