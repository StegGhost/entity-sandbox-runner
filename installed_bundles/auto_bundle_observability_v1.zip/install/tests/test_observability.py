
def test_logging():
    from install.observability.observer import log_event
    import tempfile, os

    with tempfile.TemporaryDirectory() as tmp:
        log_event(tmp, "test", {"a": 1})
        path = os.path.join(tmp, "install/observability/evolution_log.jsonl")
        assert os.path.exists(path)
