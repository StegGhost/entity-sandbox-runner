
import json
import os
from datetime import datetime

LOG_PATH = "install/observability/evolution_log.jsonl"

def log_event(bundle_root, event_type, payload):
    path = os.path.join(bundle_root, LOG_PATH)
    os.makedirs(os.path.dirname(path), exist_ok=True)

    entry = {
        "timestamp": datetime.utcnow().isoformat(),
        "event_type": event_type,
        "payload": payload
    }

    with open(path, "a") as f:
        f.write(json.dumps(entry) + "\n")

def log_generation(bundle_root, bundle_name):
    log_event(bundle_root, "generation", {
        "bundle_name": bundle_name
    })

def log_violation(bundle_root, reason):
    log_event(bundle_root, "violation", {
        "reason": reason
    })

def log_repair(bundle_root, strategy, target):
    log_event(bundle_root, "repair", {
        "strategy": strategy,
        "target": target
    })

def log_invariant_failure(bundle_root, reason):
    log_event(bundle_root, "invariant_failure", {
        "reason": reason
    })

def log_success(bundle_root):
    log_event(bundle_root, "success", {})
