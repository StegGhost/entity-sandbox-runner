
# Drop-in wrapper for proposal_to_bundle integration

from install.observability.observer import (
    log_generation,
    log_violation,
    log_repair,
    log_invariant_failure,
    log_success
)

def wrap_build(build_fn):
    def wrapped(bundle_root, bundle_name):
        log_generation(bundle_root, bundle_name)
        try:
            result = build_fn(bundle_root, bundle_name)
            log_success(bundle_root)
            return result
        except Exception as e:
            msg = str(e)

            if "capability_violation" in msg:
                log_violation(bundle_root, msg)
            elif "INVARIANT_VIOLATION" in msg:
                log_invariant_failure(bundle_root, msg)
            else:
                log_violation(bundle_root, msg)

            raise

    return wrapped
