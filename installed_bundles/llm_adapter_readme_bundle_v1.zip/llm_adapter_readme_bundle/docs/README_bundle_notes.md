# Bundle Notes

This bundle is intended for ingestion into an existing governed execution repository.

## Purpose

- refresh stale or missing README documentation
- add an LLM-agnostic proposal adapter layer
- preserve the governed execution boundary
- enable future multi-LLM integration without binding to any single vendor

## Install Targets

Copy files from `install/` into the repository root, preserving the `.github/workflows/` path.

## Compatibility

This bundle is additive. It does not require replacing the current governed executor, decision engine, or API server.
