
def test_prevention_rules():
    from install.engine.proposal_to_bundle import update_rules

    memory = {"patterns": {"capability_violation:bad.py": {"count": 2}}, "rules": {}}
    update_rules(memory)

    assert "bad.py" in memory["rules"]
