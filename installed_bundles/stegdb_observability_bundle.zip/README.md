# StegDB

[![Sync DiamondOps-Core canonicals](https://github.com/stegverse-labs/stegdb/actions/workflows/sync-diamondops-core-canonicals.yml/badge.svg)](https://github.com/stegverse-labs/stegdb/actions/workflows/sync-diamondops-core-canonicals.yml)

StegDB is StegVerse-Labs’ **canonical database + protocol hub** for keeping many repos consistent, auditable, and “self-healing.”

It provides:

- **Canonical templates** (workflows + baseline repo structure)
- **Protocols** (custody, notifications, evidence confidence, etc.)
- **Schemas** and validation targets
- **Registry + metadata** (what repos exist, what they contain, dependency status)
- **Automation pipelines** to ingest, evaluate, and synchronize system state

> Think of StegDB as the place where StegVerse defines **“what correct looks like”** and then continuously pushes that correctness outward.

---

# Repository Structure

## `.github/workflows/`

Operational automation for ingest, evaluation, and canonical synchronization.

Examples:

- `bootstrap-stegdb-dirs.yml`
- `stegdb-central.yml`
- `stegdb-ingest-only.yml`
- `sync-to-canonical.yml`
- `dispatch-sync-to-canonical.yml`
- `publish-canonical.yml`
- `full-cycle.yml`
- `workflow-lint.yml`

These workflows typically follow a pattern:

```text
clone repos
   ↓
ingest metadata
   ↓
evaluate dependencies
   ↓
build global state
   ↓
publish or sync canonicals
```

---

# `canonical/`

Canonical exports organized by project.

Example:

```text
canonical/
  cosden/
     workflows/
     src/
     Dockerfile
```

These represent **the authoritative structures** that participating repos may sync against.

---

# `profiles/base/.github/workflows/`

Reusable baseline workflows intended to be copied into repos.

Examples:

```text
profiles/base/.github/workflows/
   sync-to-canonical.yml
   workflow-lint.yml
```

---

# `protocols/`

Shared protocols that other repos can adopt or reference.

Examples:

```text
protocols/
  custody/
    custody-transition-spec.md
    custody-transition.schema.yml

  hee/
    artifact.schema.yml
    evidence-confidence-policy.md

  notifications/
    custody-notifications.md

  stegtv/
    db/
      0001_stegtv_ledger.sql
```

Protocols define **system-wide rules or interfaces** that many repos may implement.

---

# `schemas/`

Machine-readable schema definitions used to validate StegVerse artifacts.

Examples:

```text
schemas/
  dependency_status.schemas.json
  review_schema_v1.yml
  review_result_v1.yml
  stegtv_execution_event.schema.json
```

These schemas allow tools to verify that structured data produced by repos conforms to expected formats.

---

# `registry/`

Defines the repos StegDB knows about and how they should be handled.

Example:

```text
registry/
  repos.json
```

Typical fields include:

- repo name
- canonical export location
- production validation flags
- last validation timestamps

---

# `repos/<RepoName>/`

Per-repository inventories generated during ingestion.

Example:

```text
repos/
  CosDen/
     files.jsonl
```

These are produced by repo-level validators and later aggregated by StegDB.

---

# `repairs/<RepoName>/`

Repair plans generated when a repo diverges from canonical expectations.

Example:

```text
repairs/
  CosDen/
     repair_plan.json
```

---

# `meta/`

The **system memory layer** of StegVerse.

Automation pipelines continuously ingest data from repos and write structured observations here.

Two major categories exist:

## Aggregate system observations

```text
meta/
  aggregated_files.jsonl
  dependency_status.json
```

These summarize **system-wide information across many repos**.

## Domain-specific ingest outputs

```text
meta/
  stegtv/
     events.jsonl
     latest_ingest_summary.json

  guardian/
     per_repo/
        StegVerse-SCW/
            workflow_runnability_latest.json
            LATEST.md
```

Each domain ingestion tool writes to a **dedicated namespace inside `meta/`**.

Examples:

| Domain | Description |
|------|-------------|
| `repos` | repo metadata and file inventories |
| `stegtv` | execution-authorization events from StegTV |
| `guardian` | runtime system audits (e.g., workflow runnability) |

This structure allows StegDB to answer questions like:

- What repos exist?
- What files do they contain?
- What dependencies exist between them?
- What actions have actually executed?

## Observability index

StegDB can build a compact machine-readable system map:

```text
meta/observability/system_map.json
```

This file summarizes:

- aggregated repo metadata
- dependency status
- StegTV execution events
- SCW runnability snapshots

It is intended to become the foundation for StegVerse-wide observability and debugging.

---

# `tools/`

Automation utilities used by workflows and operators.

Examples currently present:

```text
tools/
  register_repo.py
  ingest_repo_metadata.py
  generate_repo_metadata.py
  evaluate_dependencies.py
  repair_repos.py
  dispatch_repo_event.py
  bootstrap_canonical_prs.py
  run_full_cycle.py
  clone_org_repos.py
  ingest_scw_runnability.py
  ingest_stegtv_events.py
  build_observability_index.py
```

These tools power StegDB's ingestion and evaluation pipelines.

Typical ingestion pipeline:

```text
repos → meta/files.jsonl
        ↓
ingest_repo_metadata.py
        ↓
meta/aggregated_files.jsonl
        ↓
evaluate_dependencies.py
        ↓
build_global_state.py
```

---

# StegTV Event Ingestion

StegDB can ingest **execution authorization events** produced by StegTV.

The ingestion tool:

```text
tools/ingest_stegtv_events.py
```

Validates events using:

```text
schemas/stegtv_execution_event.schema.json
```

Events are written to:

```text
meta/stegtv/events.jsonl
```

with a summary:

```text
meta/stegtv/latest_ingest_summary.json
```

These records represent **what actions actually occurred in the system**, providing an auditable execution history.

---

# Typical Workflows

## Push canonical changes outward

1. Update canonical sources in StegDB
2. Run **Publish Canonical**
3. Run **Sync to Canonical**

---

## Register a new repo

1. Add entry to

```text
registry/repos.json
```

2. Run ingestion tooling or `full-cycle.yml`

---

## Run a system health sweep

Run:

```text
full-cycle.yml
```

This performs:

```text
ingest → evaluate → build state → publish canonicals
```

---

# How this connects to other StegVerse repos

StegDB contains **shared infrastructure artifacts**.

Examples:

| Repo | Purpose |
|----|----|
| HouseHold | incident-specific evidence |
| CosDen | canonical code templates |
| StegTV | execution authorization system |
| SCW | workflow runnability and system audits |

StegDB defines the **shared contracts and system state** that these repos interact with.

---

# Design Philosophy

StegDB is intentionally:

**Mechanical**

Outputs are deterministic and generated by tools.

**Auditable**

System state is written to `meta/` and can be diffed across commits.

**Scalable**

The architecture supports dozens of repos and automation pipelines.

**Protocol-driven**

Standards live here so individual repos can remain lightweight.

---

# License / Safety Notes

This repository should store:

- protocols
- schemas
- automation logic
- canonical templates

Avoid committing:

- credentials
- private identifiers
- personal documents
- sensitive evidence

unless a dedicated **private repository** is used.
