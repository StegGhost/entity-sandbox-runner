#!/usr/bin/env python3
"""
Build a compact StegDB observability index from meta outputs.

Outputs:
- meta/observability/system_map.json

This file is intended to give StegVerse one machine-readable system view across:
- repo metadata aggregation
- dependency status
- StegTV execution events
- SCW runnability snapshots
"""

from __future__ import annotations

import json
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List

STEGBDB_ROOT = Path(__file__).resolve().parents[1]
META_ROOT = STEGBDB_ROOT / "meta"

AGGREGATED_FILES = META_ROOT / "aggregated_files.jsonl"
DEPENDENCY_STATUS = META_ROOT / "dependency_status.json"

STEGTV_EVENTS = META_ROOT / "stegtv" / "events.jsonl"
STEGTV_SUMMARY = META_ROOT / "stegtv" / "latest_ingest_summary.json"

SCW_RUNNABILITY = META_ROOT / "guardian" / "per_repo" / "StegVerse-SCW" / "workflow_runnability_latest.json"

OBS_DIR = META_ROOT / "observability"
OBS_FILE = OBS_DIR / "system_map.json"


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def load_json(path: Path):
    if not path.exists():
        return None
    return json.loads(path.read_text(encoding="utf-8"))


def load_jsonl(path: Path) -> List[Dict[str, Any]]:
    if not path.exists():
        return []
    rows: List[Dict[str, Any]] = []
    with path.open("r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            obj = json.loads(line)
            if isinstance(obj, dict):
                rows.append(obj)
    return rows


def summarize_repos(records: List[Dict[str, Any]]) -> Dict[str, Any]:
    per_repo: Dict[str, Dict[str, Any]] = {}
    for rec in records:
        repo = str(rec.get("repo") or "unknown")
        item = per_repo.setdefault(
            repo,
            {
                "repo": repo,
                "file_count": 0,
                "sample_paths": [],
            },
        )
        item["file_count"] += 1
        path = rec.get("path") or rec.get("file") or rec.get("relative_path")
        if path and len(item["sample_paths"]) < 5:
            item["sample_paths"].append(path)

    return {
        "repo_count": len(per_repo),
        "repos": sorted(per_repo.values(), key=lambda x: x["repo"].lower()),
    }


def summarize_stegtv(events: List[Dict[str, Any]]) -> Dict[str, Any]:
    if not events:
        return {
            "event_count": 0,
            "per_repo": [],
            "event_types": {},
            "decisions": {},
            "latest_event_time": None,
        }

    per_repo_counter: Counter[str] = Counter()
    type_counter: Counter[str] = Counter()
    decision_counter: Counter[str] = Counter()
    latest_event_time = None

    for ev in events:
        repo = str(ev.get("repo") or "unknown")
        per_repo_counter[repo] += 1
        type_counter[str(ev.get("event_type") or "unknown")] += 1
        decision_counter[str(ev.get("decision") or "unknown")] += 1

        t = ev.get("time")
        if isinstance(t, str):
            if latest_event_time is None or t > latest_event_time:
                latest_event_time = t

    per_repo = [
        {"repo": repo, "event_count": count}
        for repo, count in sorted(per_repo_counter.items(), key=lambda kv: kv[0].lower())
    ]

    return {
        "event_count": len(events),
        "per_repo": per_repo,
        "event_types": dict(type_counter),
        "decisions": dict(decision_counter),
        "latest_event_time": latest_event_time,
    }


def summarize_scw(data) -> Dict[str, Any]:
    if not isinstance(data, dict):
        return {
            "present": False,
            "repo": "StegVerse-SCW",
        }

    summary: Dict[str, Any] = {
        "present": True,
        "repo": "StegVerse-SCW",
    }

    for key in ("generated_at_utc", "canonized_at_utc", "state", "reason"):
        if key in data:
            summary[key] = data[key]

    if "workflows" in data and isinstance(data["workflows"], list):
        summary["workflow_count"] = len(data["workflows"])

    return summary


def main() -> None:
    OBS_DIR.mkdir(parents=True, exist_ok=True)

    aggregated_records = load_jsonl(AGGREGATED_FILES)
    dependency_status = load_json(DEPENDENCY_STATUS)
    stegtv_events = load_jsonl(STEGTV_EVENTS)
    stegtv_summary = load_json(STEGTV_SUMMARY)
    scw_runnability = load_json(SCW_RUNNABILITY)

    payload = {
        "generated_at_utc": utc_now(),
        "sources": {
            "aggregated_files": str(AGGREGATED_FILES.relative_to(STEGBDB_ROOT)),
            "dependency_status": str(DEPENDENCY_STATUS.relative_to(STEGBDB_ROOT)),
            "stegtv_events": str(STEGTV_EVENTS.relative_to(STEGBDB_ROOT)),
            "stegtv_summary": str(STEGTV_SUMMARY.relative_to(STEGBDB_ROOT)),
            "scw_runnability": str(SCW_RUNNABILITY.relative_to(STEGBDB_ROOT)),
        },
        "repos": summarize_repos(aggregated_records),
        "dependency_status": dependency_status or {},
        "stegtv": {
            "summary": stegtv_summary or {},
            "derived": summarize_stegtv(stegtv_events),
        },
        "scw": summarize_scw(scw_runnability if isinstance(scw_runnability, dict) else None),
    }

    OBS_FILE.write_text(json.dumps(payload, indent=2, sort_keys=True), encoding="utf-8")
    print(f"✅ Wrote observability index to {OBS_FILE.relative_to(STEGBDB_ROOT)}")


if __name__ == "__main__":
    main()
