import math
def compute_U(c,co,p,con):
    return (c*co)/max(p*con,1e-9)
def margin(U):
    return math.log(U)
