def repair_manifest(m):
    req = ["bundle_name","version","install_mode","description","allowed_paths"]
    for r in req:
        if r not in m:
            m[r] = "auto"
    return m
def retry(bundle):
    return {"status":"requeued"}
