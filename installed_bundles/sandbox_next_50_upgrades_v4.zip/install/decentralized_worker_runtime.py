import time, uuid
class Worker:
    def __init__(self, worker_id=None):
        self.worker_id = worker_id or str(uuid.uuid4())
        self.last_heartbeat = time.time()
    def heartbeat(self):
        self.last_heartbeat = time.time()
        return {"worker_id": self.worker_id, "status": "alive"}
    def claim_shard(self, shard_id):
        return {"worker_id": self.worker_id, "claimed": shard_id}
    def execute(self, payload):
        return {"worker_id": self.worker_id, "result": "ok"}
