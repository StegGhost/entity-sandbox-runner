def vote(results):
    counts={}
    for r in results:
        counts[r]=counts.get(r,0)+1
    return max(counts,key=counts.get)
