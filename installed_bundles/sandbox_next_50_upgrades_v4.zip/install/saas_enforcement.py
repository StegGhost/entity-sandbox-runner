def enforce_tier(user):
    if user.get("tier")=="free": return {"rate":10}
    if user.get("tier")=="pro": return {"rate":100}
    return {"rate":1}
