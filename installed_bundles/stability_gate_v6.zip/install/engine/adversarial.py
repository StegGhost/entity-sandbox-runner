def inject_volatility(E, factor):
    return E * factor
