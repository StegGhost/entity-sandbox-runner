def coupled_stability(states):
    return min(states)
