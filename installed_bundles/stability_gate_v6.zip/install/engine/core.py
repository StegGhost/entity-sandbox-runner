from dataclasses import dataclass
import hashlib, json

@dataclass
class SystemState:
    D: float
    M: float
    E: float
    A: float

def stability(state):
    if state.E * state.A == 0:
        return float("inf")
    return (state.D * state.M) / (state.E * state.A)

def receipt(state, prev=""):
    payload = {"D":state.D,"M":state.M,"E":state.E,"A":state.A,"prev":prev}
    raw = json.dumps(payload, sort_keys=True)
    h = hashlib.sha256(raw.encode()).hexdigest()
    return {"payload":payload,"hash":h}
