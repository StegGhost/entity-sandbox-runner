from engine.core import SystemState, stability

def test_basic():
    s = SystemState(1,1,1,1)
    assert stability(s) == 1
