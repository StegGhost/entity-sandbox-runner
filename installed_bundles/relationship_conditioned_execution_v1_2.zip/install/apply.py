from global_state_registry import GlobalStateRegistry
from stability_scorer import StabilityScorer
from cascade_prevention import CascadePrevention
from coherence_engine import CoherenceEngine

registry = GlobalStateRegistry()
scorer = StabilityScorer()
cascade = CascadePrevention()
coherence = CoherenceEngine()

def apply(node_id, action, state):
    registry.update(node_id, state)
    global_state = registry.snapshot()
    stability = scorer.score(global_state)
    ok, reason = cascade.check(action, global_state)
    if not ok:
        return {"decision": "BLOCK", "reason": reason, "stability": stability}
    return {"decision": "ALLOW", "stability": stability, "coherence": coherence.evaluate(global_state)}
