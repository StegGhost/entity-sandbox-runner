class StabilityScorer:
    def score(self, global_state):
        if not global_state:
            return 1.0
        instability = sum(1 for s in global_state.values() if s.get("risk") == "HIGH")
        total = len(global_state)
        return max(0.0, 1 - (instability / total))
