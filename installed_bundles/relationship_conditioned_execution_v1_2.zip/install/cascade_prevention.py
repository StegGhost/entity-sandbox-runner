class CascadePrevention:
    def check(self, action, global_state):
        high_risk = [s for s in global_state.values() if s.get("risk") == "HIGH"]
        if len(high_risk) > 3:
            return False, "cascade_risk"
        return True, "ok"
