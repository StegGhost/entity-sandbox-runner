class GlobalStateRegistry:
    def __init__(self):
        self.nodes = {}
    def update(self, node_id, state):
        self.nodes[node_id] = state
    def snapshot(self):
        return self.nodes
