
import json
import os

ALLOWED_PATHS = [
    "bundle_manifest.json",
    "install/tests/",
    "install/engine/",
    "install/apply.py"
]

def build_manifest(bundle_name, bundle_version="1.0.0"):
    return {
        "bundle_name": bundle_name,
        "bundle_version": bundle_version,
        "install_mode": "folder_map",
        "allowed_paths": ALLOWED_PATHS
    }

def simulate_ingestion(bundle_root):
    # verify manifest exists
    manifest_path = os.path.join(bundle_root, "bundle_manifest.json")
    if not os.path.exists(manifest_path):
        return False, "missing_manifest"

    with open(manifest_path) as f:
        manifest = json.load(f)

    allowed = manifest.get("allowed_paths", [])

    # walk files and check compliance
    for root, _, files in os.walk(bundle_root):
        for file in files:
            rel_path = os.path.relpath(os.path.join(root, file), bundle_root)

            if rel_path == "bundle_manifest.json":
                continue

            valid = False
            for path in allowed:
                if path.endswith("/") and rel_path.startswith(path):
                    valid = True
                elif rel_path == path:
                    valid = True

            if not valid:
                return False, f"capability_violation:{rel_path}"

    return True, "ok"

def ensure_structure(bundle_root):
    os.makedirs(os.path.join(bundle_root, "install/tests"), exist_ok=True)
    os.makedirs(os.path.join(bundle_root, "install/engine"), exist_ok=True)

    apply_path = os.path.join(bundle_root, "install/apply.py")
    if not os.path.exists(apply_path):
        with open(apply_path, "w") as f:
            f.write("def apply():\n    print(\"Bundle applied successfully.\")\n")

def build_bundle(bundle_root, bundle_name):
    ensure_structure(bundle_root)

    manifest = build_manifest(bundle_name)
    with open(os.path.join(bundle_root, "bundle_manifest.json"), "w") as f:
        json.dump(manifest, f, indent=2)

    ok, reason = simulate_ingestion(bundle_root)

    if not ok:
        raise Exception(f"PRECHECK_FAILED:{reason}")

    return True
