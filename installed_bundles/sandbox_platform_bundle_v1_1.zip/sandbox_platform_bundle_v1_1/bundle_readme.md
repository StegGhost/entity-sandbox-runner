Sandbox Platform Bundle v1.1

This is a sandbox-native installer bundle.

It installs staged platform content into:
- install/
- payload/

Then you can promote the payload into:
- control_plane/
- security_plane/
- evidence_plane/
- observatory/

Important:
- This version is corrected for the current ingestion engine.
- Required fields install_mode and allowed_paths are inside bundle_manifest.json.
