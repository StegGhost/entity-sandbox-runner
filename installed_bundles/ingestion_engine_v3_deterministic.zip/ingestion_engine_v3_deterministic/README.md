# Ingestion Engine v3 (Deterministic)

Fixes core ingestion issues:

- Writes ingestion_reports per bundle
- Enforces allowed_paths correctly
- Eliminates silent failures
- Produces deterministic outcomes
- Makes ingestion observable

This replaces unstable ingestion behavior where:
- bundles fail silently
- reports are missing
- execution appears "ok" but does nothing
