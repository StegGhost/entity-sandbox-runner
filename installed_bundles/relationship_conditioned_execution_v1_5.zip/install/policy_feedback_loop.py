class PolicyFeedbackLoop:
    def apply(self, action, metrics):
        if metrics["failure_rate"] > 0.6:
            action["requires_reflection"] = True
            action["throttle"] = "STRICT"
        return action
