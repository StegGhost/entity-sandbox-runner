from learning_engine import LearningEngine
from threshold_adapter import ThresholdAdapter
from policy_feedback_loop import PolicyFeedbackLoop

learning = LearningEngine()
adapter = ThresholdAdapter()
feedback = PolicyFeedbackLoop()

state = {
    "risk_threshold": 0.5
}

def apply(history, action):
    metrics = learning.update(history)
    updated_state = adapter.adjust(metrics, state)
    action = feedback.apply(action, metrics)

    return {
        "metrics": metrics,
        "updated_state": updated_state,
        "action": action
    }
