class LearningEngine:
    def update(self, history):
        outcomes = [h.get("outcome") for h in history if "outcome" in h]
        success = outcomes.count("success")
        failure = outcomes.count("failure")
        total = len(outcomes) if outcomes else 1
        return {
            "success_rate": success / total,
            "failure_rate": failure / total
        }
