class ThresholdAdapter:
    def adjust(self, metrics, current):
        if metrics["failure_rate"] > 0.5:
            current["risk_threshold"] *= 0.9
        else:
            current["risk_threshold"] *= 1.05
        return current
