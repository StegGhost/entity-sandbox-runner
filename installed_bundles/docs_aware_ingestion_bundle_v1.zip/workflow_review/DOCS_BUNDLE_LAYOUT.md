# Docs Bundle Layout v1

Future documentation bundles should use this structure:

bundle_manifest.json
payload/
  repo_root/
    README.md
    architecture_map.md
    docs/
      overview.md
    .github/
      workflows/
        docs_publish.yml

Why:
- The ingestion engine only installs governed paths.
- payload/repo_root/ is a controlled mapping to repo root.
- This allows docs bundles to update README.md and docs safely.
- It also supports workflow-file installation through the same mapping.

Example mapping:
- payload/repo_root/README.md -> README.md
- payload/repo_root/docs/overview.md -> docs/overview.md
- payload/repo_root/.github/workflows/docs_publish.yml -> .github/workflows/docs_publish.yml
