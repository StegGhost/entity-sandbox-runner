from .state_model import SystemState

def compute_stability_score(state: SystemState) -> float:
    denominator = state.env_volatility * state.action_magnitude
    if denominator == 0:
        return float("inf")
    return (state.deliberation_time * state.model_fidelity) / denominator

def compute_adaptive_threshold(state: SystemState) -> float:
    volatility_factor = max(0.0, state.env_volatility - 1.0) * 0.25
    action_factor = max(0.0, state.action_magnitude - 1.0) * 0.20
    pressure_factor = max(0.0, state.pressure_bias)
    return state.baseline_threshold + volatility_factor + action_factor + pressure_factor
