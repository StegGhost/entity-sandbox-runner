from .state_model import SystemState
from .enforcement import enforce_action

def main():
    state = SystemState(
        deliberation_time=1.2,
        model_fidelity=0.95,
        env_volatility=0.8,
        action_magnitude=1.0,
        baseline_threshold=1.0,
        pressure_bias=0.0,
        metadata={"source": "workflow_dispatch"}
    )
    result = enforce_action(state)
    print(result)
    if result["status"] == "blocked":
        raise SystemExit("Action rejected: unstable system")

if __name__ == "__main__":
    main()
