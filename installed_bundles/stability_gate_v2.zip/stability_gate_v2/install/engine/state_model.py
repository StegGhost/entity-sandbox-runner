from dataclasses import dataclass, field
from typing import Dict, Any

@dataclass
class SystemState:
    deliberation_time: float
    model_fidelity: float
    env_volatility: float
    action_magnitude: float
    baseline_threshold: float = 1.0
    pressure_bias: float = 0.0
    metadata: Dict[str, Any] = field(default_factory=dict)
