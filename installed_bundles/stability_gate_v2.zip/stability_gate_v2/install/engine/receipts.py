import hashlib
import json
from typing import Any, Dict

def canonicalize_receipt_payload(payload: Dict[str, Any]) -> str:
    return json.dumps(payload, sort_keys=True, separators=(",", ":"), ensure_ascii=False)

def compute_receipt_hash(payload: Dict[str, Any]) -> str:
    canonical = canonicalize_receipt_payload(payload).encode("utf-8")
    return hashlib.sha256(canonical).hexdigest()
