from .stability_guard import compute_stability_score, compute_adaptive_threshold
from .receipts import compute_receipt_hash

def enforce_action(state):
    score = compute_stability_score(state)
    threshold = compute_adaptive_threshold(state)

    if score >= threshold:
        status = "allowed"
        action = "execute"
    elif score >= threshold * 0.8:
        status = "delay"
        action = "increase_deliberation"
    else:
        status = "blocked"
        action = "escalate_or_abort"

    payload = {
        "status": status,
        "recommended_action": action,
        "stability_score": round(score, 6),
        "threshold": round(threshold, 6),
        "state": {
            "deliberation_time": state.deliberation_time,
            "model_fidelity": state.model_fidelity,
            "env_volatility": state.env_volatility,
            "action_magnitude": state.action_magnitude,
            "baseline_threshold": state.baseline_threshold,
            "pressure_bias": state.pressure_bias,
            "metadata": state.metadata,
        },
    }

    payload["receipt_hash"] = compute_receipt_hash(payload)
    return payload
