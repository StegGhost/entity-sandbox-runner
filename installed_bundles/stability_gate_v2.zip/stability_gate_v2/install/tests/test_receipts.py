from engine.receipts import compute_receipt_hash

def test_receipt_hash_is_deterministic():
    payload = {"a": 1, "b": 2}
    h1 = compute_receipt_hash(payload)
    h2 = compute_receipt_hash(payload)
    assert h1 == h2
