from engine.state_model import SystemState
from engine.stability_guard import compute_stability_score

def test_stability_score_basic():
    state = SystemState(1.0, 1.0, 1.0, 1.0)
    score = compute_stability_score(state)
    assert score == 1.0
