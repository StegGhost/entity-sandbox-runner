from engine.state_model import SystemState
from engine.stability_guard import compute_adaptive_threshold

def test_threshold_increases_under_pressure():
    base = SystemState(1.0, 1.0, 1.0, 1.0)
    stressed = SystemState(1.0, 1.0, 2.0, 2.0, pressure_bias=0.2)

    assert compute_adaptive_threshold(stressed) > compute_adaptive_threshold(base)
