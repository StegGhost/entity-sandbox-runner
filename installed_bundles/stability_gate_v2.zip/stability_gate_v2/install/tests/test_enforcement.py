from engine.state_model import SystemState
from engine.enforcement import enforce_action

def test_allowed():
    state = SystemState(2.0, 1.0, 1.0, 1.0)
    result = enforce_action(state)
    assert result["status"] == "allowed"
    assert "receipt_hash" in result

def test_blocked():
    state = SystemState(0.1, 0.5, 3.0, 2.0)
    result = enforce_action(state)
    assert result["status"] == "blocked"
