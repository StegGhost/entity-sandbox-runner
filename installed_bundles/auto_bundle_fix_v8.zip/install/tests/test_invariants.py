
def test_invariant_block():
    from install.engine.proposal_to_bundle import validate_invariants

    import tempfile, os

    with tempfile.TemporaryDirectory() as tmp:
        os.makedirs(os.path.join(tmp, "install/engine"), exist_ok=True)
        os.makedirs(os.path.join(tmp, "install/tests"), exist_ok=True)

        inv = {
            "required_paths": ["install/apply.py"],
            "forbidden_paths": []
        }

        ok, _ = validate_invariants(tmp, inv)
        assert not ok
