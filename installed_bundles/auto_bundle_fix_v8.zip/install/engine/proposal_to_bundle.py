
import json
import os
import shutil
import copy

BASE_ALLOWED_PATHS = [
    "bundle_manifest.json",
    "install/tests/",
    "install/engine/",
    "install/apply.py",
    "install/config/"
]

MAX_RETRIES = 3
MEMORY_PATH = "install/config/repair_memory.json"
INVARIANT_PATH = "install/config/invariants.json"

# ------------------ Memory ------------------

def load_memory(bundle_root):
    path = os.path.join(bundle_root, MEMORY_PATH)
    if os.path.exists(path):
        with open(path) as f:
            return json.load(f)
    return {"patterns": {}, "generator_rules": {}}

def save_memory(bundle_root, memory):
    path = os.path.join(bundle_root, MEMORY_PATH)
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w") as f:
        json.dump(memory, f, indent=2)

# ------------------ Invariants ------------------

def load_invariants(bundle_root):
    path = os.path.join(bundle_root, INVARIANT_PATH)
    if os.path.exists(path):
        with open(path) as f:
            return json.load(f)
    # default invariants
    return {
        "required_paths": [
            "install/apply.py",
            "install/engine/",
            "install/tests/"
        ],
        "forbidden_paths": [
            "secrets/",
            ".env"
        ]
    }

def validate_invariants(bundle_root, invariants):
    # check required
    for req in invariants.get("required_paths", []):
        full = os.path.join(bundle_root, req)
        if req.endswith("/") and not os.path.isdir(full):
            return False, f"invariant_missing_dir:{req}"
        if not req.endswith("/") and not os.path.exists(full):
            return False, f"invariant_missing_file:{req}"

    # check forbidden
    for root, _, files in os.walk(bundle_root):
        for f in files:
            rel = os.path.relpath(os.path.join(root, f), bundle_root)
            for forbidden in invariants.get("forbidden_paths", []):
                if rel.startswith(forbidden):
                    return False, f"invariant_forbidden:{rel}"

    return True, "ok"

# ------------------ Generator Rules ------------------

def record_failure(memory, reason):
    memory["patterns"].setdefault(reason, {"count": 0})
    memory["patterns"][reason]["count"] += 1

def update_generator_rules(memory):
    for reason, data in memory.get("patterns", {}).items():
        if data["count"] >= 2 and reason.startswith("capability_violation:"):
            bad_path = reason.split(":", 1)[1]
            filename = os.path.basename(bad_path)
            memory["generator_rules"][filename] = "install/engine/"

def apply_generator_rules(bundle_root, memory):
    rules = memory.get("generator_rules", {})
    for root, _, files in os.walk(bundle_root):
        for file in files:
            if file in rules:
                src = os.path.join(root, file)
                target_dir = os.path.join(bundle_root, rules[file])
                os.makedirs(target_dir, exist_ok=True)
                dst = os.path.join(target_dir, file)
                if os.path.abspath(src) != os.path.abspath(dst):
                    shutil.move(src, dst)

# ------------------ Manifest ------------------

def build_allowed_paths(memory):
    allowed = list(BASE_ALLOWED_PATHS)
    for target in memory.get("generator_rules", {}).values():
        if target not in allowed:
            allowed.append(target)
    return allowed

def build_manifest(bundle_name, memory):
    return {
        "bundle_name": bundle_name,
        "bundle_version": "1.0.0",
        "install_mode": "folder_map",
        "allowed_paths": build_allowed_paths(memory)
    }

# ------------------ Ingestion Simulation ------------------

def simulate_ingestion(bundle_root):
    manifest_path = os.path.join(bundle_root, "bundle_manifest.json")
    if not os.path.exists(manifest_path):
        return False, "missing_manifest"

    with open(manifest_path) as f:
        manifest = json.load(f)

    allowed = manifest.get("allowed_paths", [])

    for root, _, files in os.walk(bundle_root):
        for file in files:
            rel_path = os.path.relpath(os.path.join(root, file), bundle_root)

            if rel_path == "bundle_manifest.json":
                continue

            valid = False
            for path in allowed:
                if path.endswith("/") and rel_path.startswith(path):
                    valid = True
                elif rel_path == path:
                    valid = True

            if not valid:
                return False, f"capability_violation:{rel_path}"

    return True, "ok"

# ------------------ Structure ------------------

def ensure_structure(bundle_root):
    os.makedirs(os.path.join(bundle_root, "install/tests"), exist_ok=True)
    os.makedirs(os.path.join(bundle_root, "install/engine"), exist_ok=True)
    os.makedirs(os.path.join(bundle_root, "install/config"), exist_ok=True)

    apply_path = os.path.join(bundle_root, "install/apply.py")
    if not os.path.exists(apply_path):
        with open(apply_path, "w") as f:
            f.write("def apply():\n    print('Bundle applied successfully.')\n")

# ------------------ Repair ------------------

def auto_repair(bundle_root, reason, memory):
    record_failure(memory, reason)

    if reason.startswith("capability_violation:"):
        bad_path = reason.split(":", 1)[1]
        full_path = os.path.join(bundle_root, bad_path)
        quarantine_dir = os.path.join(bundle_root, "quarantine")
        os.makedirs(quarantine_dir, exist_ok=True)
        if os.path.exists(full_path):
            shutil.move(full_path, os.path.join(quarantine_dir, os.path.basename(bad_path)))
        return True

    if reason.startswith("invariant_"):
        return False  # do not auto-fix invariant violations

    if reason == "missing_manifest":
        return True

    return False

# ------------------ Build ------------------

def build_bundle(bundle_root, bundle_name):
    ensure_structure(bundle_root)

    memory = load_memory(bundle_root)
    invariants = load_invariants(bundle_root)

    snapshot = copy.deepcopy(memory)

    apply_generator_rules(bundle_root, memory)

    manifest = build_manifest(bundle_name, memory)
    with open(os.path.join(bundle_root, "bundle_manifest.json"), "w") as f:
        json.dump(manifest, f, indent=2)

    for _ in range(MAX_RETRIES):
        ok, reason = simulate_ingestion(bundle_root)
        if ok:
            inv_ok, inv_reason = validate_invariants(bundle_root, invariants)
            if not inv_ok:
                memory = snapshot  # rollback
                save_memory(bundle_root, memory)
                raise Exception(f"INVARIANT_VIOLATION:{inv_reason}")

            update_generator_rules(memory)
            save_memory(bundle_root, memory)
            return True

        repaired = auto_repair(bundle_root, reason, memory)
        if not repaired:
            memory = snapshot
            save_memory(bundle_root, memory)
            raise Exception(f"UNRECOVERABLE:{reason}")

    memory = snapshot
    save_memory(bundle_root, memory)
    raise Exception(f"MAX_RETRIES_EXCEEDED:{reason}")
