
# Generator V3 Bundle

## New Capabilities

### Dynamic Tightening
- Only includes paths that exist in bundle

### Policy Constraints
- allow_docs
- allow_config
- minimize_scopes

### Governance Upgrade
- Manifest now includes policy block
- Enables future enforcement at ingestion layer

## Result
- Safer manifests
- Reduced attack surface
- Still guaranteed ingestion pass
