
from install.engine.proposal_to_bundle import build_manifest

def test_dynamic_scope():
    manifest = build_manifest("sample_bundle")
    assert "bundle_manifest.json" in manifest["allowed_paths"]

def test_policy_present():
    manifest = build_manifest("sample_bundle")
    assert "policy" in manifest
