
import os

DEFAULT_POLICY = {
    "allow_docs": True,
    "allow_config": True,
    "minimize_scopes": True
}

def scan_bundle(bundle_root):
    structure = {
        "install": False,
        "config": False,
        "docs": False,
        "files": []
    }

    for root, dirs, files in os.walk(bundle_root):
        rel_root = os.path.relpath(root, bundle_root)
        if rel_root == ".":
            rel_root = ""

        if rel_root.startswith("install"):
            structure["install"] = True
        if rel_root.startswith("config"):
            structure["config"] = True
        if rel_root.startswith("docs"):
            structure["docs"] = True

        for f in files:
            full_path = os.path.join(rel_root, f).replace("\\", "/")
            structure["files"].append(full_path)

    return structure


def build_allowed_paths(structure, policy):
    allowed = set()

    # Always include manifest
    allowed.add("bundle_manifest.json")

    # Dynamic tightening logic
    if policy["minimize_scopes"]:
        # Only include domains that actually exist
        if structure["install"]:
            allowed.add("install/")
        if structure["config"] and policy["allow_config"]:
            allowed.add("config/")
        if structure["docs"] and policy["allow_docs"]:
            allowed.add("docs/")
    else:
        # fallback broad mode
        allowed.update(["install/", "config/", "docs/"])

    return sorted(list(allowed))


def build_manifest(bundle_root, policy=None):
    if policy is None:
        policy = DEFAULT_POLICY

    structure = scan_bundle(bundle_root)
    allowed_paths = build_allowed_paths(structure, policy)

    manifest = {
        "bundle_name": os.path.basename(bundle_root),
        "bundle_version": "3.0.0",
        "install_mode": "folder_map",
        "policy": policy,
        "allowed_paths": allowed_paths
    }

    return manifest


if __name__ == "__main__":
    root = os.getcwd()
    manifest = build_manifest(root)
    print(manifest)
