
def validate_policy(policy):
    required_keys = ["allow_docs", "allow_config", "minimize_scopes"]

    for key in required_keys:
        if key not in policy:
            raise ValueError(f"Missing policy key: {key}")

    return True
