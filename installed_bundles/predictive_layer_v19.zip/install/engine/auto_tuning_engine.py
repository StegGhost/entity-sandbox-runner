
def auto_tune(params, metrics, rate=0.1):
    if metrics.get("failure_rate",0) > 0.3:
        params["slash_rate"] = params.get("slash_rate",1.0) * (1 + rate)
    if metrics.get("throughput",1) < 0.5:
        params["reward_rate"] = params.get("reward_rate",1.0) * (1 + rate)
    return params
