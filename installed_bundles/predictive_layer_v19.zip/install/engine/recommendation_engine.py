
def recommend(metrics):
    recs = []
    if metrics.get("failure_rate",0) > 0.3:
        recs.append("Increase slashing severity")
    if metrics.get("throughput",1) < 0.5:
        recs.append("Increase rewards for execution")
    return recs
