
def simulate_trajectory(current, steps=5):
    return [current + i for i in range(steps)]
