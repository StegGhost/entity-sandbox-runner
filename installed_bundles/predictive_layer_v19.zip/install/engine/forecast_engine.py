
def forecast(metric_history):
    if len(metric_history) < 2:
        return metric_history
    trend = metric_history[-1] - metric_history[-2]
    return [metric_history[-1] + i * trend for i in range(1,6)]
