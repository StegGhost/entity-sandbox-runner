
from install.engine.auto_tuning_engine import auto_tune

def test_tune():
    params = {"slash_rate":1.0}
    out = auto_tune(params, {"failure_rate":0.5})
    assert out["slash_rate"] > 1.0
