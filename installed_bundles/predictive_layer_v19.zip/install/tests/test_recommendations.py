
from install.engine.recommendation_engine import recommend

def test_recs():
    recs = recommend({"failure_rate":0.5})
    assert len(recs) > 0
