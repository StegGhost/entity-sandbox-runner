
from install.engine.forecast_engine import forecast

def test_forecast():
    out = forecast([1,2])
    assert len(out) > 0
