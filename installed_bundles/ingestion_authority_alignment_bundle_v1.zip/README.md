# Ingestion Authority Alignment Bundle v1

Purpose:
- make `install/ingestion_v2.py` the single authoritative installer path
- remove `install/apply.py` as a competing mutation path by turning it into a compatibility wrapper
- stop `execute_next_action.py` from performing direct installation
- keep review -> repair -> review grounded in `logs/ingestion_log.json`

Files included:
- install/ingestion_v2.py
- install/apply.py
- install/engine/execute_next_action.py
- install/engine/reconcile_execution_state.py
