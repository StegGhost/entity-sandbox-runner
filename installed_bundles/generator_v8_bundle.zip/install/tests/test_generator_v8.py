
from install.engine.proposal_to_bundle import build_manifest

def test_economics_present():
    m = build_manifest("sample_bundle")
    assert "economics" in m

def test_rewards_logic():
    m = build_manifest("sample_bundle", identity="agent1", outcome="success")
    assert m["economics"]["agent1"]["balance"] >= 0
