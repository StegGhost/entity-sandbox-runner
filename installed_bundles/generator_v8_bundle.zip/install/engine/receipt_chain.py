
import hashlib, json, os

STATE_FILE = ".receipt_state.json"

def generate_receipt(files, passport):
    payload = "".join(sorted(files)) + passport["hash"]
    return {
        "file_hash": hashlib.sha256(payload.encode()).hexdigest(),
        "file_count": len(files)
    }

def load_previous_receipt(bundle_root):
    path = os.path.join(bundle_root, STATE_FILE)
    if os.path.exists(path):
        with open(path, "r") as f:
            return json.load(f)
    return None

def link_receipts(previous, current):
    return {"current": current, "previous": previous}

def persist_receipt(bundle_root, receipt):
    path = os.path.join(bundle_root, STATE_FILE)
    with open(path, "w") as f:
        json.dump(receipt, f)
