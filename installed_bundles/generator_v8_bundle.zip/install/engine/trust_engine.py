
import json, os

TRUST_FILE = ".trust_state.json"

def load_trust_state(bundle_root):
    path = os.path.join(bundle_root, TRUST_FILE)
    if os.path.exists(path):
        with open(path, "r") as f:
            return json.load(f)
    return {}

def update_trust(state, identity, outcome):
    if identity not in state:
        state[identity] = {"score": 0, "history": []}

    if outcome == "success":
        state[identity]["score"] += 1
    else:
        state[identity]["score"] -= 2

    state[identity]["history"].append(outcome)
    return state
