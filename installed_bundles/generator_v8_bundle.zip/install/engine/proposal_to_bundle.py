
import os
from .passport import generate_passport
from .receipt_chain import generate_receipt, link_receipts, load_previous_receipt, persist_receipt
from .trust_engine import update_trust, load_trust_state
from .economic_engine import apply_economics, load_economic_state

DEFAULT_POLICY = {
    "allow_docs": True,
    "allow_config": True,
    "minimize_scopes": True
}

def scan_bundle(bundle_root):
    structure = {"install": False, "config": False, "docs": False, "files": []}
    for root, dirs, files in os.walk(bundle_root):
        rel_root = os.path.relpath(root, bundle_root)
        if rel_root == ".": rel_root = ""
        if rel_root.startswith("install"): structure["install"] = True
        if rel_root.startswith("config"): structure["config"] = True
        if rel_root.startswith("docs"): structure["docs"] = True
        for f in files:
            structure["files"].append(os.path.join(rel_root, f).replace("\\","/"))
    return structure

def build_allowed_paths(structure, policy):
    allowed = set(["bundle_manifest.json"])
    if structure["install"]: allowed.add("install/")
    if structure["config"] and policy["allow_config"]: allowed.add("config/")
    if structure["docs"] and policy["allow_docs"]: allowed.add("docs/")
    return sorted(list(allowed))

def build_manifest(bundle_root, policy=None, identity="unknown", outcome="success"):
    if policy is None: policy = DEFAULT_POLICY

    structure = scan_bundle(bundle_root)
    allowed_paths = build_allowed_paths(structure, policy)

    passport = generate_passport(identity, policy)

    prev_receipt = load_previous_receipt(bundle_root)
    receipt = generate_receipt(structure["files"], passport)
    chained = link_receipts(prev_receipt, receipt)
    persist_receipt(bundle_root, chained)

    trust_state = load_trust_state(bundle_root)
    updated_trust = update_trust(trust_state, identity, outcome)

    econ_state = load_economic_state(bundle_root)
    updated_econ = apply_economics(econ_state, identity, outcome, updated_trust)

    return {
        "bundle_name": os.path.basename(bundle_root),
        "bundle_version": "8.0.0",
        "install_mode": "folder_map",
        "policy": policy,
        "identity": passport,
        "receipt": chained,
        "trust": updated_trust,
        "economics": updated_econ,
        "allowed_paths": allowed_paths
    }
