
import json, os

ECON_FILE = ".economic_state.json"

def load_economic_state(bundle_root):
    path = os.path.join(bundle_root, ECON_FILE)
    if os.path.exists(path):
        with open(path, "r") as f:
            return json.load(f)
    return {}

def apply_economics(state, identity, outcome, trust_state):
    if identity not in state:
        state[identity] = {"balance": 0, "rewards": 0, "slashes": 0}

    if outcome == "success":
        reward = 10 + trust_state[identity]["score"]
        state[identity]["balance"] += reward
        state[identity]["rewards"] += reward
    else:
        penalty = 15
        state[identity]["balance"] -= penalty
        state[identity]["slashes"] += penalty

    return state
