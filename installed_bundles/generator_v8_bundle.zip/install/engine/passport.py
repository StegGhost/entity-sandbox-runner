
import hashlib, time

def generate_passport(identity, policy):
    payload = f"{identity}-{policy}-{time.time()}"
    return {
        "identity": identity,
        "timestamp": time.time(),
        "hash": hashlib.sha256(payload.encode()).hexdigest()
    }
