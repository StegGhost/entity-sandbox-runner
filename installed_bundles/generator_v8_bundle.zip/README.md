
# Generator V8 Bundle

Slashing + Rewards + Economic Governance

- Trust-weighted rewards
- Slashing penalties
- Persistent economic state
