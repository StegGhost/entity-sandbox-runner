class RelationshipPolicyEngine:
    def resolve_role(self, relationship_state):
        if relationship_state.get("boundary_clarity", 0.0) < 0.5:
            return "guardian"
        if relationship_state.get("trust_level", 0.0) > 0.8:
            return "advisor"
        return "advisor"

    def apply(self, role, action):
        if role == "guardian":
            return "ESCALATE"
        if role == "advisor":
            return "ALLOW_WITH_GUIDANCE"
        return "ALLOW"
