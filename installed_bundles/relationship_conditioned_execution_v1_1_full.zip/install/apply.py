import os
import sys

ROOT = os.path.dirname(os.path.abspath(__file__))
if ROOT not in sys.path:
    sys.path.insert(0, ROOT)

from decision_integration_hook import evaluate


def apply(action, history, witnesses=None):
    return evaluate(action=action, history=history, witnesses=witnesses or [])


if __name__ == "__main__":
    demo_action = {
        "type": "irreversible_human_decision",
        "consent": True,
        "traceable": True,
        "irreversible": True,
        "uncertainty_ack": True,
        "quorum_required": 2,
    }
    demo_history = [
        {"type": "advisory", "violation": False},
        {"type": "irreversible_human_decision", "violation": False},
        {"type": "irreversible_human_decision", "violation": False},
    ]
    print(apply(demo_action, demo_history, witnesses=[]))
