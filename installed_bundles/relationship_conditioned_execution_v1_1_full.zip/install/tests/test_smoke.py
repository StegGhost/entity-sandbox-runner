import os
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if ROOT not in sys.path:
    sys.path.insert(0, ROOT)

from apply import apply


def test_block_without_witnesses():
    action = {
        "type": "irreversible_human_decision",
        "consent": True,
        "traceable": True,
        "irreversible": True,
        "uncertainty_ack": True,
        "quorum_required": 2,
    }
    history = [
        {"type": "irreversible_human_decision", "violation": False},
        {"type": "irreversible_human_decision", "violation": False},
        {"type": "irreversible_human_decision", "violation": False},
    ]
    result = apply(action, history, witnesses=[])
    assert result["decision"] == "BLOCK"
    assert result["reason"] == "quorum_failed"
