class StegVerseEthicsGuard:
    def validate(self, action):
        if not action.get("consent"):
            return False, "consent_missing"

        if not action.get("traceable"):
            return False, "traceability_required"

        if action.get("irreversible") and not action.get("uncertainty_ack"):
            return False, "uncertainty_not_acknowledged"

        return True, "ok"
