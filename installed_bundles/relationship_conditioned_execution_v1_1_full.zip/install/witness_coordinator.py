class WitnessCoordinator:
    def collect(self, action, witnesses):
        approvals = []
        for witness in witnesses:
            decision = witness.evaluate(action)
            approvals.append({
                "witness_id": getattr(witness, "id", "unknown"),
                "decision": decision
            })
        return approvals
