class RelationshipHistoryAnalyzer:
    def is_typical(self, action, history):
        similar = [h for h in history if h.get("type") == action.get("type")]
        return len(similar) > 2
