class SelfHealingEngine:
    def attempt_recovery(self, failure_reason, action):
        if failure_reason == "consent_missing":
            return {"action": "request_consent"}
        if failure_reason == "non_guarantee_not_ack":
            return {"action": "prompt_uncertainty_ack"}
        if failure_reason == "quorum_failed":
            return {"action": "route_to_alternative"}
        if failure_reason == "traceability_required":
            return {"action": "restore_traceability"}
        return {"action": "escalate"}
