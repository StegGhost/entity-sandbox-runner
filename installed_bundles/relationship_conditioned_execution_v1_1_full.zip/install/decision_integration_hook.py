from relationship_state_engine import RelationshipStateEngine
from relationship_history_analyzer import RelationshipHistoryAnalyzer
from relationship_policy_engine import RelationshipPolicyEngine
from stegverse_ethics_guard import StegVerseEthicsGuard
from non_guarantee_invariant import check_non_guarantee
from temporal_identity_guard import identity_risk
from decision_state_recorder import DecisionStateRecorder
from witness_coordinator import WitnessCoordinator
from quorum_validator import QuorumValidator
from self_healing_engine import SelfHealingEngine
from anomaly_detector import AnomalyDetector
from trust_decay_engine import TrustDecayEngine


def evaluate(action, history, witnesses=None):
    witnesses = witnesses or []

    rel_engine = RelationshipStateEngine()
    analyzer = RelationshipHistoryAnalyzer()
    policy_engine = RelationshipPolicyEngine()
    ethics = StegVerseEthicsGuard()
    recorder = DecisionStateRecorder()

    witness_coord = WitnessCoordinator()
    quorum = QuorumValidator()
    healer = SelfHealingEngine()
    anomaly = AnomalyDetector()
    trust_decay = TrustDecayEngine()

    relationship = rel_engine.evaluate(history)
    relationship["trust_level"] = trust_decay.update(
        relationship["trust_level"], history
    )

    if anomaly.detect(action, history):
        action["anomaly_flag"] = True
        action["requires_reflection"] = True

    if not analyzer.is_typical(action, history):
        action["requires_reflection"] = True

    valid, reason = ethics.validate(action)
    if not valid:
        recovery = healer.attempt_recovery(reason, action)
        return {"decision": "BLOCK", "reason": reason, "recovery": recovery}

    if not check_non_guarantee(action):
        recovery = healer.attempt_recovery("non_guarantee_not_ack", action)
        return {
            "decision": "BLOCK",
            "reason": "non_guarantee_not_ack",
            "recovery": recovery,
        }

    if identity_risk(action) == "HIGH":
        action["friction"] = "increased"

    if action.get("irreversible"):
        approvals = witness_coord.collect(action, witnesses)
        required = action.get("quorum_required", 2)
        if not quorum.validate(approvals, required=required):
            recovery = healer.attempt_recovery("quorum_failed", action)
            return {
                "decision": "BLOCK",
                "reason": "quorum_failed",
                "approvals": approvals,
                "recovery": recovery,
            }
        action["witness_approvals"] = approvals

    role = policy_engine.resolve_role(relationship)
    decision = policy_engine.apply(role, action)

    receipt = recorder.record({
        "type": "relationship_conditioned_decision",
        "version": "1.1.0",
        "relationship": relationship,
        "role": role,
        "decision": decision,
        "action": action,
    })
    return receipt
