import hashlib
import json
import time

class DecisionStateRecorder:
    def record(self, payload):
        payload = dict(payload)
        payload["timestamp"] = time.time()
        payload["hash"] = self._hash(payload)
        return payload

    def _hash(self, payload):
        data = json.dumps(payload, sort_keys=True).encode()
        return hashlib.sha256(data).hexdigest()
