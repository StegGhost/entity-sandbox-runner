def identity_risk(action):
    if action.get("irreversible"):
        return "HIGH"
    return "LOW"
