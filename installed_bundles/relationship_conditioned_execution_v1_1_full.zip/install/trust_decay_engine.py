class TrustDecayEngine:
    def update(self, trust, events):
        penalties = sum(1 for e in events if e.get("violation"))
        decay = penalties * 0.05
        return max(0.0, trust - decay)
