def check_non_guarantee(action):
    return action.get("uncertainty_ack", False)
