def select_best(candidates):
    admissible = [c for c in candidates if c["evaluation"]["admissible"]]
    if not admissible:
        return None
    admissible.sort(
        key=lambda c: (
            -c["evaluation"]["viability_score"],
            c["state"]["a"],
            c["proposal"]["delta_a"],
        )
    )
    return admissible[0]
