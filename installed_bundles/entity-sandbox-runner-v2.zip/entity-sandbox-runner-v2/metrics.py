import math

def compute_viability(g, c, t, K, alpha, beta, gamma):
    return K * (g ** alpha) * (c ** beta) * (t ** gamma)

def viability_score(g, c, a, t, K, alpha, beta, gamma):
    return compute_viability(g, c, t, K, alpha, beta, gamma) - a

def throughput_vs_legitimacy(g, a, t):
    denom = g * t
    return a / denom if denom > 0 else float("inf")

def rigel_distance(state, equilibrium):
    return math.sqrt(sum((state[i] - equilibrium[i]) ** 2 for i in range(len(state))))
