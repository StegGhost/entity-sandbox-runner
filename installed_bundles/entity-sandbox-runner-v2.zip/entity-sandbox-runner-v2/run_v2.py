import json
import time
import yaml
import hashlib
from pathlib import Path

from metrics import (
    compute_viability,
    viability_score,
    throughput_vs_legitimacy,
    rigel_distance,
)
from selector import select_best

def update_state(state, delta_a, degrade_g, degrade_t):
    g, c, a, t = state
    new_g = max(0.0, g - degrade_g)
    new_c = c
    new_a = min(1.0, a + delta_a)
    new_t = max(0.0, t - degrade_t)
    return (new_g, new_c, new_a, new_t)

def hash_receipt(payload):
    return hashlib.sha256(json.dumps(payload, sort_keys=True).encode()).hexdigest()

def create_candidate(prev_hash, entity_name, state, proposal, evaluation, step):
    payload = {
        "prev_receipt_hash": prev_hash,
        "timestamp": time.time(),
        "step": step,
        "entity": entity_name,
        "proposal": proposal,
        "evaluation": evaluation,
        "state": {
            "g": state[0],
            "c": state[1],
            "a": state[2],
            "t": state[3],
        },
    }
    payload["receipt_hash"] = hash_receipt(payload)
    return payload

def main():
    root = Path(__file__).resolve().parent
    with open(root / "config_v2.yaml", "r") as f:
        config = yaml.safe_load(f)

    g, c, a, t = config["initial_state"]
    K = float(config["K"])
    alpha = float(config["alpha"])
    beta = float(config["beta"])
    gamma = float(config["gamma"])
    steps = int(config["steps"])
    degrade_g = float(config["degrade_g"])
    degrade_t = float(config["degrade_t"])
    equilibrium = config["rigel_equilibrium"]
    entities = config["entities"]

    results_dir = root / "results"
    results_dir.mkdir(exist_ok=True)

    receipts = []
    metrics_timeline = []
    prev_hash = ""
    accepted_count = 0
    rejected_count = 0

    for step in range(1, steps + 1):
        candidates = []

        for entity in entities:
            proposal = {"delta_a": float(entity["delta_a"])}
            proposed_state = update_state((g, c, a, t), proposal["delta_a"], degrade_g, degrade_t)

            vg = compute_viability(proposed_state[0], proposed_state[1], proposed_state[3], K, alpha, beta, gamma)
            vscore = viability_score(proposed_state[0], proposed_state[1], proposed_state[2], proposed_state[3], K, alpha, beta, gamma)
            tvl = throughput_vs_legitimacy(proposed_state[0], proposed_state[2], proposed_state[3])
            rd = rigel_distance(proposed_state, equilibrium)
            admissible = proposed_state[2] <= vg

            evaluation = {
                "viability": vg,
                "viability_score": vscore,
                "throughput_vs_legitimacy": tvl,
                "rigel_distance": rd,
                "admissible": admissible,
            }

            candidate = create_candidate(prev_hash, entity["name"], proposed_state, proposal, evaluation, step)
            candidates.append(candidate)

        selected = select_best(candidates)

        if selected is None:
            rejected_count += 1
            metrics_timeline.append({
                "step": step,
                "accepted": False,
                "selected_entity": None,
                "state": {"g": g, "c": c, "a": a, "t": t},
            })
            receipts.extend(candidates)
            if candidates:
                prev_hash = candidates[-1]["receipt_hash"]
            continue

        accepted_count += 1
        chosen_state = selected["state"]
        g, c, a, t = chosen_state["g"], chosen_state["c"], chosen_state["a"], chosen_state["t"]

        metrics_timeline.append({
            "step": step,
            "accepted": True,
            "selected_entity": selected["entity"],
            "state": selected["state"],
            "evaluation": selected["evaluation"],
        })

        receipts.extend(candidates)
        prev_hash = selected["receipt_hash"]

    summary_lines = [
        f"Completed {steps} steps: {accepted_count} accepted, {rejected_count} rejected.",
        f"Final state: g={g:.3f}, c={c:.3f}, a={a:.3f}, t={t:.3f}",
        "Selector policy: highest viability score among admissible proposals.",
        f"Entities tested: {', '.join(e['name'] for e in entities)}",
    ]

    with open(results_dir / "summary.txt", "w") as f:
        f.write("\n".join(summary_lines) + "\n")

    with open(results_dir / "metrics.json", "w") as f:
        json.dump(metrics_timeline, f, indent=2)

    with open(results_dir / "receipts.json", "w") as f:
        json.dump(receipts, f, indent=2)

    print("\n".join(summary_lines))

if __name__ == "__main__":
    main()
