# Entity Sandbox Runner v2

This repository runs the **v2 governed admissibility experiment** for StegVerse.

It upgrades the first test by introducing:
- multiple entity proposals per step
- governance-based proposal selection
- metrics generation
- receipt chaining
- workflow automation

## What v2 tests

At each timestep, multiple entities propose changes to artifact pressure `a`.
The runner:

1. Generates candidate proposals
2. Applies the transition operator to each proposal
3. Evaluates admissibility using the GCAT inequality
4. Computes metrics for each candidate
5. Selects the best admissible proposal using a simple governance selector
6. Commits the chosen state and records a chained receipt

If no proposal is admissible, the system holds state and records a rejected step.

## Files

- `run_v2.py` — main experiment runner
- `config_v2.yaml` — experiment parameters
- `metrics.py` — common metric functions
- `selector.py` — governance selector for admissible proposals
- `.github/workflows/run-v2.yml` — GitHub Actions workflow
- `results/example_summary.txt` — example summary output
- `results/example_metrics.json` — example metrics output
- `.gitignore` — ignores generated receipts and local caches

## Running locally

Install dependency:

```sh
python -m pip install pyyaml
```

Run:

```sh
python run_v2.py
```

Outputs are written to:
- `results/summary.txt`
- `results/metrics.json`
- `results/receipts.json`
