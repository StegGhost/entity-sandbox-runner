import json

def compute_violations(state):
    violations = []
    if not state.get("valid", False):
        violations.append("invalid_state")
    return violations

def apply_fix(state, violations):
    if "invalid_state" in violations:
        state["valid"] = True
    return state

def run_closure_loop():
    state = {"valid": False}
    history = []

    while True:
        violations = compute_violations(state)
        history.append({"state": dict(state), "violations": violations})

        if not violations:
            break

        state = apply_fix(state, violations)

    with open("history_stream.jsonl", "w") as f:
        for entry in history:
            f.write(json.dumps(entry) + "\n")

    print("Converged. History written.")

if __name__ == "__main__":
    run_closure_loop()
