
def evolve_mechanisms(mechanisms, performance_scores):
    # select top-performing mechanisms
    sorted_mech = sorted(mechanisms, key=lambda m: performance_scores.get(m, 0), reverse=True)
    return sorted_mech[:max(1, len(sorted_mech)//2)]
