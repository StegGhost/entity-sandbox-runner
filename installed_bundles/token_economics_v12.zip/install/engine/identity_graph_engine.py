
GRAPH = {}

def add_identity(node):
    GRAPH[node] = []

def link_identities(a, b):
    GRAPH.setdefault(a, []).append(b)
    GRAPH.setdefault(b, []).append(a)

def get_neighbors(node):
    return GRAPH.get(node, [])
