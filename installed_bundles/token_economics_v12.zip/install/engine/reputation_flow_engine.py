
def propagate_reputation(graph, rep):
    new_rep = {}
    for node, neighbors in graph.items():
        new_rep[node] = rep.get(node, 0) + sum(rep.get(n,0) for n in neighbors) * 0.1
    return new_rep
