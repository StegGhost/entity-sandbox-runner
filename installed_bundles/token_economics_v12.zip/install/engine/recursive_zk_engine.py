
import hashlib

def recursive_proof(data, depth=3):
    proof = str(data)
    for _ in range(depth):
        proof = hashlib.sha256(proof.encode()).hexdigest()
    return proof

def verify_recursive(data, proof, depth=3):
    return recursive_proof(data, depth) == proof
