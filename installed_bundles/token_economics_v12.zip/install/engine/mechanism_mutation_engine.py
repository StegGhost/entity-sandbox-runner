
import random

def mutate_mechanism(mech):
    return mech + "_mutated_" + str(random.randint(1,1000))
