
from install.engine.self_evolving_mechanism_engine import evolve_mechanisms

def test_evolve():
    mechs = ["a","b","c"]
    scores = {"a":1,"b":2,"c":0}
    out = evolve_mechanisms(mechs, scores)
    assert "b" in out
