
from install.engine.identity_graph_engine import add_identity, link_identities, get_neighbors

def test_graph():
    add_identity("a")
    link_identities("a","b")
    assert "b" in get_neighbors("a")
