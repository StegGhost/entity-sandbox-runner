
from install.engine.recursive_zk_engine import recursive_proof, verify_recursive

def test_recursive():
    data = "x"
    proof = recursive_proof(data)
    assert verify_recursive(data, proof)
