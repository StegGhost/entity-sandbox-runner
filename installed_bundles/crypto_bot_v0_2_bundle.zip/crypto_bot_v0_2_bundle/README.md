# Coinbase micro market-maker v0.2 bundle

This bundle contains a **single-position, fee-aware micro market-making bot** for Coinbase Advanced Trade.

It uses:
- the official Coinbase Advanced Trade Python SDK
- live ticker data over WebSocket
- post-only limit orders
- a fee-aware exit rule that will not place a profit-taking exit unless projected net profit is at least **$1.00** after fees and a slippage buffer

## Files

- `app.py` — main bot
- `config.py` — local configuration and API keys
- `requirements.txt` — Python dependencies

## Safety posture

This bundle defaults to:
- `DRY_RUN = True`
- one open position max
- small notional sizing
- daily loss cap
- time-based escape path

Do **not** change `DRY_RUN` to `False` until you have confirmed:
1. your API key works
2. product ID and price precision are correct
3. the bot logs make sense
4. your order permissions exclude withdrawals

## Install

```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
```

## Configure

Edit `config.py`:
- `API_KEY`
- `API_SECRET`
- `PRODUCT_ID`
- `POSITION_NOTIONAL_USD`

Coinbase's current official Python SDK documentation shows CDP-style API keys and the `RESTClient` / `WSClient` approach for Advanced Trade. citeturn292095search0turn292095search5turn292095search7

## Run

```bash
python app.py
```

## Notes

- This is **v0.2**, not production-grade HFT.
- Order reconciliation is intentionally simple.
- The code uses a **conservative fee model** instead of reading your exact current fee tier.
- `MAX_HOLD_SECONDS` exists because a strict “never sell until +$1” rule can trap inventory indefinitely.

## What the bot does

1. Subscribes to live ticker updates for `PRODUCT_ID`
2. Places a post-only buy order near best bid when spread is small enough
3. Reconciles fills
4. Computes the minimum profitable exit price after:
   - entry fee
   - estimated exit fee
   - slippage buffer
   - desired minimum profit
5. Places a post-only sell order only when the target economics are met, or when risk controls force a timed exit path

## Important limitations

- No persistent database yet
- No partial-fill inventory accounting beyond basic reconciliation
- No advanced cancel/replace ladder
- No multi-position grid
- No formal backtest harness

## Recommended next upgrade

The safest next version is v0.3 with:
- persistent SQLite ledger
- explicit partial-fill handling
- cancel/replace logic for stale exits
- configurable trend filter
- separate paper and live execution adapters
