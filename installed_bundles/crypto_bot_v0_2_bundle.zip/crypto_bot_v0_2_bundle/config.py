# Coinbase Advanced Trade v0.2 configuration.
# Populate with your Coinbase Developer Platform API key values.

API_KEY = "organizations/ORG_ID/apiKeys/KEY_ID"
API_SECRET = "-----BEGIN EC PRIVATE KEY-----\nYOUR_PRIVATE_KEY\n-----END EC PRIVATE KEY-----\n"

PRODUCT_ID = "ETH-USD"
BASE_CURRENCY = "ETH"
COUNTER_CURRENCY = "USD"

# Start tiny for live testing.
POSITION_NOTIONAL_USD = 25.0

# Conservative fee model. Adjust once you confirm your actual maker/taker tier.
FEE_RATE = 0.004
MIN_NET_PROFIT_USD = 1.00
SLIPPAGE_BUFFER_USD = 0.25

# Risk controls.
MAX_HOLD_SECONDS = 1800
MAX_DAILY_LOSS_USD = 10.0
MAX_OPEN_POSITIONS = 1
SPREAD_LIMIT_USD = 2.0
ORDER_REFRESH_SECONDS = 20
POST_ONLY = True
PRICE_DECIMALS = 2

# Set to True for paper-like behavior using live market data but no real orders.
DRY_RUN = True

LOG_LEVEL = "INFO"
