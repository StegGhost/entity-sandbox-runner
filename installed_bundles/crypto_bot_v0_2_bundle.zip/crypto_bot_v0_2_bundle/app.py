import logging
import signal
import sys
import threading
import time
import uuid
from dataclasses import dataclass
from decimal import Decimal, ROUND_UP
from pathlib import Path
from typing import Optional

from coinbase.rest import RESTClient
from coinbase.websocket import WSClient

from config import (
    API_KEY,
    API_SECRET,
    BASE_CURRENCY,
    COUNTER_CURRENCY,
    DRY_RUN,
    FEE_RATE,
    LOG_LEVEL,
    MAX_DAILY_LOSS_USD,
    MAX_HOLD_SECONDS,
    MAX_OPEN_POSITIONS,
    MIN_NET_PROFIT_USD,
    ORDER_REFRESH_SECONDS,
    POSITION_NOTIONAL_USD,
    POST_ONLY,
    PRICE_DECIMALS,
    PRODUCT_ID,
    SLIPPAGE_BUFFER_USD,
    SPREAD_LIMIT_USD,
)

logging.basicConfig(
    level=getattr(logging, LOG_LEVEL.upper(), logging.INFO),
    format="%(asctime)s %(levelname)s %(message)s",
)
logger = logging.getLogger("micro_mm")


@dataclass
class Position:
    entry_order_id: str
    entry_price: Decimal
    base_size: Decimal
    entry_fee_usd: Decimal
    opened_at: float


class OrderBookState:
    def __init__(self) -> None:
        self.best_bid: Optional[Decimal] = None
        self.best_ask: Optional[Decimal] = None
        self.lock = threading.Lock()

    def update(self, best_bid: str, best_ask: str) -> None:
        with self.lock:
            self.best_bid = Decimal(best_bid)
            self.best_ask = Decimal(best_ask)

    def snapshot(self) -> tuple[Optional[Decimal], Optional[Decimal]]:
        with self.lock:
            return self.best_bid, self.best_ask


class FeeAwareTrader:
    def __init__(self) -> None:
        self.client = RESTClient(api_key=API_KEY, api_secret=API_SECRET)
        self.orderbook = OrderBookState()
        self.position: Optional[Position] = None
        self.active_entry_order_id: Optional[str] = None
        self.active_exit_order_id: Optional[str] = None
        self.daily_realized_pnl = Decimal("0")
        self.last_entry_submitted_at = 0.0
        self.shutdown = False

    def _round_price(self, price: Decimal) -> Decimal:
        quant = Decimal("1").scaleb(-PRICE_DECIMALS)
        return price.quantize(quant, rounding=ROUND_UP)

    def _base_size_for_notional(self, price: Decimal) -> Decimal:
        # Coinbase expects a string. Eight decimals is conservative for majors.
        size = (Decimal(str(POSITION_NOTIONAL_USD)) / price).quantize(Decimal("0.00000001"))
        return size

    def on_ws_message(self, message) -> None:
        try:
            events = message.get("events", [])
            for event in events:
                tickers = event.get("tickers", [])
                for ticker in tickers:
                    if ticker.get("product_id") == PRODUCT_ID:
                        self.orderbook.update(ticker["best_bid"], ticker["best_ask"])
        except Exception as exc:
            logger.exception("Failed to parse websocket message: %s", exc)

    def start_market_data(self) -> WSClient:
        ws = WSClient(
            api_key=API_KEY,
            api_secret=API_SECRET,
            on_message=self.on_ws_message,
        )
        ws.open()
        ws.ticker(product_ids=[PRODUCT_ID])
        logger.info("Subscribed to ticker channel for %s", PRODUCT_ID)
        return ws

    def projected_net_profit(self, exit_price: Decimal) -> Decimal:
        assert self.position is not None
        gross = (exit_price - self.position.entry_price) * self.position.base_size
        exit_fee = (exit_price * self.position.base_size * Decimal(str(FEE_RATE))).quantize(Decimal("0.00000001"))
        net = gross - self.position.entry_fee_usd - exit_fee - Decimal(str(SLIPPAGE_BUFFER_USD))
        return net

    def min_profitable_exit_price(self) -> Decimal:
        assert self.position is not None
        fee_rate = Decimal(str(FEE_RATE))
        entry_cost = self.position.entry_price * self.position.base_size
        required = entry_cost + self.position.entry_fee_usd + Decimal(str(SLIPPAGE_BUFFER_USD)) + Decimal(str(MIN_NET_PROFIT_USD))
        denominator = self.position.base_size * (Decimal("1") - fee_rate)
        raw = required / denominator
        return self._round_price(raw)

    def can_enter(self, best_bid: Decimal, best_ask: Decimal) -> bool:
        if self.position is not None:
            return False
        if self.active_entry_order_id is not None:
            return False
        if self.active_exit_order_id is not None:
            return False
        if self.daily_realized_pnl <= Decimal(str(-MAX_DAILY_LOSS_USD)):
            logger.warning("Daily loss limit reached; refusing new entries")
            return False
        if MAX_OPEN_POSITIONS != 1:
            logger.warning("This v0.2 bundle only supports one open position safely")
            return False
        spread = best_ask - best_bid
        return spread <= Decimal(str(SPREAD_LIMIT_USD))

    def place_limit_order(self, side: str, price: Decimal, base_size: Decimal) -> Optional[str]:
        client_order_id = str(uuid.uuid4())
        if DRY_RUN:
            logger.info("DRY_RUN %s %s %s @ %s", side, PRODUCT_ID, base_size, price)
            return client_order_id

        response = self.client.limit_order_gtc_buy(
            client_order_id=client_order_id,
            product_id=PRODUCT_ID,
            base_size=str(base_size),
            limit_price=str(price),
            post_only=POST_ONLY,
        ) if side == "BUY" else self.client.limit_order_gtc_sell(
            client_order_id=client_order_id,
            product_id=PRODUCT_ID,
            base_size=str(base_size),
            limit_price=str(price),
            post_only=POST_ONLY,
        )

        if getattr(response, "success", False):
            order_id = getattr(response, "order_id", None) or client_order_id
            logger.info("Placed %s order_id=%s size=%s price=%s", side, order_id, base_size, price)
            return order_id

        logger.error("Order failed: %s", response)
        return None

    def cancel_order(self, order_id: str) -> None:
        if DRY_RUN:
            logger.info("DRY_RUN cancel order %s", order_id)
            return
        try:
            self.client.cancel_orders(order_ids=[order_id])
            logger.info("Canceled order %s", order_id)
        except Exception as exc:
            logger.exception("Failed to cancel order %s: %s", order_id, exc)

    def poll_order_status(self, order_id: str):
        if DRY_RUN:
            return {"status": "FILLED", "avg_filled_price": "0", "filled_size": "0"}
        return self.client.get_order(order_id=order_id)

    def maybe_submit_entry(self, best_bid: Decimal, best_ask: Decimal) -> None:
        if not self.can_enter(best_bid, best_ask):
            return
        price = self._round_price(best_bid)
        base_size = self._base_size_for_notional(price)
        order_id = self.place_limit_order("BUY", price, base_size)
        if order_id:
            self.active_entry_order_id = order_id
            self.last_entry_submitted_at = time.time()

    def reconcile_entry(self) -> None:
        if self.active_entry_order_id is None:
            return
        if DRY_RUN:
            best_bid, _ = self.orderbook.snapshot()
            if best_bid is None:
                return
            price = self._round_price(best_bid)
            size = self._base_size_for_notional(price)
            entry_fee = (price * size * Decimal(str(FEE_RATE))).quantize(Decimal("0.00000001"))
            self.position = Position(
                entry_order_id=self.active_entry_order_id,
                entry_price=price,
                base_size=size,
                entry_fee_usd=entry_fee,
                opened_at=time.time(),
            )
            logger.info("DRY_RUN filled entry @ %s size=%s", price, size)
            self.active_entry_order_id = None
            return

        try:
            order = self.client.get_order(order_id=self.active_entry_order_id)
            status = getattr(order, "status", None) or getattr(order, "order", {}).get("status")
            if str(status).upper() in {"FILLED", "FILLED_SUCCESS"}:
                avg_price = Decimal(str(getattr(order, "average_filled_price", None) or getattr(order, "order", {}).get("average_filled_price") or getattr(order, "order", {}).get("avg_filled_price") or "0"))
                filled_size = Decimal(str(getattr(order, "filled_size", None) or getattr(order, "order", {}).get("filled_size") or "0"))
                if avg_price > 0 and filled_size > 0:
                    entry_fee = (avg_price * filled_size * Decimal(str(FEE_RATE))).quantize(Decimal("0.00000001"))
                    self.position = Position(
                        entry_order_id=self.active_entry_order_id,
                        entry_price=avg_price,
                        base_size=filled_size,
                        entry_fee_usd=entry_fee,
                        opened_at=time.time(),
                    )
                    logger.info("Entry filled @ %s size=%s", avg_price, filled_size)
                    self.active_entry_order_id = None
            elif time.time() - self.last_entry_submitted_at > ORDER_REFRESH_SECONDS:
                self.cancel_order(self.active_entry_order_id)
                self.active_entry_order_id = None
        except Exception as exc:
            logger.exception("Entry reconciliation failed: %s", exc)

    def maybe_submit_exit(self, best_bid: Decimal) -> None:
        if self.position is None or self.active_exit_order_id is not None:
            return
        net = self.projected_net_profit(best_bid)
        held = time.time() - self.position.opened_at
        if net >= Decimal(str(MIN_NET_PROFIT_USD)) or held >= MAX_HOLD_SECONDS:
            target = max(self.min_profitable_exit_price(), self._round_price(best_bid))
            order_id = self.place_limit_order("SELL", target, self.position.base_size)
            if order_id:
                self.active_exit_order_id = order_id
                if held >= MAX_HOLD_SECONDS and net < Decimal(str(MIN_NET_PROFIT_USD)):
                    logger.warning("Placed time-based exit below desired economics risk policy")

    def reconcile_exit(self) -> None:
        if self.active_exit_order_id is None or self.position is None:
            return
        if DRY_RUN:
            exit_price = self.min_profitable_exit_price()
            net = self.projected_net_profit(exit_price)
            self.daily_realized_pnl += net
            logger.info("DRY_RUN exit filled @ %s net=%s cumulative=%s", exit_price, net, self.daily_realized_pnl)
            self.position = None
            self.active_exit_order_id = None
            return

        try:
            order = self.client.get_order(order_id=self.active_exit_order_id)
            status = getattr(order, "status", None) or getattr(order, "order", {}).get("status")
            if str(status).upper() in {"FILLED", "FILLED_SUCCESS"}:
                avg_price = Decimal(str(getattr(order, "average_filled_price", None) or getattr(order, "order", {}).get("average_filled_price") or getattr(order, "order", {}).get("avg_filled_price") or "0"))
                if avg_price > 0:
                    net = self.projected_net_profit(avg_price)
                    self.daily_realized_pnl += net
                    logger.info("Exit filled @ %s net=%s cumulative=%s", avg_price, net, self.daily_realized_pnl)
                    self.position = None
                    self.active_exit_order_id = None
        except Exception as exc:
            logger.exception("Exit reconciliation failed: %s", exc)

    def loop(self) -> None:
        while not self.shutdown:
            best_bid, best_ask = self.orderbook.snapshot()
            if best_bid is not None and best_ask is not None:
                logger.info(
                    "market %s bid=%s ask=%s spread=%s pos=%s daily_pnl=%s",
                    PRODUCT_ID,
                    best_bid,
                    best_ask,
                    best_ask - best_bid,
                    bool(self.position),
                    self.daily_realized_pnl,
                )
                self.reconcile_entry()
                self.reconcile_exit()
                self.maybe_submit_entry(best_bid, best_ask)
                self.maybe_submit_exit(best_bid)
            time.sleep(2)


def main() -> None:
    trader = FeeAwareTrader()
    ws = trader.start_market_data()

    def handle_shutdown(signum, frame):
        logger.warning("Received shutdown signal %s", signum)
        trader.shutdown = True
        try:
            ws.close()
        except Exception:
            pass
        sys.exit(0)

    signal.signal(signal.SIGINT, handle_shutdown)
    signal.signal(signal.SIGTERM, handle_shutdown)
    trader.loop()


if __name__ == "__main__":
    main()
