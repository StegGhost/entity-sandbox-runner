import json, os

inp = "payload/runtime/priority_weights.json"
out = "payload/runtime/execution_policy.json"

data = json.load(open(inp)) if os.path.exists(inp) else {"items":[]}

policy = {
    "timestamp": __import__("time").time(),
    "actions": []
}

for item in data.get("items", [])[:10]:
    action = {
        "target": item.get("text"),
        "priority": item.get("score"),
        "action": "focus" if item.get("score",0) >= 2 else "monitor"
    }
    policy["actions"].append(action)

os.makedirs("payload/runtime", exist_ok=True)
json.dump(policy, open(out,"w"), indent=2)

print("policy generated")
