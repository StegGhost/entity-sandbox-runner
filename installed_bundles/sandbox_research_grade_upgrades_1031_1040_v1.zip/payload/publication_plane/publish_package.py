
import shutil
from pathlib import Path

OUT = Path("publish_package")
OUT.mkdir(exist_ok=True)

for f in ["critical_ratio_research.tex", "observatory/u_distribution_real.png"]:
    p = Path(f)
    if p.exists():
        shutil.copy2(p, OUT / p.name)

print("Package ready")
