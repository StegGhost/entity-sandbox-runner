
## Theorem (Proposed)

Under bounded system conditions, the ratio:

U = (C*K)/(P*S)

acts as a stability boundary such that:

- U > 1 implies persistence
- U < 1 implies collapse

Proof sketch forthcoming.
