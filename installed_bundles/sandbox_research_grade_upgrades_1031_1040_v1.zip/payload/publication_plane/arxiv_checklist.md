
## arXiv Checklist
- [ ] Abstract complete
- [ ] Figures included
- [ ] References added
- [ ] PDF compiled
- [ ] Metadata filled
