
from pathlib import Path

TEX = Path("critical_ratio_research.tex")

def main():
    if not TEX.exists():
        return

    content = TEX.read_text()

    content += "\n\n\\includegraphics{observatory/u_distribution_real.png}"
    content += "\n\\includegraphics{observatory/uc_convergence.png}"

    TEX.write_text(content)

if __name__ == "__main__":
    main()
