
import random, json
from pathlib import Path

DATA = Path("experiments/critical_ratio_campaign/results/phase_space_map.json")

def main():
    data = json.loads(DATA.read_text())
    u_vals = [d["U"] for d in data if d.get("U")]

    samples = []
    for _ in range(100):
        sample = random.choices(u_vals, k=len(u_vals))
        samples.append(sum(sample)/len(sample))

    print(min(samples), max(samples))

if __name__ == "__main__":
    main()
