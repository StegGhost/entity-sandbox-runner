
import json
from pathlib import Path

DATA = Path("experiments/critical_ratio_campaign/results/phase_space_map.json")

def main():
    data = json.loads(DATA.read_text())

    violations = [d for d in data if d["U"] > 1 and not d["stable"]]
    print("Violations:", len(violations))

if __name__ == "__main__":
    main()
