
import json
import matplotlib.pyplot as plt
from pathlib import Path

STATE = Path("autonomy_plane/campaign_state.json")

def main():
    if not STATE.exists():
        return

    state = json.loads(STATE.read_text())
    history = state.get("uc_history", [])

    plt.plot(history)
    plt.title("Uc Convergence")
    plt.savefig("observatory/uc_convergence.png")

if __name__ == "__main__":
    main()
