
import json, random
from pathlib import Path

DATA = Path("experiments/critical_ratio_campaign/results/phase_space_map.json")

def main():
    data = json.loads(DATA.read_text())

    random_vals = [random.random() for _ in range(len(data))]
    real_vals = [d["U"] for d in data if d.get("U")]

    print("Real avg:", sum(real_vals)/len(real_vals))
    print("Random avg:", sum(random_vals)/len(random_vals))

if __name__ == "__main__":
    main()
