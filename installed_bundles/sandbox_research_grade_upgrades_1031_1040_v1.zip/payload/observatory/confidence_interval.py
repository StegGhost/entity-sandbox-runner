
import json
import statistics
from pathlib import Path

DATA = Path("experiments/critical_ratio_campaign/results/phase_space_map.json")

def main():
    if not DATA.exists():
        return

    data = json.loads(DATA.read_text())
    u_vals = [d["U"] for d in data if d.get("U")]

    mean = statistics.mean(u_vals)
    stdev = statistics.stdev(u_vals)

    print({"mean": mean, "stdev": stdev})

if __name__ == "__main__":
    main()
