
import json
import matplotlib.pyplot as plt
from pathlib import Path

DATA = Path("experiments/critical_ratio_campaign/results/phase_space_map.json")

def main():
    if not DATA.exists():
        print("No data file found")
        return

    data = json.loads(DATA.read_text())
    u_vals = [d["U"] for d in data if d.get("U") is not None]

    plt.hist(u_vals, bins=50)
    plt.title("Real U Distribution")
    plt.savefig("observatory/u_distribution_real.png")
    print("Saved real distribution")

if __name__ == "__main__":
    main()
