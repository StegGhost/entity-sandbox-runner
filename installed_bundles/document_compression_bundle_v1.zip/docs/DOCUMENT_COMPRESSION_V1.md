# Document Compression Bundle v1

This bundle adds a deterministic document compactor for note-heavy repos.

## Installed
- `install/document_compactor.py`
- `config/document_compactor_config.json`

## Outputs
- `docs/canonical/claims_canonical.md`
- `docs/canonical/definitions_canonical.md`
- `docs/canonical/findings_canonical.md`
- `docs/canonical/system_summary.md`
- `docs/canonical/compaction_summary.json`

## Receipt
- `payload/receipts/document_compaction/document_compaction_0001.json`

## Example
```bash
python install/document_compactor.py
```
