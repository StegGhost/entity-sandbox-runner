
from engine.reputation import update, get
def test_reputation():
    update("n1", 0.9)
    assert get("n1") <= 1.0
