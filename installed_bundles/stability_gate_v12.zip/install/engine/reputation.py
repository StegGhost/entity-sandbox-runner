
REPUTATION = {}
def update(node, score):
    REPUTATION[node] = REPUTATION.get(node, 1.0) * score
def get(node):
    return REPUTATION.get(node, 1.0)
