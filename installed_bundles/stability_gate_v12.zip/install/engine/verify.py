
def verify_state(state):
    return state is not None
