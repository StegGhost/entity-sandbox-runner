
PENALTIES = {}
def slash(node, amount):
    PENALTIES[node] = PENALTIES.get(node, 0) + amount
