
def inject_attack(E, intensity):
    return E * intensity
