from __future__ import annotations

from dataclasses import dataclass
from typing import Iterable


@dataclass
class MutationClassification:
    mutation_type: str
    reasons: list[str]

    def as_dict(self) -> dict:
        return {
            "mutation_type": self.mutation_type,
            "reasons": list(self.reasons),
        }


class MutationClassifier:
    """
    Conservative mutation classification.
    """

    def classify(self, changed_files: Iterable[str]) -> MutationClassification:
        files = [str(f).replace("\\", "/") for f in changed_files]
        reasons: list[str] = []

        if any("/workflows/" in f or f.startswith(".github/workflows/") for f in files):
            reasons.append("Workflow mutation detected.")
            return MutationClassification("workflow_mutation", reasons)

        if any("schema" in f or f.endswith(".schema.json") for f in files):
            reasons.append("Schema or interface contract mutation detected.")
            return MutationClassification("interface_mutation", reasons)

        if any("/config/" in f or f.startswith("config/") or f.endswith((".yaml", ".yml", ".json")) for f in files):
            reasons.append("Configuration mutation detected.")
            return MutationClassification("configuration_change", reasons)

        if any(f.endswith(".md") or f.startswith("docs/") for f in files):
            reasons.append("Documentation mutation detected.")
            return MutationClassification("documentation_change", reasons)

        if any(f.endswith(".py") for f in files):
            reasons.append("Code-bearing mutation detected.")
            return MutationClassification("dependency_mutation", reasons)

        reasons.append("Mutation type could not be safely classified.")
        return MutationClassification("unknown_mutation", reasons)
