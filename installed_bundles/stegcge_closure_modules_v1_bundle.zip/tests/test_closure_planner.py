from pathlib import Path

from cge.dependency_graph import DependencyGraph
from cge.closure_planner import ClosurePlanner


def test_closure_expands_to_include_dependencies(tmp_path: Path):
    pkg = tmp_path / "pkg"
    pkg.mkdir()
    (pkg / "__init__.py").write_text("", encoding="utf-8")
    (pkg / "b.py").write_text("VALUE = 1\n", encoding="utf-8")
    (pkg / "a.py").write_text("from pkg.b import VALUE\n", encoding="utf-8")

    graph = DependencyGraph(tmp_path).build()
    planner = ClosurePlanner(graph)
    plan = planner.expand(["pkg/a.py"])

    assert "pkg/b.py" in plan.dependency_closure
    assert "pkg/b.py" in plan.missing_dependencies
    assert plan.closure_complete is False
