from pathlib import Path

from cge.verification_engine import VerificationEngine
from cge.accepted_change_receipt import AcceptedChangeReceipt


def test_verification_defers_when_dependency_closure_incomplete(tmp_path: Path):
    pkg = tmp_path / "pkg"
    pkg.mkdir()
    (pkg / "__init__.py").write_text("", encoding="utf-8")
    (pkg / "b.py").write_text("VALUE = 1\n", encoding="utf-8")
    (pkg / "a.py").write_text("from pkg.b import VALUE\n", encoding="utf-8")

    engine = VerificationEngine(tmp_path)
    result = engine.verify_change(["pkg/a.py"])

    assert result.decision == "defer"
    assert result.closure_complete is False
    assert "pkg/b.py" in result.missing_dependencies


def test_verification_allows_when_closure_complete(tmp_path: Path):
    pkg = tmp_path / "pkg"
    pkg.mkdir()
    (pkg / "__init__.py").write_text("", encoding="utf-8")
    (pkg / "b.py").write_text("VALUE = 1\n", encoding="utf-8")
    (pkg / "a.py").write_text("from pkg.b import VALUE\n", encoding="utf-8")

    engine = VerificationEngine(tmp_path)
    result = engine.verify_change(["pkg/a.py", "pkg/b.py"])

    assert result.decision == "allow"
    assert result.closure_complete is True

    receipt = AcceptedChangeReceipt.from_verification_result(result)
    payload = receipt.to_dict()
    assert payload["closure_complete"] is True
    assert "dependency_closure" in payload
