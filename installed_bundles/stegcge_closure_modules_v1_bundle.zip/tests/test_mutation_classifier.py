from cge.mutation_classifier import MutationClassifier


def test_classifies_python_change_as_dependency_mutation():
    classifier = MutationClassifier()
    result = classifier.classify(["cge/proposal_engine.py"])
    assert result.mutation_type == "dependency_mutation"


def test_classifies_schema_change_as_interface_mutation():
    classifier = MutationClassifier()
    result = classifier.classify(["schemas/proposal.schema.json"])
    assert result.mutation_type == "interface_mutation"
