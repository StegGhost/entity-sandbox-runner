
def validate_policy(policy):
    required = ["allow_docs", "allow_config", "minimize_scopes"]
    for r in required:
        if r not in policy:
            raise ValueError(f"Missing policy key: {r}")
    return True
