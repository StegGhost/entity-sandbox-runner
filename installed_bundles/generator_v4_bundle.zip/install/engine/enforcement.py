
def enforce_policy(manifest, bundle_files):
    allowed = manifest.get("allowed_paths", [])
    violations = []
    for f in bundle_files:
        if not any(f == p or f.startswith(p.rstrip("/")) for p in allowed):
            violations.append(f)
    return {
        "valid": len(violations) == 0,
        "violations": violations
    }
