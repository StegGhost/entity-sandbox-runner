
import os

DEFAULT_POLICY = {
    "allow_docs": True,
    "allow_config": True,
    "minimize_scopes": True
}

def scan_bundle(bundle_root):
    structure = {"install": False, "config": False, "docs": False}
    for root, dirs, files in os.walk(bundle_root):
        rel_root = os.path.relpath(root, bundle_root)
        if rel_root == ".": rel_root = ""
        if rel_root.startswith("install"): structure["install"] = True
        if rel_root.startswith("config"): structure["config"] = True
        if rel_root.startswith("docs"): structure["docs"] = True
    return structure

def build_allowed_paths(structure, policy):
    allowed = set()
    allowed.add("bundle_manifest.json")
    if policy.get("minimize_scopes", True):
        if structure["install"]: allowed.add("install/")
        if structure["config"] and policy.get("allow_config", True): allowed.add("config/")
        if structure["docs"] and policy.get("allow_docs", True): allowed.add("docs/")
    else:
        allowed.update(["install/", "config/", "docs/"])
    return sorted(list(allowed))

def build_manifest(bundle_root, policy=None):
    if policy is None: policy = DEFAULT_POLICY
    structure = scan_bundle(bundle_root)
    allowed_paths = build_allowed_paths(structure, policy)
    return {
        "bundle_name": os.path.basename(bundle_root),
        "bundle_version": "4.0.0",
        "install_mode": "folder_map",
        "policy": policy,
        "allowed_paths": allowed_paths
    }

if __name__ == "__main__":
    print(build_manifest(os.getcwd()))
