
from install.engine.proposal_to_bundle import build_manifest
from install.engine.enforcement import enforce_policy

def test_manifest_build():
    m = build_manifest("sample_bundle")
    assert "allowed_paths" in m

def test_enforcement():
    manifest = {
        "allowed_paths": ["bundle_manifest.json", "install/"]
    }
    files = ["install/apply.py"]
    result = enforce_policy(manifest, files)
    assert result["valid"]
