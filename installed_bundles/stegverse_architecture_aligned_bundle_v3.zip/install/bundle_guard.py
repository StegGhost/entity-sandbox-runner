import json
import os

REQUIRED_FIELDS = [
    "bundle_name",
    "version",
    "install_mode",
    "description",
    "allowed_paths"
]

ALLOWED_ROOT_EXCEPTION = "bundle_manifest.json"

ALLOWED_ROOTS = [
    "install/",
    "payload/",
    "experiments/",
    "workflow_review/"
]

def validate_manifest(manifest_path):
    if not os.path.exists(manifest_path):
        return False, "manifest_missing"

    with open(manifest_path, "r") as f:
        try:
            manifest = json.load(f)
        except Exception:
            return False, "invalid_json"

    missing = [f for f in REQUIRED_FIELDS if f not in manifest]
    if missing:
        return False, f"missing_fields:{missing}"

    return True, "valid"

def validate_structure(bundle_path):
    for root, dirs, files in os.walk(bundle_path):
        rel_root = os.path.relpath(root, bundle_path)

        if rel_root == ".":
            for f in files:
                if f != ALLOWED_ROOT_EXCEPTION:
                    return False, f"illegal_root_file:{f}"

    return True, "valid"

def validate_bundle(bundle_path):
    manifest_path = os.path.join(bundle_path, "bundle_manifest.json")

    valid, reason = validate_manifest(manifest_path)
    if not valid:
        return {"valid": False, "reason": reason}

    valid, reason = validate_structure(bundle_path)
    if not valid:
        return {"valid": False, "reason": reason}

    return {"valid": True, "reason": "valid"}
