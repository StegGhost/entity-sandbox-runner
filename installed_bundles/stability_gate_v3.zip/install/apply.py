import os
import shutil

BASE_DIR = os.getcwd()


def _copy_tree_contents(src_dir: str, dst_dir: str) -> None:
    os.makedirs(dst_dir, exist_ok=True)
    for name in os.listdir(src_dir):
        src_path = os.path.join(src_dir, name)
        dst_path = os.path.join(dst_dir, name)
        if os.path.isdir(src_path):
            if os.path.exists(dst_path):
                shutil.rmtree(dst_path)
            shutil.copytree(src_path, dst_path)
        else:
            shutil.copy2(src_path, dst_path)


def apply_bundle():
    print("[stability_gate_v3] Applying bundle...")

    src_engine = os.path.join(BASE_DIR, "install", "engine")
    dst_engine = os.path.join(BASE_DIR, "engine")
    _copy_tree_contents(src_engine, dst_engine)
    print("[stability_gate_v3] Engine installed.")

    src_tests = os.path.join(BASE_DIR, "install", "tests")
    dst_tests = os.path.join(BASE_DIR, "tests")
    _copy_tree_contents(src_tests, dst_tests)
    print("[stability_gate_v3] Tests installed.")

    src_docs = os.path.join(BASE_DIR, "docs")
    dst_docs = os.path.join(BASE_DIR, "docs")
    _copy_tree_contents(src_docs, dst_docs)
    print("[stability_gate_v3] Docs installed.")

    print("[stability_gate_v3] Bundle applied successfully.")


if __name__ == "__main__":
    apply_bundle()
