import hashlib
import json
from typing import Dict, Any


def build_receipt(payload: Dict[str, Any]) -> Dict[str, Any]:
    serialized = json.dumps(payload, sort_keys=True, separators=(",", ":"))
    digest = hashlib.sha256(serialized.encode("utf-8")).hexdigest()
    return {
        "payload": payload,
        "receipt_hash": digest,
        "receipt_algo": "sha256"
    }
