from typing import Iterable, List


def estimate_env_volatility(samples: Iterable[float]) -> float:
    values: List[float] = [abs(float(x)) for x in samples]
    if not values:
        return 0.0
    return sum(values) / len(values)


def bounded_volatility(samples: Iterable[float], floor: float = 0.05, ceiling: float = 10.0) -> float:
    estimate = estimate_env_volatility(samples)
    if estimate < floor:
        return floor
    if estimate > ceiling:
        return ceiling
    return estimate
