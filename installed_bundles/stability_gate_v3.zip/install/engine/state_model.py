from dataclasses import dataclass, field
from typing import Dict, Any, Optional


@dataclass
class SystemState:
    deliberation_time: float
    model_fidelity: float
    env_volatility: float
    action_magnitude: float
    observed_at: Optional[str] = None
    metadata: Dict[str, Any] = field(default_factory=dict)
