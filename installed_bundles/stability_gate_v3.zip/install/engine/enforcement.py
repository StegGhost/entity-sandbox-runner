from typing import Dict, Any

from .adaptive_threshold import compute_threshold
from .receipts import build_receipt
from .stability_guard import compute_stability_score, classify_stability
from .state_model import SystemState


def enforce_action(
    state: SystemState,
    base_threshold: float = 1.0,
    risk_level: float = 1.0,
    authority_confidence: float = 1.0
) -> Dict[str, Any]:
    threshold = compute_threshold(
        base_threshold=base_threshold,
        risk_level=risk_level,
        authority_confidence=authority_confidence
    )

    score = compute_stability_score(state)
    stability_class = classify_stability(score, threshold)

    if stability_class == "stable":
        status = "allowed"
        next_action = "execute"
    elif stability_class == "borderline":
        status = "delay"
        next_action = "increase_deliberation"
    else:
        status = "blocked"
        next_action = "escalate_or_abort"

    payload = {
        "status": status,
        "next_action": next_action,
        "stability_class": stability_class,
        "stability_score": score,
        "threshold": threshold,
        "state": {
            "deliberation_time": state.deliberation_time,
            "model_fidelity": state.model_fidelity,
            "env_volatility": state.env_volatility,
            "action_magnitude": state.action_magnitude,
            "observed_at": state.observed_at,
            "metadata": state.metadata,
        },
    }
    return build_receipt(payload)
