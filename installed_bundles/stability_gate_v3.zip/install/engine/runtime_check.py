import json
import os

from .enforcement import enforce_action
from .state_model import SystemState
from .volatility import bounded_volatility


def _load_json(path: str):
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def main():
    input_path = os.environ.get("STABILITY_INPUT_JSON", "stability_input.json")
    if not os.path.exists(input_path):
        raise FileNotFoundError(
            f"Missing runtime input file: {input_path}"
        )

    data = _load_json(input_path)
    volatility_samples = data.get("volatility_samples", [])
    env_volatility = data.get("env_volatility")
    if env_volatility is None:
        env_volatility = bounded_volatility(volatility_samples)

    state = SystemState(
        deliberation_time=float(data["deliberation_time"]),
        model_fidelity=float(data["model_fidelity"]),
        env_volatility=float(env_volatility),
        action_magnitude=float(data["action_magnitude"]),
        observed_at=data.get("observed_at"),
        metadata=data.get("metadata", {})
    )

    result = enforce_action(
        state=state,
        base_threshold=float(data.get("base_threshold", 1.0)),
        risk_level=float(data.get("risk_level", 1.0)),
        authority_confidence=float(data.get("authority_confidence", 1.0)),
    )

    print(json.dumps(result, indent=2, sort_keys=True))

    if result["payload"]["status"] == "blocked":
        raise SystemExit(1)


if __name__ == "__main__":
    main()
