from engine.adaptive_threshold import compute_threshold


def test_threshold_rises_with_risk():
    low = compute_threshold(base_threshold=1.0, risk_level=1.0, authority_confidence=1.0)
    high = compute_threshold(base_threshold=1.0, risk_level=2.0, authority_confidence=1.0)
    assert high > low


def test_threshold_rises_when_authority_confidence_drops():
    strong = compute_threshold(base_threshold=1.0, risk_level=1.0, authority_confidence=1.0)
    weak = compute_threshold(base_threshold=1.0, risk_level=1.0, authority_confidence=0.5)
    assert weak > strong
