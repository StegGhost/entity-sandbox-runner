from engine.receipts import build_receipt


def test_receipt_is_deterministic():
    payload = {"a": 1, "b": 2}
    r1 = build_receipt(payload)
    r2 = build_receipt(payload)
    assert r1["receipt_hash"] == r2["receipt_hash"]
    assert r1["receipt_algo"] == "sha256"
