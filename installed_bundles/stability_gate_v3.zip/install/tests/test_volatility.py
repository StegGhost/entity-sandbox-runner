from engine.volatility import estimate_env_volatility, bounded_volatility


def test_estimate_env_volatility():
    assert estimate_env_volatility([1.0, -2.0, 3.0]) == 2.0


def test_bounded_volatility_floor():
    assert bounded_volatility([], floor=0.05) == 0.05
