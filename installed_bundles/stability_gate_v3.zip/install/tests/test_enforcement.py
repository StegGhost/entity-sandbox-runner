from engine.enforcement import enforce_action
from engine.state_model import SystemState


def test_allowed_action():
    state = SystemState(2.0, 1.0, 0.5, 1.0)
    result = enforce_action(state)
    assert result["payload"]["status"] == "allowed"
    assert result["payload"]["next_action"] == "execute"


def test_blocked_action():
    state = SystemState(0.1, 0.3, 2.0, 2.0)
    result = enforce_action(state)
    assert result["payload"]["status"] == "blocked"
    assert result["payload"]["next_action"] == "escalate_or_abort"
