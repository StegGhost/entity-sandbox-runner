# Stability Gate v3

## Core Equation

```text
S = (D × M) / (E × A)
```

Where:

- `D` = deliberation time
- `M` = model fidelity
- `E` = environmental volatility
- `A` = action magnitude

## v3 Additions

- adaptive thresholding via risk and authority confidence
- bounded volatility estimation from samples
- deterministic SHA-256 receipt generation
- runtime execution check entrypoint

## Admissibility

```text
allow(action) iff stability_score >= threshold
```

## Outcome Classes

- `allowed` → execute
- `delay` → increase deliberation
- `blocked` → escalate or abort
