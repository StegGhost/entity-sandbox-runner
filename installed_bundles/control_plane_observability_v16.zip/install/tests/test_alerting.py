
from install.engine.alerting_engine import check_alerts

def test_alert():
    alerts = check_alerts({"failure_rate":0.5}, {"failure_rate":0.3})
    assert len(alerts) > 0
