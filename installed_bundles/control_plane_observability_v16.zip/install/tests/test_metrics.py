
from install.engine.metrics_engine import record_success, record_failure, get_metrics

def test_metrics():
    record_success()
    record_failure()
    m = get_metrics()
    assert "failure_rate" in m
