
def build_dashboard(metrics, state, events):
    return {
        "metrics": metrics,
        "state": state,
        "recent_events": events
    }
