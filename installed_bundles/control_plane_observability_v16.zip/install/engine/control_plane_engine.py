
SYSTEM_STATE = {}

def update_state(key, value):
    SYSTEM_STATE[key] = value

def get_state():
    return SYSTEM_STATE
