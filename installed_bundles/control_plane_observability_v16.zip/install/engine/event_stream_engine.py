
EVENTS = []

def emit_event(event):
    EVENTS.append(event)

def get_events():
    return EVENTS[-100:]
