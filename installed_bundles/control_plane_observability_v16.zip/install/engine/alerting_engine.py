
def check_alerts(metrics, thresholds):
    alerts = []
    if metrics.get("failure_rate",0) > thresholds.get("failure_rate",1):
        alerts.append("HIGH_FAILURE_RATE")
    return alerts
