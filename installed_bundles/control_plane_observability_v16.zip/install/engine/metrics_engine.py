
METRICS = {"success":0, "failure":0}

def record_success():
    METRICS["success"] += 1

def record_failure():
    METRICS["failure"] += 1

def get_metrics():
    total = METRICS["success"] + METRICS["failure"]
    failure_rate = METRICS["failure"] / total if total > 0 else 0
    return {**METRICS, "failure_rate": failure_rate}
