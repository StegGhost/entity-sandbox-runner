class PreemptiveThrottle:
    def apply(self, forecast):
        if forecast["risk"] == "HIGH":
            return "THROTTLE"
        if forecast["risk"] == "MEDIUM":
            return "LIMIT"
        return "NONE"
