class TrajectoryDriftDetector:
    def detect(self, history):
        if len(history) < 5:
            return False

        recent = history[-5:]
        types = [h.get("type") for h in recent]

        return len(set(types)) > 3
