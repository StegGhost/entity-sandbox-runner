class PredictiveStabilityEngine:
    def forecast(self, history):
        if len(history) < 3:
            return {"risk": "LOW", "score": 0.9}

        recent = history[-3:]
        high_risk = sum(1 for h in recent if h.get("risk") == "HIGH")

        if high_risk >= 2:
            return {"risk": "HIGH", "score": 0.3}
        if high_risk == 1:
            return {"risk": "MEDIUM", "score": 0.6}
        return {"risk": "LOW", "score": 0.9}
