from predictive_stability_engine import PredictiveStabilityEngine
from trajectory_drift_detector import TrajectoryDriftDetector
from preemptive_throttle import PreemptiveThrottle

engine = PredictiveStabilityEngine()
drift = TrajectoryDriftDetector()
throttle = PreemptiveThrottle()

def apply(history):
    forecast = engine.forecast(history)
    drift_flag = drift.detect(history)
    throttle_action = throttle.apply(forecast)

    return {
        "forecast": forecast,
        "drift_detected": drift_flag,
        "throttle": throttle_action
    }
