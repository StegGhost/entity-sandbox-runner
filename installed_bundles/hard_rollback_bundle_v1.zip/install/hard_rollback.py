import json, os, shutil

ptr="payload/rollback/latest_snapshot.json"

if not os.path.exists(ptr):
    print("no snapshot"); exit()

snap=json.load(open(ptr))
root=snap.get("snapshot_root")

if not root or not os.path.exists(root):
    print("invalid snapshot"); exit()

for r,_,fs in os.walk(root):
    for fn in fs:
        src=os.path.join(r,fn)
        rel=os.path.relpath(src,root)
        dst=rel
        os.makedirs(os.path.dirname(dst),exist_ok=True)
        shutil.copy2(src,dst)

print({"hard_rollback":True,"source":root})
