import json, os

score_path = "payload/state_scoring/state_score.json"
score = json.load(open(score_path)) if os.path.exists(score_path) else {}

os.makedirs("marketing/generated", exist_ok=True)

post = f"""AI systems today cannot prove what they did.

Current system score: {score.get('score')}

We built a governed execution system that enforces:
- preflight validation
- execution receipts
- rollback safety

This is what AI infrastructure should look like.
"""

with open("marketing/generated/post.txt", "w") as f:
    f.write(post)

print({"generated": True})
