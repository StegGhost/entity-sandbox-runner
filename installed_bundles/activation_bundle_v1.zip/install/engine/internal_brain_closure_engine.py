# PATCH: Add run_sandbox_scenario action at end of action list

def append_activation_action(actions, findings):
    if findings:
        actions.append({
            "action": "run_sandbox_scenario",
            "priority": 10,
            "targets": ["baseline"],
            "reason": "activation: enable sandbox execution loop"
        })
    return actions
