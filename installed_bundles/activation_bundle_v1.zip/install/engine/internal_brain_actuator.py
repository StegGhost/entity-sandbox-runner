import subprocess
from datetime import datetime

def utc_now():
    return datetime.utcnow().isoformat()

def handle_run_sandbox_scenario():
    result = subprocess.run(
        ["python", "install/autonomous_loop_orchestrator.py"],
        capture_output=True,
        text=True
    )

    return {
        "action": "run_sandbox_scenario",
        "status": "executed",
        "stdout": result.stdout,
        "stderr": result.stderr,
        "returncode": result.returncode,
        "ts": utc_now()
    }
