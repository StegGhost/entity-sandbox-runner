# Activation Bundle v1

Adds run_sandbox_scenario action.

Connects:
internal_brain → autonomous_loop_orchestrator

Enables first execution loop.
