v7.3–v7.5 bundle

Includes:
- Adaptive routing (trust-based worker selection)
- Failure reassignment (self-healing behavior)
- U-signal control response (mode switching: conservative / normal / aggressive)
- Autonomous loop with persistence

Install:
1. Upload to repo
2. Ensure workflows are enabled
3. Trigger "Autonomous Evaluation Loop" once
